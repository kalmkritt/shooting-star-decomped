/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 */
package cyou.rimuru.shootingstardemo.star;

import cyou.rimuru.shootingstardemo.magic.a;
import cyou.rimuru.shootingstardemo.magic.f;
import cyou.rimuru.shootingstardemo.spell.c;
import cyou.rimuru.shootingstardemo.star.d;
import cyou.rimuru.shootingstardemo.star.e;
import cyou.rimuru.shootingstardemo.star.h;
import cyou.rimuru.shootingstardemo.star.i;
import cyou.rimuru.shootingstardemo.star.k;
import cyou.rimuru.shootingstardemo.star.l;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public final class j {
    private j() {
    }

    public static boolean a(ServerPlayer serverPlayer, k k2, f f2) {
        cyou.rimuru.shootingstardemo.spell.a a2 = c.b(k2, serverPlayer.getUUID());
        if (a2 != null) {
            String string;
            if (a2 instanceof l) {
                l l2 = (l)a2;
                string = l2.l();
            } else {
                string = null;
            }
            String string2 = string;
            a.a(serverPlayer, string2 != null ? k2.g + " is still raising the land \u2014 " + string2 : k2.g + " is already on its way");
            return false;
        }
        long l3 = serverPlayer.getRandom().nextLong();
        switch (k2) {
            case b: {
                c.a(new e(serverPlayer, c.a(serverPlayer, 420.0, 260.0), l3, f2));
                break;
            }
            case c: {
                c.a(new h(serverPlayer, c.a(serverPlayer, 320.0, 400.0), l3, f2));
                break;
            }
            case d: {
                c.a(new l(serverPlayer, c.a(serverPlayer, 320.0, 200.0), l3, f2));
                break;
            }
            default: {
                c.a(new i(serverPlayer, c.a(serverPlayer, 420.0, 260.0), l3, f2));
            }
        }
        return true;
    }

    static boolean a(Entity entity, ServerPlayer serverPlayer) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            return !j.a(player) && player.isAlive();
        }
        for (Entity entity2 : entity.getIndirectPassengers()) {
            Player player;
            if (!(entity2 instanceof Player) || !j.a(player = (Player)entity2)) continue;
            return false;
        }
        return !entity.isRemoved();
    }

    private static boolean a(Player player) {
        return player.isCreative() || player.isSpectator();
    }

    static void a(ServerLevel serverLevel, Entity entity, ServerPlayer serverPlayer, float f2) {
        d.a(serverLevel, entity, entity == serverPlayer ? null : serverPlayer, f2);
    }
}

