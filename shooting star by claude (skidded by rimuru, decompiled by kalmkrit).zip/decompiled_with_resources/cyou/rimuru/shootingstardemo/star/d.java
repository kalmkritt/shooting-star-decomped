/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.ints.IntArrayList
 *  it.unimi.dsi.fastutil.ints.IntList
 *  net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload
 *  net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Entity$RemovalReason
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.OwnableEntity
 *  net.minecraft.world.entity.boss.enderdragon.EnderDragon
 *  net.minecraft.world.entity.boss.enderdragon.EnderDragonPart
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.entity.projectile.Projectile
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.entity.EntityInLevelCallback
 *  net.minecraft.world.phys.AABB
 */
package cyou.rimuru.shootingstardemo.star;

import cyou.rimuru.shootingstardemo.registry.c;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.EnderDragonPart;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityInLevelCallback;
import net.minecraft.world.phys.AABB;

public final class d {
    private static final int a = 16;
    private static final int b = 400;
    private static final double c = 16.0;
    private static final float d = 1.0E30f;
    private static final Map<UUID, a> e = new HashMap<UUID, a>();
    private static final List<b> f = new ArrayList<b>();
    private static final MethodHandle g;
    private static final MethodHandle h;

    private d() {
    }

    public static void a(ServerLevel serverLevel, Entity entity, ServerPlayer serverPlayer, float f2) {
        if (f2 == Float.POSITIVE_INFINITY) {
            // empty if block
        }
        if (f2 == Float.POSITIVE_INFINITY) {
            cyou.rimuru.shootingstardemo.star.d.a(serverLevel, entity, serverPlayer);
            return;
        }
        if (entity instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity)entity;
            livingEntity.hurtServer(serverLevel, cyou.rimuru.shootingstardemo.registry.c.a(serverLevel, cyou.rimuru.shootingstardemo.registry.c.b, serverPlayer == null || serverPlayer.isRemoved() ? null : serverPlayer), f2);
        } else {
            entity.discard();
        }
    }

    public static void a(ServerLevel serverLevel, Entity entity, ServerPlayer serverPlayer) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            cyou.rimuru.shootingstardemo.star.d.a(serverLevel, player, serverPlayer);
            return;
        }
        Entity entity2 = cyou.rimuru.shootingstardemo.star.d.b(entity);
        Level level = entity2.level();
        if (!(level instanceof ServerLevel)) {
            return;
        }
        ServerLevel serverLevel2 = (ServerLevel)level;
        int n2 = serverLevel2.getServer().getTickCount() + 400;
        cyou.rimuru.shootingstardemo.star.d.a(serverLevel2, entity2, n2);
        AABB aABB = entity2.getBoundingBox().inflate(16.0);
        for (b b2 : f) {
            if (b2.a != serverLevel2 || !b2.b.intersects(aABB)) continue;
            b2.b = b2.b.minmax(aABB);
            b2.c = n2;
            return;
        }
        f.add(new b(serverLevel2, aABB, n2));
    }

    private static Entity b(Entity entity) {
        Entity entity2;
        if (entity instanceof EnderDragonPart) {
            EnderDragonPart enderDragonPart = (EnderDragonPart)entity;
            entity2 = enderDragonPart.parentMob;
        } else {
            entity2 = entity;
        }
        return entity2;
    }

    private static void a(ServerLevel serverLevel, Entity entity, int n2) {
        EnderDragon enderDragon;
        Entity entity222;
        for (Entity entity222 : List.copyOf(entity.getPassengers())) {
            if (entity222 instanceof Player) {
                entity222.stopRiding();
                continue;
            }
            cyou.rimuru.shootingstardemo.star.d.a(serverLevel, cyou.rimuru.shootingstardemo.star.d.b(entity222), n2);
        }
        entity.stopRiding();
        if (entity instanceof EnderDragon) {
            enderDragon = (EnderDragon)entity;
            entity222 = serverLevel.getDragonFight();
            if (entity222 != null) {
                entity222.setDragonKilled(enderDragon);
            }
        }
        enderDragon = new IntArrayList();
        enderDragon.add(entity.getId());
        if (entity instanceof EnderDragon) {
            entity222 = (EnderDragon)entity;
            for (EnderDragonPart enderDragonPart : entity222.getSubEntities()) {
                enderDragon.add(enderDragonPart.getId());
            }
        }
        cyou.rimuru.shootingstardemo.star.d.a(entity);
        entity222 = new ClientboundRemoveEntitiesPacket((IntList)enderDragon);
        cyou.rimuru.shootingstardemo.net.c c2 = new cyou.rimuru.shootingstardemo.net.c(enderDragon.toIntArray());
        for (ServerPlayer serverPlayer : serverLevel.players()) {
            serverPlayer.connection.send((Packet)entity222);
            if (!ServerPlayNetworking.canSend((ServerPlayer)serverPlayer, cyou.rimuru.shootingstardemo.net.c.a)) continue;
            ServerPlayNetworking.send((ServerPlayer)serverPlayer, (CustomPacketPayload)c2);
        }
        e.merge(entity.getUUID(), new a(serverLevel, n2), (a2, a3) -> a2.b >= a3.b ? a2 : a3);
    }

    public static void a(Entity entity) {
        try {
            g.invoke(entity, Entity.RemovalReason.KILLED);
            h.invoke(entity).onRemove(Entity.RemovalReason.KILLED);
        }
        catch (Throwable throwable) {
            throw new IllegalStateException("could not take " + String.valueOf(entity) + " out of the world", throwable);
        }
    }

    private static void a(ServerLevel serverLevel, Player player, ServerPlayer serverPlayer) {
        DamageSource damageSource = cyou.rimuru.shootingstardemo.registry.c.a(serverLevel, cyou.rimuru.shootingstardemo.registry.c.a, serverPlayer == null || serverPlayer.isRemoved() ? null : serverPlayer);
        for (int i2 = 0; i2 < 16 && player.isAlive(); ++i2) {
            player.setInvulnerableTime(0);
            player.hurtServer(serverLevel, damageSource, 1.0E30f);
            if (!player.isAlive()) continue;
            player.setHealth(0.0f);
            player.die(damageSource);
        }
    }

    public static void a(MinecraftServer minecraftServer) {
        Object object;
        Object object2;
        Object object3;
        if (e.isEmpty() && f.isEmpty()) {
            return;
        }
        int n2 = minecraftServer.getTickCount();
        ArrayList<Object> arrayList = new ArrayList<Object>();
        ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
        Iterator<Map.Entry<UUID, a>> iterator = e.entrySet().iterator();
        while (iterator.hasNext()) {
            object3 = iterator.next();
            object2 = (a)object3.getValue();
            if (n2 > ((a)object2).b) {
                iterator.remove();
                continue;
            }
            object = ((a)object2).a.getEntity((UUID)object3.getKey());
            if (object == null) continue;
            arrayList.add(object);
            arrayList2.add(((a)object2).b);
        }
        object3 = f.iterator();
        while (object3.hasNext()) {
            object2 = (b)object3.next();
            if (n2 > ((b)object2).c) {
                object3.remove();
                continue;
            }
            for (ServerLevel serverLevel : ((b)object2).a.getEntities((Entity)null, ((b)object2).b, d::c)) {
                arrayList.add(serverLevel);
                arrayList2.add(((b)object2).c);
            }
        }
        for (int i2 = 0; i2 < arrayList.size(); ++i2) {
            ServerLevel serverLevel;
            object = cyou.rimuru.shootingstardemo.star.d.b((Entity)arrayList.get(i2));
            Level level = object.level();
            if (!(level instanceof ServerLevel) || (serverLevel = (ServerLevel)level).getEntity(object.getUUID()) != object) continue;
            cyou.rimuru.shootingstardemo.star.d.a(serverLevel, (Entity)object, (Integer)arrayList2.get(i2));
        }
    }

    private static boolean c(Entity entity) {
        Entity entity2;
        if (entity.tickCount > 1 || entity instanceof Player) {
            return false;
        }
        if (entity instanceof ItemEntity) {
            ItemEntity itemEntity = (ItemEntity)entity;
            entity2 = itemEntity.getOwner();
        } else if (entity instanceof Projectile) {
            Projectile projectile = (Projectile)entity;
            entity2 = projectile.getOwner();
        } else if (entity instanceof OwnableEntity) {
            OwnableEntity ownableEntity = (OwnableEntity)entity;
            entity2 = ownableEntity.getOwner();
        } else {
            entity2 = null;
        }
        Entity entity3 = entity2;
        return !(entity3 instanceof Player);
    }

    static {
        Field field = null;
        Field field2 = null;
        for (Field field3 : Entity.class.getDeclaredFields()) {
            if (Modifier.isStatic(field3.getModifiers())) continue;
            if (field3.getType() == Entity.RemovalReason.class) {
                field = field3;
                continue;
            }
            if (field3.getType() != EntityInLevelCallback.class) continue;
            field2 = field3;
        }
        if (field == null || field2 == null) {
            throw new IllegalStateException("Entity's removal fields not found");
        }
        try {
            field.setAccessible(true);
            field2.setAccessible(true);
            g = MethodHandles.lookup().unreflectSetter(field);
            h = MethodHandles.lookup().unreflectGetter(field2);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new IllegalStateException(illegalAccessException);
        }
    }

    private static final class b {
        final ServerLevel a;
        AABB b;
        int c;

        b(ServerLevel serverLevel, AABB aABB, int n2) {
            this.a = serverLevel;
            this.b = aABB;
            this.c = n2;
        }
    }

    private record a(ServerLevel a, int b) {
        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{a.class, "level;until", "a", "b"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{a.class, "level;until", "a", "b"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{a.class, "level;until", "a", "b"}, this, object);
        }
    }
}

