/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap$Entry
 *  it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
 *  it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue
 *  it.unimi.dsi.fastutil.longs.LongIterator
 *  it.unimi.dsi.fastutil.longs.LongOpenHashSet
 *  it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.BlockPos$MutableBlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.resources.Identifier
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.server.level.ThreadedLevelLightEngine
 *  net.minecraft.server.level.TicketType
 *  net.minecraft.tags.BlockTags
 *  net.minecraft.tags.FluidTags
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.level.ChunkPos
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.ConcretePowderBlock
 *  net.minecraft.world.level.block.FallingBlock
 *  net.minecraft.world.level.block.Mirror
 *  net.minecraft.world.level.block.Rotation
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.Half
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.block.state.properties.SlabType
 *  net.minecraft.world.level.chunk.LevelChunk
 *  net.minecraft.world.level.levelgen.Heightmap$Types
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 */
package cyou.rimuru.shootingstardemo.star;

import cyou.rimuru.shootingstardemo.ShootingStarDemo;
import cyou.rimuru.shootingstardemo.registry.b;
import cyou.rimuru.shootingstardemo.star.f;
import cyou.rimuru.shootingstardemo.star.g;
import cyou.rimuru.shootingstardemo.star.j;
import cyou.rimuru.shootingstardemo.star.k;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.lang.invoke.MethodHandle;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ThreadedLevelLightEngine;
import net.minecraft.server.level.TicketType;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ConcretePowderBlock;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class l
extends cyou.rimuru.shootingstardemo.spell.a {
    public static final int l = 5;
    public static final int m = 7;
    public static final int n = 9;
    public static final int o = 290;
    public static final int p = 398;
    public static final int q = 426;
    public static final int r = 438;
    public static final int s = 462;
    public static final int t = 474;
    public static final int u = 20;
    public static final int v = 4;
    public static final int w = 562;
    public static final int x = 682;
    public static final int y = 256;
    public static final int z = 32;
    public static final int A = 8;
    public static final int B = 32;
    public static final int C = 20;
    public static final float D = 0.4f;
    public static final double E = 200.0;
    public static final double F = 320.0;
    public static final int G = 0;
    public static final int H = 1;
    public static final int I = 2;
    public static final int J = 3;
    private static final int R = 3072;
    private static final int S = 16;
    private static final long T = 1500000L;
    private static final long U = 20000000L;
    public static final int K = 30;
    private static final int V = 6000;
    private static final long W = Runtime.getRuntime().maxMemory() / 16L;
    private static final int X = 60;
    public static final int L = 12;
    private static final boolean Y = !"false".equals(System.getProperty("shooting_star_demo.tess.fast"));
    private static final boolean Z = Boolean.getBoolean("shooting_star_demo.tess.verify");
    private static final long aa = 4000000L;
    private static final int ab = Mth.clamp((int)(Runtime.getRuntime().availableProcessors() - 2), (int)2, (int)8);
    private static final ExecutorService ac = Executors.newFixedThreadPool(ab, runnable -> {
        Thread thread = new Thread(runnable, "Tesseract builder");
        thread.setDaemon(true);
        thread.setPriority(4);
        return thread;
    });
    private static final TicketType ad = (TicketType)Registry.register((Registry)BuiltInRegistries.TICKET_TYPE, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"tesseract"), (Object)new TicketType(0L, 2));
    private static final Object2IntOpenHashMap<c> ae = new Object2IntOpenHashMap();
    private final long af;
    private long ag;
    private long ah;
    private long ai;
    private long aj;
    private long ak;
    private long al;
    private long am;
    private long an;
    private long ao;
    private long ap;
    private long aq;
    private long ar;
    private int as;
    private int at;
    private int au;
    private int av;
    private int aw;
    private int ax;
    private static final ThreadMXBean ay = ManagementFactory.getThreadMXBean();
    private long az;
    private long aA;
    private long aB;
    private long aC;
    private final boolean aD;
    private final a[] aE = new a[64];
    private final List<Integer> aF = new ArrayList<Integer>();
    private long aG;
    private long aH = W;
    private final LongArrayFIFOQueue aI = new LongArrayFIFOQueue();
    private final LongOpenHashSet aJ = new LongOpenHashSet();
    private static final long aK = 25000000L;
    private final boolean[] aL = new boolean[64];
    private final boolean[] aM = new boolean[4];
    private final int aN;
    private final int aO;
    private final int aP;
    private final int[] aQ = new int[64];
    private final boolean[] aR = new boolean[64];
    private final int[] aS = new int[64];
    private boolean aT = true;
    private long aU = -1L;
    private final ArrayDeque<Integer> aV = new ArrayDeque();
    private final LongOpenHashSet[] aW = new LongOpenHashSet[64];
    private final Long2ObjectOpenHashMap<CompletableFuture<?>> aX = new Long2ObjectOpenHashMap();
    private final Long2IntOpenHashMap aY = new Long2IntOpenHashMap();
    private final double aZ;
    private final int ba;
    private final int bb;
    private final int bc;
    private final int bd;
    private static final int be = 4;
    private static final int bf = 6;
    public static final int M = 16;
    public static final int N = 48;
    private static final int bg = 0;
    private static final int bh = 1;
    private static final int bi = 2;
    private static final int bj = 3;
    private static final int bk = 4;
    public static volatile int O;
    public static volatile int P;
    public static volatile int Q;

    public l(ServerPlayer serverPlayer, Vec3 vec3, long l2, cyou.rimuru.shootingstardemo.magic.f f2) {
        super(cyou.rimuru.shootingstardemo.star.k.d, serverPlayer, serverPlayer.position(), vec3, l2, false, f2);
        this.aZ = cyou.rimuru.shootingstardemo.star.l.a(f2.b());
        this.ba = cyou.rimuru.shootingstardemo.star.l.b(this.aZ);
        this.bb = this.ba / 8;
        this.bc = cyou.rimuru.shootingstardemo.star.l.c(this.aZ);
        this.bd = Math.min((int)Math.ceil(((double)this.ba * 0.72 + 32.0) / 16.0), 32);
        this.aN = cyou.rimuru.shootingstardemo.star.l.a(vec3.x, this.ba);
        this.aO = cyou.rimuru.shootingstardemo.star.l.a(vec3.z, this.ba);
        this.aD = Y;
        O = 0;
        this.aP = cyou.rimuru.shootingstardemo.star.l.a(Mth.floor((double)vec3.y), this.aZ, this.b.getMinY());
        this.af = ChunkPos.pack((int)(Mth.floor((double)vec3.x) >> 4), (int)(Mth.floor((double)vec3.z) >> 4));
        this.a(this.af, this.bd);
        System.arraycopy(cyou.rimuru.shootingstardemo.star.l.k(), 0, this.aQ, 0, this.aQ.length);
        this.aY.defaultReturnValue(Integer.MAX_VALUE);
        Arrays.fill(this.aS, Integer.MAX_VALUE);
        Integer[] integerArray = new Integer[64];
        for (int i2 = 0; i2 < integerArray.length; ++i2) {
            integerArray[i2] = i2;
        }
        Arrays.sort(integerArray, (n2, n3) -> Integer.compare(this.aQ[n2], this.aQ[n3]));
        this.aV.addAll(Arrays.asList(integerArray));
    }

    public static void j() {
    }

    @Override
    public double f() {
        return Math.max(super.f(), (double)this.ba * 0.75 + 400.0);
    }

    public static double a(float f2) {
        return f2 / 0.4f;
    }

    public static int b(double d2) {
        int n2 = 128;
        int n3 = Math.max(16, (int)Math.round(256.0 * d2 / 8.0) * 8);
        return n3 < n2 ? n3 : (int)Math.round(256.0 * d2 / (double)n2) * n2;
    }

    public static int a(double d2, int n2) {
        return Math.floorDiv(Mth.floor((double)d2) + 8, 16) * 16 - n2 / 2;
    }

    public static int c(double d2) {
        return cyou.rimuru.shootingstardemo.star.l.b(d2) / 8;
    }

    public static int a(int n2, double d2, int n3) {
        return Math.max(n2 - 1 - cyou.rimuru.shootingstardemo.star.l.c(d2), n3 + 1);
    }

    public static int a(int n2, int n3, int n4, double d2, int n5) {
        int n6 = (4 - cyou.rimuru.shootingstardemo.star.l.a(n3, n4)) * (int)Math.round(20.0 * d2);
        return Math.max(n2 - n6, Math.min(n2, n5 + 4));
    }

    public static int d(double d2) {
        return cyou.rimuru.shootingstardemo.star.l.c(d2) + (int)Math.round(40.0 * d2);
    }

    public static int[] a(long l2, int n2, int n3, double d2, int n4, int n5, int n6) {
        int n7 = n6 - 2 - n4 - n5;
        int n8 = cyou.rimuru.shootingstardemo.star.l.d(d2);
        if (n7 >= n8) {
            return new int[]{n4 + Math.max(Math.min(cyou.rimuru.shootingstardemo.star.l.a(l2, n2, n3, d2), n7), n8), n5};
        }
        if (n7 >= 12) {
            return new int[]{n4 + n7, n5};
        }
        int n9 = n4 + 12;
        return new int[]{n9, Mth.clamp((int)(n6 - 2 - n9), (int)0, (int)n5)};
    }

    public static int a(long l2, int n2, int n3, int n4, int n5, double d2, int n6, int n7) {
        int n8 = cyou.rimuru.shootingstardemo.star.l.a(l2, n2, n3);
        if (n8 == 3 && (n4 > n5 + (int)Math.round(16.0 * d2) || n5 + n4 > n7 - 2 - n6)) {
            return 2;
        }
        return n8;
    }

    public static List<int[]> a(long l2, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
        ArrayList<int[]> arrayList = new ArrayList<int[]>();
        if (n6 >= n5) {
            return arrayList;
        }
        int n11 = 16;
        int n12 = (n4 + n11 - 1) / n11;
        int n13 = (n5 - n6 + n11 - 1) / n11;
        ArrayList<double[]> arrayList2 = new ArrayList<double[]>();
        for (int i2 = 0; i2 < n13; ++i2) {
            for (int i3 = 0; i3 < n12; ++i3) {
                for (int i4 = 0; i4 < n12; ++i4) {
                    arrayList2.add(new double[]{cyou.rimuru.shootingstardemo.star.l.c(l2, n2 * 131 + i3 * 7 + i2 * 977, n3 * 137 + i4 * 13 + i2 * 31), i3, i2, i4});
                }
            }
        }
        arrayList2.sort((dArray, dArray2) -> Double.compare(dArray[0], dArray2[0]));
        double d2 = (double)n7 + (double)n4 * 0.5;
        double d3 = (double)n8 + (double)n4 * 0.5;
        int n14 = n10 - 2 - n11;
        int n15 = Math.max(1, n14 - (n9 + 16));
        for (int i5 = 0; i5 < Math.min(48, arrayList2.size()); ++i5) {
            int n16 = (int)((double[])arrayList2.get(i5))[1];
            int n17 = (int)((double[])arrayList2.get(i5))[2];
            int n18 = (int)((double[])arrayList2.get(i5))[3];
            int n19 = n17 * 4099 + n16 * 61 + n18;
            double d4 = (double)(n16 * n11) + (double)n11 * 0.5 - (double)n4 * 0.5;
            double d5 = (double)(n18 * n11) + (double)n11 * 0.5 - (double)n4 * 0.5;
            double d6 = d4 * d4 + d5 * d5 < 1.0 ? cyou.rimuru.shootingstardemo.star.l.c(l2, n19, 1) * Math.PI * 2.0 : Math.atan2(d5, d4);
            double d7 = d6 + (double)(n17 + 1) * 0.9 + (cyou.rimuru.shootingstardemo.star.l.c(l2, n19, 2) - 0.5) * 0.6;
            double d8 = (double)n4 * 0.71 + 10.0 + (double)(n17 * n11) * 0.75 + cyou.rimuru.shootingstardemo.star.l.c(l2, n19, 3) * 14.0;
            int n20 = Mth.floor((double)(d2 + Math.cos(d7) * d8 - (double)n11 * 0.5)) + (int)(cyou.rimuru.shootingstardemo.star.l.c(l2, n19, 4) * 11.0) - 5;
            int n21 = Mth.floor((double)(d3 + Math.sin(d7) * d8 - (double)n11 * 0.5)) + (int)(cyou.rimuru.shootingstardemo.star.l.c(l2, n19, 5) * 11.0) - 5;
            int n22 = n14 - (int)(((double)(n17 * n11) * 0.8 + cyou.rimuru.shootingstardemo.star.l.c(l2, n19, 6) * (double)n11 * 2.0) % (double)n15);
            arrayList.add(new int[]{n16 * n11, n6 + n17 * n11, n18 * n11, n20, n22, n21, (int)(cyou.rimuru.shootingstardemo.star.l.c(l2, n19, 7) * 4.0), n17});
        }
        return arrayList;
    }

    public static double e(double d2) {
        return Mth.clamp((double)d2, (double)0.5, (double)2.0);
    }

    public static int f(double d2) {
        return (int)Math.round(13.0 * cyou.rimuru.shootingstardemo.star.l.e(d2));
    }

    public static int a(int n2, int n3, int n4, int n5) {
        int n6 = Math.min(n2 + 150, n5 - 30);
        if (n4 != Integer.MAX_VALUE) {
            n6 = Math.min(n6, n4 - n3 - 8);
        }
        return Math.max(n6, n2 + n3 + 8);
    }

    public static int[] k() {
        int[] nArray = new int[64];
        int[] nArray2 = new int[4];
        for (int i2 = 0; i2 < 8; ++i2) {
            for (int i3 = 0; i3 < 8; ++i3) {
                int n2;
                int n3;
                int n4 = n3 = cyou.rimuru.shootingstardemo.star.l.a(i3, i2);
                nArray2[n4] = nArray2[n4] + 1;
                nArray[i2 * 8 + i3] = 474 + n3 * 20 + (n3 < 2 ? n2 : n2 / 2);
            }
        }
        return nArray;
    }

    public static int a(int n2, int n3) {
        double d2 = 3.5;
        return (int)Math.floor(Math.max(Math.abs((double)n2 - d2), Math.abs((double)n3 - d2)));
    }

    public static int a(long l2, int n2, int n3) {
        double d2 = cyou.rimuru.shootingstardemo.star.l.c(l2, n2 * 7 + 3, n3 * 13 + 5);
        return d2 < 0.42 ? 0 : (d2 < 0.62 ? 1 : (d2 < 0.8 ? 2 : 3));
    }

    public static int b(long l2, int n2, int n3) {
        return cyou.rimuru.shootingstardemo.star.l.a(l2, n2, n3, 1.0);
    }

    public static int a(long l2, int n2, int n3, double d2) {
        return (int)Math.round((double)(90 + (int)(cyou.rimuru.shootingstardemo.star.l.c(l2, n3 * 5 - 1, n2 * 11 + 9) * 160.0)) * d2);
    }

    static double c(long l2, int n2, int n3) {
        long l3 = l2 ^ (long)n2 * -7046029254386353131L ^ (long)n3 * -4417276706812531889L;
        l3 = (l3 ^ l3 >>> 31) * -4658895280553007687L;
        l3 ^= l3 >>> 29;
        return (double)(l3 >>> 11) / 9.007199254740992E15;
    }

    @Override
    protected void a(int n2) {
        if (this.j != null && n2 % 10 == 0) {
            cyou.rimuru.shootingstardemo.spell.d.a(this.j);
        }
        if (n2 == 462) {
            this.p();
        }
        for (int i2 = 0; i2 < 4; ++i2) {
            if (n2 != 474 + i2 * 20 + 8) continue;
            this.g(i2);
        }
        if (n2 == 562) {
            Map<BlockPos, BlockState> map = this.r();
            map.keySet().removeIf(blockPos -> !this.b.getBlockState(blockPos).isAir());
            cyou.rimuru.shootingstardemo.star.a.a(this.b, map);
        }
        if (this.aT && n2 > 582 && this.aV.isEmpty() && this.aF.isEmpty() && this.aX.isEmpty() && this.aJ.isEmpty()) {
            this.s();
        }
    }

    @Override
    protected void b() {
        int n2 = Math.max(0, this.h() - 1);
        if (n2 > 682 && this.aU < 0L) {
            this.aU = this.b.getGameTime();
        }
        this.d(n2);
        if (this.j != null && this.b.getGameTime() % 20L == 0L && this.c(n2)) {
            cyou.rimuru.shootingstardemo.magic.a.a(this.j, this.a.c() + " \u2014 raising the land: " + this.n());
        }
    }

    @Override
    protected boolean c() {
        return super.c() && (this.aV.isEmpty() && this.aF.isEmpty() && this.aJ.isEmpty() && this.aX.isEmpty() || this.aU >= 0L && this.b.getGameTime() - this.aU > 6000L);
    }

    private boolean c(int n2) {
        for (int i2 = 0; i2 < this.aR.length; ++i2) {
            if (this.aR[i2] || n2 < this.aQ[i2]) continue;
            return true;
        }
        return false;
    }

    private String n() {
        int n2 = 0;
        for (boolean bl : this.aR) {
            n2 += bl ? 1 : 0;
        }
        return n2 + " of " + this.aR.length + " cubes up";
    }

    public String l() {
        return this.h() > 474 ? this.n() : null;
    }

    private void d(int n2) {
        long l2;
        this.ax = n2;
        this.ar = 0L;
        long l3 = System.nanoTime();
        this.aX.long2ObjectEntrySet().removeIf(entry -> ((CompletableFuture)entry.getValue()).isDone());
        while (!this.aI.isEmpty() && System.nanoTime() - l3 < 25000000L) {
            l2 = this.aI.dequeueLong();
            this.aJ.remove(l2);
            LevelChunk levelChunk = this.b.getChunkSource().getChunkNow(ChunkPos.getX((long)l2), ChunkPos.getZ((long)l2));
            if (levelChunk == null) continue;
            long l4 = System.nanoTime();
            cyou.rimuru.shootingstardemo.star.a.a(this.b, levelChunk);
            this.ak += System.nanoTime() - l4;
            this.a(new long[]{l2});
        }
        l2 = System.nanoTime();
        long l5 = l2 + 20000000L;
        if (this.aD) {
            Iterator<Integer> iterator = this.aF.iterator();
            while (iterator.hasNext()) {
                int n3 = iterator.next();
                a a2 = this.aE[n3];
                if (a2.g != null) {
                    if (n2 < this.aQ[n3] - 60) {
                        if (this.aW[n3] != null) {
                            this.f(n3);
                        }
                    } else if (this.aW[n3] == null) {
                        this.a(n3, a2.d);
                    }
                }
                if (a2.g == null || n2 < this.aQ[n3] || !a2.g.isDone()) {
                    this.av += n2 >= this.aQ[n3] ? 1 : 0;
                    continue;
                }
                if (System.nanoTime() > l5) break;
                if (!a2.c.a(this.b)) {
                    ++this.as;
                    continue;
                }
                iterator.remove();
                this.aE[n3] = null;
                this.aG -= a2.f;
                this.b(n3, a2);
            }
        }
        long l6 = 0L;
        long l7 = 0L;
        int n4 = 0;
        for (int n5 : this.aV) {
            n4 += this.aW[n5] != null ? this.aW[n5].size() : 0;
        }
        int n6 = 0;
        Iterator<Integer> iterator = this.aV.iterator();
        while (iterator.hasNext() && n6 < 16) {
            int n7;
            int n8 = iterator.next();
            int n9 = n7 = !this.aD || this.aL[n8] ? 1 : 0;
            boolean bl = n7 != 0 ? l6 >= 1500000L : System.nanoTime() > l5;
            LongOpenHashSet longOpenHashSet = new LongOpenHashSet();
            b[] bArray = new b[1];
            int n10 = this.a(n8, longOpenHashSet, bArray);
            if (n10 == 4) {
                iterator.remove();
                this.e(n8);
                continue;
            }
            if (n10 != 0 || n7 != 0 && n2 < this.aQ[n8] || bl) {
                int n11;
                ++n6;
                if (n10 == 1) {
                    this.as += n2 >= this.aQ[n8] ? 1 : 0;
                } else if (n10 == 2) {
                    this.at += n2 >= this.aQ[n8] ? 1 : 0;
                } else if (n10 == 3) {
                    this.au += n2 >= this.aQ[n8] ? 1 : 0;
                }
                int n12 = n11 = this.aW[n8] == null ? longOpenHashSet.size() : longOpenHashSet.size() - this.aW[n8].size();
                if (this.aW[n8] != null || n4 == 0 || n4 + n11 <= 3072) {
                    n4 += Math.max(0, n11);
                    this.a(n8, longOpenHashSet);
                }
                if (n7 != 0) continue;
                l7 += (long)this.bb * (long)this.bb * (long)(this.b.getMaxY() - cyou.rimuru.shootingstardemo.star.l.a(this.aP, n8 % 8, n8 / 8, this.aZ, this.b.getMinY()));
                continue;
            }
            if (n7 != 0) {
                long[] lArray;
                this.a(n8, longOpenHashSet);
                this.aS[n8] = bArray[0].d();
                try {
                    lArray = this.a(n8 % 8, n8 / 8, bArray[0]);
                }
                catch (OutOfMemoryError outOfMemoryError) {
                    ShootingStarDemo.LOGGER.c("[carve-timer] Tesseract: no room in the heap to carve cell {} block by block, it stays", n8);
                    iterator.remove();
                    continue;
                }
                this.a(lArray);
                this.e(n8);
                iterator.remove();
                l6 += (long)this.bb * (long)this.bb * (long)bArray[0].a();
                continue;
            }
            long l8 = this.a(n8, bArray[0]);
            if (!this.aF.isEmpty() && this.aG + l7 + l8 > this.aH) {
                ++n6;
                l7 += l8;
                this.a(n8, longOpenHashSet);
                continue;
            }
            iterator.remove();
            this.a(n8, bArray[0], longOpenHashSet, l8, l5);
        }
        if (this.aD) {
            for (int n7 : this.aF) {
                a a3 = this.aE[n7];
                if (a3.g != null || System.nanoTime() > l5) continue;
                long l9 = System.nanoTime();
                if (a3.c.a(this.b, l5)) {
                    a3.g = this.a(n7, a3);
                }
                this.am += System.nanoTime() - l9;
            }
        }
        for (int i2 = 0; i2 < this.aW.length; ++i2) {
            if (this.aW[i2] == null || !this.aR[i2] || !this.c(this.aW[i2])) continue;
            this.f(i2);
        }
        this.ao = Math.max(this.ao, System.nanoTime() - l3 - this.ar);
    }

    private int a(int n2, LongOpenHashSet longOpenHashSet, b[] bArray) {
        int n3 = n2 % 8;
        int n4 = n2 / 8;
        cyou.rimuru.shootingstardemo.star.l.a(this.aN + n3 * this.bb, this.aO + n4 * this.bb, this.bb, longOpenHashSet);
        if (!this.a(longOpenHashSet)) {
            return 1;
        }
        if (!this.c(longOpenHashSet)) {
            return 2;
        }
        b b2 = this.c(n3, n4);
        if (b2 == null) {
            return 4;
        }
        bArray[0] = b2;
        for (int[] nArray : b2.f()) {
            cyou.rimuru.shootingstardemo.star.l.a(nArray[3], nArray[5], 16, longOpenHashSet);
        }
        if (!this.a(longOpenHashSet)) {
            return 1;
        }
        if (!this.c(longOpenHashSet)) {
            return 2;
        }
        return this.b(longOpenHashSet) ? 3 : 0;
    }

    private long a(int n2, b b2) {
        int n3 = cyou.rimuru.shootingstardemo.star.l.a(this.aP, n2 % 8, n2 / 8, this.aZ, this.b.getMinY());
        return (long)this.bb * (long)this.bb * (long)Math.max(1, this.aP + b2.a() - n3) + (long)b2.f().size() * 16L * 16L * 16L;
    }

    private void a(long[] lArray) {
        ThreadedLevelLightEngine threadedLevelLightEngine = this.b.getChunkSource().getLightEngine();
        for (long l2 : lArray) {
            this.aX.put(l2, this.a(threadedLevelLightEngine, l2));
        }
    }

    private CompletableFuture<?> a(ThreadedLevelLightEngine threadedLevelLightEngine, long l2) {
        return threadedLevelLightEngine.waitForPendingTasks(ChunkPos.getX((long)l2), ChunkPos.getZ((long)l2));
    }

    private void e(int n2) {
        this.aR[n2] = true;
        this.aw = Math.max(this.aw, this.ax - this.aQ[n2]);
        long l2 = System.nanoTime();
        if (this.az == 0L) {
            this.az = l2;
        }
        this.aA = l2;
    }

    private static void a(int n2, int n3, int n4, LongOpenHashSet longOpenHashSet) {
        for (int i2 = n2 >> 4; i2 <= n2 + n4 - 1 >> 4; ++i2) {
            for (int i3 = n3 >> 4; i3 <= n3 + n4 - 1 >> 4; ++i3) {
                longOpenHashSet.add(ChunkPos.pack((int)i2, (int)i3));
            }
        }
    }

    private boolean a(LongOpenHashSet longOpenHashSet) {
        LongIterator longIterator = longOpenHashSet.iterator();
        while (longIterator.hasNext()) {
            long l2 = (Long)longIterator.next();
            if (this.b.getChunkSource().getChunkNow(ChunkPos.getX((long)l2), ChunkPos.getZ((long)l2)) != null) continue;
            return false;
        }
        return true;
    }

    private void a(int n2, LongOpenHashSet longOpenHashSet) {
        if (this.aW[n2] == null) {
            this.aW[n2] = new LongOpenHashSet();
        }
        LongIterator longIterator = longOpenHashSet.iterator();
        while (longIterator.hasNext()) {
            long l2 = (Long)longIterator.next();
            if (!this.aW[n2].add(l2)) continue;
            this.a(l2, 1);
        }
    }

    private void a(long l2, int n2) {
        if (ae.addTo((Object)new c(this.b, l2, n2), 1) == 0) {
            this.b.getChunkSource().addTicketWithRadius(ad, ChunkPos.unpack((long)l2), n2);
        }
    }

    private void b(long l2, int n2) {
        c c2 = new c(this.b, l2, n2);
        int n3 = ae.addTo((Object)c2, -1);
        if (n3 <= 1) {
            ae.removeInt((Object)c2);
            if (n3 == 1) {
                this.b.getChunkSource().removeTicketWithRadius(ad, ChunkPos.unpack((long)l2), n2);
            }
        }
    }

    public static void m() {
        ae.clear();
    }

    private boolean b(LongOpenHashSet longOpenHashSet) {
        for (int n2 : this.aF) {
            LongOpenHashSet longOpenHashSet2 = this.aE[n2].d;
            LongIterator longIterator = longOpenHashSet.iterator();
            while (longIterator.hasNext()) {
                long l2 = (Long)longIterator.next();
                if (!longOpenHashSet2.contains(l2)) continue;
                return true;
            }
        }
        return false;
    }

    private boolean c(LongOpenHashSet longOpenHashSet) {
        LongIterator longIterator = longOpenHashSet.iterator();
        while (longIterator.hasNext()) {
            long l2 = (Long)longIterator.next();
            if (this.aJ.contains(l2)) {
                return false;
            }
            CompletableFuture completableFuture = (CompletableFuture)this.aX.get(l2);
            if (completableFuture == null || completableFuture.isDone()) continue;
            return false;
        }
        return true;
    }

    private void f(int n2) {
        LongIterator longIterator = this.aW[n2].iterator();
        while (longIterator.hasNext()) {
            long l2 = (Long)longIterator.next();
            this.b(l2, 1);
        }
        this.aW[n2] = null;
    }

    private b c(int n2, int n3) {
        int n4;
        int n5;
        int n6;
        int n7 = this.aN + n2 * this.bb;
        int n8 = this.aO + n3 * this.bb;
        int n9 = this.aP;
        int n10 = Math.max(4, this.bb / 16);
        int n11 = this.b.dimensionType().hasCeiling() ? this.b.getMinY() + this.b.dimensionType().logicalHeight() - 6 : Integer.MAX_VALUE;
        for (n6 = n7; n6 < n7 + this.bb; n6 += n10) {
            for (n5 = n8; n5 < n8 + this.bb; n5 += n10) {
                int n12;
                n4 = Math.min(this.b.getHeight(Heightmap.Types.MOTION_BLOCKING, n6, n5) + 1, n11);
                if (n4 > (n12 = this.aY.get(cyou.rimuru.shootingstardemo.star.l.d(n6, n5)))) {
                    n4 = this.b(n6, n5, n12);
                }
                n9 = Math.max(n9, n4);
            }
        }
        n6 = Math.min(n9 - this.aP, this.b.getMaxY() - this.aP);
        if (n6 <= 1) {
            return null;
        }
        n5 = cyou.rimuru.shootingstardemo.star.l.a(this.f, n2, n3, n6, this.bb, this.aZ, this.aP, this.b.getMaxY());
        n4 = n5 == 3 ? this.bb : n6;
        int[] nArray = cyou.rimuru.shootingstardemo.star.l.a(this.f, n2, n3, this.aZ, this.aP, n4, this.b.getMaxY());
        List<int[]> list = cyou.rimuru.shootingstardemo.star.l.a(this.f, n2, n3, this.bb, n4, nArray[1], n7, n8, this.aP + this.bc, this.b.getMaxY());
        return new b(n6, n5, n4, nArray[0], nArray[1], list);
    }

    private int b(int n2, int n3, int n4) {
        BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
        for (int i2 = n4 - 1; i2 > this.aP; --i2) {
            if (this.b.getBlockState((BlockPos)mutableBlockPos.set(n2, i2, n3)).isAir()) continue;
            return i2 + 1;
        }
        return this.aP;
    }

    private static long d(int n2, int n3) {
        return (long)n2 << 32 | (long)n3 & 0xFFFFFFFFL;
    }

    private void a(int n2, b b2, LongOpenHashSet longOpenHashSet, long l2, long l3) {
        a a2;
        int n3 = n2 % 8;
        int n7 = n2 / 8;
        int n8 = this.aN + n3 * this.bb;
        int n9 = this.aO + n7 * this.bb;
        this.aS[n2] = b2.d();
        long l4 = System.nanoTime();
        int n10 = cyou.rimuru.shootingstardemo.star.l.a(this.aP, n3, n7, this.aZ, this.b.getMinY());
        int n11 = b2.a();
        Long2ObjectOpenHashMap long2ObjectOpenHashMap = new Long2ObjectOpenHashMap();
        int n12 = Math.max(this.aP + n11 - 1, b2.d() + b2.e() - 1);
        LongOpenHashSet longOpenHashSet2 = new LongOpenHashSet();
        cyou.rimuru.shootingstardemo.star.l.a(n8, n9, this.bb, longOpenHashSet2);
        Object object = longOpenHashSet2.iterator();
        while (object.hasNext()) {
            long l5 = (Long)object.next();
            cyou.rimuru.shootingstardemo.star.l.a((Long2ObjectOpenHashMap<int[]>)long2ObjectOpenHashMap, l5, n10, n12);
        }
        for (int[] nArray : b2.f()) {
            LongOpenHashSet longOpenHashSet3 = new LongOpenHashSet();
            cyou.rimuru.shootingstardemo.star.l.a(nArray[3], nArray[5], 16, longOpenHashSet3);
            LongIterator longIterator = longOpenHashSet3.iterator();
            while (longIterator.hasNext()) {
                long l6 = (Long)longIterator.next();
                cyou.rimuru.shootingstardemo.star.l.a((Long2ObjectOpenHashMap<int[]>)long2ObjectOpenHashMap, l6, nArray[4], nArray[4] + 16 - 1);
            }
        }
        object = cyou.rimuru.shootingstardemo.star.f.a(this.b, (Long2ObjectMap<int[]>)long2ObjectOpenHashMap, n8, n9, this.bb, n10 + 1, this.aP + n11 - 1);
        Long2ObjectOpenHashMap long2ObjectOpenHashMap2 = null;
        int n13 = cyou.rimuru.shootingstardemo.star.l.a(n3, n7);
        long l7 = System.nanoTime();
        if (Z && !this.aM[n13] && l2 <= 4000000L) {
            this.aM[n13] = true;
            Long2ObjectOpenHashMap long2ObjectOpenHashMap3 = new Long2ObjectOpenHashMap();
            int n14 = this.b.getMinY();
            int n15 = this.b.getMaxY();
            this.a(n3, n7, b2, n10, this.o(), (n4, n5, n6, blockState) -> {
                if (n5 >= n14 && n5 <= n15) {
                    long2ObjectOpenHashMap3.put(BlockPos.asLong((int)n4, (int)n5, (int)n6), (Object)blockState);
                }
            }, new long[4]);
            long2ObjectOpenHashMap2 = long2ObjectOpenHashMap3;
            l2 += (long)long2ObjectOpenHashMap3.size() * 10L;
        }
        long l8 = System.nanoTime() - l7;
        this.aq += l8;
        this.ar += l8;
        this.a(n2, longOpenHashSet);
        this.aE[n2] = a2 = new a(b2, n10, (f)object, longOpenHashSet, long2ObjectOpenHashMap2, l2);
        this.aF.add(n2);
        this.aG += l2;
        if (((f)object).a(this.b, l3)) {
            a2.g = this.a(n2, a2);
        }
        this.am += System.nanoTime() - l4 - l8;
    }

    private CompletableFuture<long[]> a(int n2, a a2) {
        int n3 = n2 % 8;
        int n4 = n2 / 8;
        return CompletableFuture.supplyAsync(() -> {
            long[] lArray = new long[5];
            long l2 = ay.getCurrentThreadCpuTime();
            a2.c.a();
            this.a(n3, n4, a2.a, a2.b, a2.c, a2.c, lArray);
            lArray[4] = ay.getCurrentThreadCpuTime() - l2;
            return lArray;
        }, ac);
    }

    private static void a(Long2ObjectOpenHashMap<int[]> long2ObjectOpenHashMap, long l2, int n2, int n3) {
        int[] nArray = (int[])long2ObjectOpenHashMap.get(l2);
        if (nArray == null) {
            long2ObjectOpenHashMap.put(l2, (Object)new int[]{n2, n3});
        } else {
            nArray[0] = Math.min(nArray[0], n2);
            nArray[1] = Math.max(nArray[1], n3);
        }
    }

    private void b(int n2, a a2) {
        long[] lArray;
        int n3 = n2 % 8;
        int n4 = n2 / 8;
        try {
            lArray = a2.g.join();
        }
        catch (RuntimeException runtimeException) {
            a2.c.c(this.b);
            if (runtimeException.getCause() instanceof OutOfMemoryError) {
                this.aH = Math.max(1L, this.aH / 2L);
                ShootingStarDemo.LOGGER.b("[carve-timer] Tesseract: no room in the heap to build cell {}; building it again, with fewer built ahead (up to {} blocks)", n2, this.aH);
                this.aV.addFirst(n2);
                return;
            }
            ShootingStarDemo.LOGGER.c("[carve-timer] Tesseract: cell {} failed to build, carving it block by block", n2, runtimeException);
            this.aL[n2] = true;
            this.aV.addFirst(n2);
            return;
        }
        if (a2.c.b(this.b)) {
            ShootingStarDemo.LOGGER.a("[carve-timer] Tesseract: cell {}'s land changed while it was built, carving it block by block", n2);
            a2.c.c(this.b);
            this.aL[n2] = true;
            this.aV.addFirst(n2);
            return;
        }
        long l2 = System.nanoTime();
        this.ag += lArray[0];
        this.ah += lArray[1];
        this.ai += lArray[2];
        this.aj += lArray[3];
        this.ap += lArray[4];
        long l3 = System.nanoTime();
        if (a2.e != null) {
            int n5 = 0;
            for (Long2ObjectMap.Entry object : a2.e.long2ObjectEntrySet()) {
                long l4 = object.getLongKey();
                if (a2.c.b(BlockPos.getX((long)l4), BlockPos.getY((long)l4), BlockPos.getZ((long)l4)) == object.getValue()) continue;
                ++n5;
            }
            this.aB += (long)a2.e.size();
            this.aC += (long)n5;
            ShootingStarDemo.LOGGER.a("[carve-timer] Tesseract verify: cell {} ({}, {}), {} of {} blocks differ", n2, n3, n4, n5, a2.e.size());
        }
        long l5 = System.nanoTime() - l3;
        this.aq += l5;
        this.ar += l5;
        if (a2.c.b() > 0) {
            ShootingStarDemo.LOGGER.b("[carve-timer] Tesseract: cell {} reached {} blocks outside what it took up", n2, a2.c.b());
        }
        for (long l6 : a2.c.d(this.b)) {
            if (!this.aJ.add(l6)) continue;
            this.aI.enqueue(l6);
        }
        this.a(a2.a.f());
        this.c(this.aN + n3 * this.bb, this.aO + n4 * this.bb, a2.b);
        this.e(n2);
        long l7 = System.nanoTime() - l2 - l5;
        this.an += l7;
        this.al = Math.max(this.al, l7);
    }

    private d o() {
        return new d(this){
            private long b;
            private LevelChunk c;
            final /* synthetic */ l a;
            {
                l l3 = l2;
                Objects.requireNonNull(l3);
                this.a = l3;
                this.b = Long.MIN_VALUE;
            }

            @Override
            public BlockState a(int n2, int n3, int n4) {
                long l2 = ChunkPos.pack((int)(n2 >> 4), (int)(n4 >> 4));
                if (l2 != this.b) {
                    this.b = l2;
                    this.c = this.a.b.getChunkSource().getChunkNow(n2 >> 4, n4 >> 4);
                }
                return this.c.getSection(this.c.getSectionIndex(n3)).getBlockState(n2 & 0xF, n3 & 0xF, n4 & 0xF);
            }
        };
    }

    private long[] a(int n2, int n3, b b2) {
        long l2 = System.nanoTime();
        int n4 = cyou.rimuru.shootingstardemo.star.l.a(this.aP, n2, n3, this.aZ, this.b.getMinY());
        g g2 = new g(this.b);
        long[] lArray = new long[4];
        this.a(n2, n3, b2, n4, this.o(), g2::a, lArray);
        this.a(b2.f());
        long l3 = System.nanoTime();
        long[] lArray2 = g2.b();
        long l4 = System.nanoTime();
        this.ag += lArray[0];
        this.ah += lArray[1];
        this.ai += lArray[2];
        this.aj += lArray[3];
        this.ak += l4 - l3;
        this.al = Math.max(this.al, l4 - l2);
        this.c(this.aN + n2 * this.bb, this.aO + n3 * this.bb, n4);
        return lArray2;
    }

    /*
     * Exception decompiling
     */
    private void a(int var1_1, int var2_2, b var3_3, int var4_4, d var5_5, e var6_6, long[] var7_7) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.ClassCastException: class org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement cannot be cast to class org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement (org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement and org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement are in unnamed module of loader 'app')
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchExpressionRewriter$LValueSingleUsageCheckingRewriter.rewriteExpression(SwitchExpressionRewriter.java:96)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.expression.LValueExpression.applyExpressionRewriter(LValueExpression.java:84)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter.rewriteExpression(AbstractExpressionRewriter.java:14)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.expression.ArithmeticOperation.applyExpressionRewriter(ArithmeticOperation.java:171)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.rewriters.AbstractExpressionRewriter.rewriteExpression(AbstractExpressionRewriter.java:14)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.AssignmentSimple.rewriteExpressions(AssignmentSimple.java:167)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredFor.rewriteExpressions(StructuredFor.java:194)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:421)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.AbstractStructuredBlockStatement.transformStructuredChildren(AbstractStructuredBlockStatement.java:28)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:421)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.AbstractStructuredBlockStatement.transformStructuredChildren(AbstractStructuredBlockStatement.java:28)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:421)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.transformers.ExpressionRewriterTransformer.transform(ExpressionRewriterTransformer.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:680)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchExpressionRewriter.rewriteBlockSwitches(SwitchExpressionRewriter.java:140)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchExpressionRewriter.transform(SwitchExpressionRewriter.java:71)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.switchExpression(Op04StructuredStatement.java:101)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:909)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static BlockState[] a(BlockState[] blockStateArray, int n2) {
        BlockState[] blockStateArray2 = new BlockState[blockStateArray.length];
        for (int i2 = 1; i2 < blockStateArray2.length; ++i2) {
            BlockState blockState = blockStateArray[i2];
            blockStateArray2[i2] = switch (n2) {
                case 1 -> blockState.rotate(Rotation.CLOCKWISE_90);
                case 2 -> cyou.rimuru.shootingstardemo.star.l.b(blockState);
                case 3 -> cyou.rimuru.shootingstardemo.star.l.c(blockState);
                default -> blockState;
            };
        }
        return blockStateArray2;
    }

    private void a(List<int[]> list) {
        O += list.size();
        for (int[] nArray : list) {
            for (int i2 = nArray[3]; i2 < nArray[3] + 16; ++i2) {
                for (int i3 = nArray[5]; i3 < nArray[5] + 16; ++i3) {
                    long l2 = cyou.rimuru.shootingstardemo.star.l.d(i2, i3);
                    this.aY.put(l2, Math.min(this.aY.get(l2), nArray[4]));
                }
            }
        }
    }

    private void c(int n2, int n3, int n4) {
        for (Entity entity2 : this.b.getEntities((Entity)null, new AABB((double)n2, (double)(n4 - 4), (double)n3, (double)(n2 + this.bb), (double)this.b.getMaxY(), (double)(n3 + this.bb)), entity -> !(entity instanceof LivingEntity))) {
            if (!cyou.rimuru.shootingstardemo.star.j.a(entity2, this.j)) continue;
            cyou.rimuru.shootingstardemo.star.j.a(this.b, entity2, this.j, this.i.c());
        }
    }

    private static long d(int n2, int n3, int n4) {
        return ((long)(n2 / 16) * 65536L + (long)(n3 / 16)) * 65536L + (long)(n4 / 16);
    }

    static BlockState b(int n2, int n3) {
        return cyou.rimuru.shootingstardemo.star.l.a(n2, n3, 256);
    }

    static BlockState a(int n2, int n3, int n4) {
        return b.a.a(Math.min((n2 + n3) * 7 / (2 * n4), 6));
    }

    public static BlockState a(BlockState blockState) {
        Block block;
        if (!blockState.getFluidState().isEmpty()) {
            if (blockState.hasProperty((Property)BlockStateProperties.WATERLOGGED)) {
                blockState = (BlockState)blockState.setValue((Property)BlockStateProperties.WATERLOGGED, (Comparable)Boolean.valueOf(false));
            } else {
                return blockState.getFluidState().is(FluidTags.LAVA) ? Blocks.MAGMA_BLOCK.defaultBlockState() : Blocks.PACKED_ICE.defaultBlockState();
            }
        }
        if ((block = blockState.getBlock()) == Blocks.SAND) {
            return Blocks.SANDSTONE.defaultBlockState();
        }
        if (block == Blocks.RED_SAND) {
            return Blocks.RED_SANDSTONE.defaultBlockState();
        }
        if (block == Blocks.GRAVEL) {
            return Blocks.ANDESITE.defaultBlockState();
        }
        if (block == Blocks.POINTED_DRIPSTONE) {
            return Blocks.DRIPSTONE_BLOCK.defaultBlockState();
        }
        if (block instanceof ConcretePowderBlock) {
            Identifier identifier = BuiltInRegistries.BLOCK.getKey((Object)block);
            Identifier identifier2 = Identifier.fromNamespaceAndPath((String)identifier.getNamespace(), (String)identifier.getPath().replace("_concrete_powder", "_concrete"));
            return BuiltInRegistries.BLOCK.getOptional(identifier2).map(Block::defaultBlockState).orElse(Blocks.TUFF.defaultBlockState());
        }
        if (blockState.is(BlockTags.ANVIL)) {
            return Blocks.IRON_BLOCK.defaultBlockState();
        }
        if (block instanceof FallingBlock && block != Blocks.DRAGON_EGG) {
            return Blocks.TUFF.defaultBlockState();
        }
        return blockState;
    }

    public static BlockState b(BlockState blockState) {
        SlabType slabType;
        BlockState blockState2 = blockState.mirror(Mirror.LEFT_RIGHT);
        if (blockState2.hasProperty((Property)BlockStateProperties.HALF)) {
            blockState2 = (BlockState)blockState2.setValue((Property)BlockStateProperties.HALF, (Comparable)(blockState2.getValue((Property)BlockStateProperties.HALF) == Half.TOP ? Half.BOTTOM : Half.TOP));
        }
        if (blockState2.hasProperty((Property)BlockStateProperties.SLAB_TYPE)) {
            slabType = (SlabType)blockState2.getValue((Property)BlockStateProperties.SLAB_TYPE);
            blockState2 = (BlockState)blockState2.setValue((Property)BlockStateProperties.SLAB_TYPE, (Comparable)(slabType == SlabType.TOP ? SlabType.BOTTOM : (slabType == SlabType.BOTTOM ? SlabType.TOP : slabType)));
        }
        if (blockState2.hasProperty((Property)BlockStateProperties.FACING) && (slabType = (Direction)blockState2.getValue((Property)BlockStateProperties.FACING)).getAxis() == Direction.Axis.Y) {
            blockState2 = (BlockState)blockState2.setValue((Property)BlockStateProperties.FACING, (Comparable)slabType.getOpposite());
        }
        return blockState2;
    }

    private static BlockState c(BlockState blockState) {
        Direction.Axis axis;
        BlockState blockState2 = blockState;
        if (blockState2.hasProperty((Property)BlockStateProperties.AXIS)) {
            axis = (Direction.Axis)blockState2.getValue((Property)BlockStateProperties.AXIS);
            blockState2 = (BlockState)blockState2.setValue((Property)BlockStateProperties.AXIS, (Comparable)(axis == Direction.Axis.Y ? Direction.Axis.Z : (axis == Direction.Axis.Z ? Direction.Axis.Y : axis)));
        }
        if (blockState2.hasProperty((Property)BlockStateProperties.FACING)) {
            axis = (Direction)blockState2.getValue((Property)BlockStateProperties.FACING);
            Direction direction = switch (2.a[axis.ordinal()]) {
                case 1 -> Direction.NORTH;
                case 2 -> Direction.SOUTH;
                case 3 -> Direction.UP;
                case 4 -> Direction.DOWN;
                default -> axis;
            };
            blockState2 = (BlockState)blockState2.setValue((Property)BlockStateProperties.FACING, (Comparable)direction);
        }
        return blockState2;
    }

    private void p() {
        for (Entity entity2 : this.b.getEntities((Entity)null, this.q(), entity -> entity instanceof LivingEntity && cyou.rimuru.shootingstardemo.spell.d.a(entity, this.j))) {
            double d2 = (1.6 + cyou.rimuru.shootingstardemo.star.l.c(this.f, entity2.getId(), 3) * 1.2) * Math.max(1.0, Math.sqrt(this.aZ));
            entity2.setDeltaMovement(entity2.getDeltaMovement().add(0.0, d2, 0.0));
            entity2.syncVelocity = true;
        }
    }

    private void g(int n2) {
        for (Entity entity : this.b.getEntities((Entity)null, this.q())) {
            int n3 = Mth.floor((double)((entity.getX() - (double)this.aN) / (double)this.bb));
            int n4 = Mth.floor((double)((entity.getZ() - (double)this.aO) / (double)this.bb));
            if (n3 < 0 || n4 < 0 || n3 >= 8 || n4 >= 8 || cyou.rimuru.shootingstardemo.star.l.a(n3, n4) > n2 || !cyou.rimuru.shootingstardemo.star.j.a(entity, this.j)) continue;
            cyou.rimuru.shootingstardemo.star.j.a(this.b, entity, this.j, this.i.c());
        }
    }

    private AABB q() {
        return new AABB((double)this.aN, (double)(this.b.getMinY() - 16), (double)this.aO, (double)(this.aN + this.ba), (double)(this.b.getMaxY() + 64), (double)(this.aO + this.ba));
    }

    private Map<BlockPos, BlockState> r() {
        int n2;
        int n3;
        int n4;
        HashMap<BlockPos, BlockState> hashMap = new HashMap<BlockPos, BlockState>();
        int n5 = this.aN + this.ba / 2;
        int n6 = this.aO + this.ba / 2;
        int n7 = cyou.rimuru.shootingstardemo.star.l.f(this.aZ);
        int n8 = Integer.MAX_VALUE;
        for (n4 = 0; n4 < this.aS.length; ++n4) {
            if (cyou.rimuru.shootingstardemo.star.l.a(n4 % 8, n4 / 8) != 0) continue;
            n8 = Math.min(n8, this.aS[n4]);
        }
        n4 = cyou.rimuru.shootingstardemo.star.l.a(this.aP + this.bc, n7, n8, this.b.getMaxY());
        int n9 = (int)Math.round(6.0 * cyou.rimuru.shootingstardemo.star.l.e(this.aZ));
        ArrayList<int[]> arrayList = new ArrayList<int[]>();
        ArrayList<int[]> arrayList2 = new ArrayList<int[]>();
        for (n3 = 0; n3 < 8; ++n3) {
            n2 = (n3 & 1) == 0 ? -1 : 1;
            int n10 = (n3 & 2) == 0 ? -1 : 1;
            int n11 = (n3 & 4) == 0 ? -1 : 1;
            arrayList.add(new int[]{n5 + n2 * n7, n4 + n10 * n7, n6 + n11 * n7});
            arrayList2.add(new int[]{n5 + n2 * n9, n4 + n10 * n9, n6 + n11 * n9});
        }
        for (n3 = 0; n3 < 8; ++n3) {
            for (n2 = n3 + 1; n2 < 8; ++n2) {
                if (Integer.bitCount(n3 ^ n2) != 1) continue;
                cyou.rimuru.shootingstardemo.star.l.a(hashMap, (int[])arrayList.get(n3), (int[])arrayList.get(n2), n4, n7);
                cyou.rimuru.shootingstardemo.star.l.a(hashMap, (int[])arrayList2.get(n3), (int[])arrayList2.get(n2), n4, n7);
            }
            cyou.rimuru.shootingstardemo.star.l.a(hashMap, (int[])arrayList.get(n3), (int[])arrayList2.get(n3), n4, n7);
        }
        return hashMap;
    }

    private static void a(Map<BlockPos, BlockState> map, int[] nArray, int[] nArray2, int n2, int n3) {
        int n4 = Math.max(Math.max(Math.abs(nArray2[0] - nArray[0]), Math.abs(nArray2[1] - nArray[1])), Math.abs(nArray2[2] - nArray[2]));
        int n5 = nArray[0];
        int n6 = nArray[1];
        int n7 = nArray[2];
        for (int i2 = 0; i2 <= n4; ++i2) {
            double d2 = n4 == 0 ? 0.0 : (double)i2 / (double)n4;
            int n8 = (int)Math.round(Mth.lerp((double)d2, (double)nArray[0], (double)nArray2[0]));
            int n9 = (int)Math.round(Mth.lerp((double)d2, (double)nArray[1], (double)nArray2[1]));
            int n10 = (int)Math.round(Mth.lerp((double)d2, (double)nArray[2], (double)nArray2[2]));
            if (n8 != n5) {
                cyou.rimuru.shootingstardemo.star.l.a(map, n8, n6, n7, n2, n3);
            }
            if (n10 != n7) {
                cyou.rimuru.shootingstardemo.star.l.a(map, n8, n6, n10, n2, n3);
            }
            cyou.rimuru.shootingstardemo.star.l.a(map, n8, n9, n10, n2, n3);
            n5 = n8;
            n6 = n9;
            n7 = n10;
        }
    }

    private static void a(Map<BlockPos, BlockState> map, int n2, int n3, int n4, int n5, int n6) {
        map.put(new BlockPos(n2, n3, n4), b.a.a(Mth.clamp((int)((n3 - n5 + n6) * 7 / (2 * n6 + 1)), (int)0, (int)6)));
    }

    private void s() {
        if (this.aT) {
            this.aT = false;
            this.b(this.af, this.bd);
        }
    }

    @Override
    protected void g() {
        long l2 = 1000000L;
        if (this.aD) {
            ShootingStarDemo.LOGGER.a("[carve-timer] Tesseract (fast, {} builders): server thread snapshot {} ms, apply {} ms (relight {} ms), worst cell {} ms, worst tick {} ms; builders read {} ms, clear {} ms, turn {} ms, frame {} ms (wall, {} ms CPU); first to last cell {} ms{}", ab, this.am / l2, this.an / l2, this.ak / l2, this.al / l2, this.ao / l2, this.ag / l2, this.ah / l2, this.ai / l2, this.aj / l2, this.ap / l2, (this.aA - this.az) / l2, this.aB > 0L ? ", verify " + this.aC + " of " + this.aB + " blocks differ (" + this.aq / l2 + " ms, left out)" : "");
        } else {
            ShootingStarDemo.LOGGER.a("[carve-timer] Tesseract (block by block): read {} ms, clear {} ms, turn {} ms, frame {} ms, flush {} ms, worst cell {} ms, worst tick {} ms, first to last cell {} ms", this.ag / l2, this.ah / l2, this.ai / l2, this.aj / l2, this.ak / l2, this.al / l2, this.ao / l2, (this.aA - this.az) / l2);
        }
        ShootingStarDemo.LOGGER.a("[carve-timer] Tesseract waits (cell-ticks): land loading {}, light {}, a neighbour building {}, own build {}; latest cell {} ticks late", this.as, this.at, this.au, this.av, this.aw);
        while (!this.aI.isEmpty()) {
            long l3 = this.aI.dequeueLong();
            LevelChunk levelChunk = this.b.getChunkSource().getChunkNow(ChunkPos.getX((long)l3), ChunkPos.getZ((long)l3));
            if (levelChunk == null) continue;
            cyou.rimuru.shootingstardemo.star.a.a(this.b, levelChunk);
        }
        this.aJ.clear();
        int n2 = 0;
        for (boolean bl : this.aR) {
            n2 += bl ? 0 : 1;
        }
        P = n2;
        Q = this.aw;
        if (n2 > 0) {
            ShootingStarDemo.LOGGER.a("[carve-timer] Tesseract: {} cells never rose ({} still waiting on their land, {} being built)", n2, this.aV.size(), this.aF.size());
            if (this.j != null) {
                cyou.rimuru.shootingstardemo.magic.a.a(this.j, this.a.c() + ": " + n2 + (n2 == 1 ? " cube" : " cubes") + " couldn't load in time and stayed in the ground");
            }
        }
        Object object = this.aF.iterator();
        while (object.hasNext()) {
            int n3 = (Integer)object.next();
            if (this.aE[n3].g != null) {
                this.aE[n3].g.cancel(false);
            }
            this.aE[n3].c.c(this.b);
            this.aE[n3] = null;
        }
        this.aF.clear();
        this.aG = 0L;
        this.aV.clear();
        for (int i2 = 0; i2 < this.aW.length; ++i2) {
            if (this.aW[i2] == null) continue;
            this.f(i2);
        }
        this.s();
    }

    private static final class a {
        final b a;
        final int b;
        final f c;
        final LongOpenHashSet d;
        final Long2ObjectOpenHashMap<BlockState> e;
        final long f;
        CompletableFuture<long[]> g;

        a(b b2, int n2, f f2, LongOpenHashSet longOpenHashSet, Long2ObjectOpenHashMap<BlockState> long2ObjectOpenHashMap, long l2) {
            this.a = b2;
            this.b = n2;
            this.c = f2;
            this.d = longOpenHashSet;
            this.e = long2ObjectOpenHashMap;
            this.f = l2;
        }
    }

    private record b(int a, int b, int c, int d, int e, List<int[]> f) {
        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{b.class, "h;turn;height;base;fit;sections", "a", "b", "c", "d", "e", "f"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{b.class, "h;turn;height;base;fit;sections", "a", "b", "c", "d", "e", "f"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{b.class, "h;turn;height;base;fit;sections", "a", "b", "c", "d", "e", "f"}, this, object);
        }
    }

    private record c(ServerLevel a, long b, int c) {
        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{c.class, "level;chunk;radius", "a", "b", "c"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{c.class, "level;chunk;radius", "a", "b", "c"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{c.class, "level;chunk;radius", "a", "b", "c"}, this, object);
        }
    }

    static interface d {
        public BlockState a(int var1, int var2, int var3);
    }

    static interface e {
        public void put(int var1, int var2, int var3, BlockState var4);

        default public void a(int n2, int n3, int n4, int n5) {
            BlockState blockState = Blocks.AIR.defaultBlockState();
            for (int i2 = n4; i2 <= n5; ++i2) {
                this.put(n2, i2, n3, blockState);
            }
        }
    }
}

