/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2IntMap$Entry
 *  it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap$Entry
 *  it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
 *  it.unimi.dsi.fastutil.longs.LongArrayList
 *  it.unimi.dsi.fastutil.longs.LongIterator
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.SectionPos
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ThreadedLevelLightEngine
 *  net.minecraft.world.level.ChunkPos
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.chunk.LevelChunk
 *  net.minecraft.world.level.chunk.LevelChunkSection
 *  net.minecraft.world.level.chunk.PalettedContainerFactory
 */
package cyou.rimuru.shootingstardemo.star;

import cyou.rimuru.shootingstardemo.ShootingStarDemo;
import cyou.rimuru.shootingstardemo.star.b;
import cyou.rimuru.shootingstardemo.star.l;
import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import java.util.ArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ThreadedLevelLightEngine;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainerFactory;

final class f
implements l.d,
l.e {
    private static final BlockState a = Blocks.AIR.defaultBlockState();
    private final int b;
    private final int c;
    private final PalettedContainerFactory d;
    private final LongArrayList e = new LongArrayList();
    private int f;
    private final Long2ObjectOpenHashMap<int[]> g = new Long2ObjectOpenHashMap();
    private final Long2ObjectOpenHashMap<LevelChunkSection[]> h = new Long2ObjectOpenHashMap();
    private final Long2ObjectOpenHashMap<LevelChunkSection[]> i = new Long2ObjectOpenHashMap();
    private final Long2ObjectOpenHashMap<boolean[]> j = new Long2ObjectOpenHashMap();
    private final Long2ObjectOpenHashMap<boolean[]> k = new Long2ObjectOpenHashMap();
    private final int l;
    private final int m;
    private final int n;
    private final int o;
    private final int p;
    private final int q;
    private int r;
    private final Long2IntOpenHashMap s = new Long2IntOpenHashMap();
    private boolean t;
    private long u = Long.MIN_VALUE;
    private LevelChunkSection[] v;
    private long w = Long.MIN_VALUE;
    private LevelChunkSection[] x;
    private boolean[] y;

    private f(ServerLevel serverLevel, int n2, int n3, int n4, int n5, int n6) {
        this.b = serverLevel.getMinY();
        this.c = serverLevel.getMaxY();
        this.d = serverLevel.palettedContainerFactory();
        this.l = n2;
        this.m = n3;
        this.n = n2 + n4;
        this.o = n3 + n4;
        this.p = n5;
        this.q = n6;
    }

    static f a(ServerLevel serverLevel, Long2ObjectMap<int[]> long2ObjectMap, int n2, int n3, int n4, int n5, int n6) {
        f f2 = new f(serverLevel, n2, n3, n4, n5, n6);
        for (Long2ObjectMap.Entry entry : long2ObjectMap.long2ObjectEntrySet()) {
            f2.e.add(entry.getLongKey());
            f2.g.put(entry.getLongKey(), (Object)((int[])entry.getValue()));
        }
        return f2;
    }

    boolean a(ServerLevel serverLevel, long l2) {
        while (this.f < this.e.size()) {
            long l3 = this.e.getLong(this.f);
            LevelChunk levelChunk = serverLevel.getChunkSource().getChunkNow(ChunkPos.getX((long)l3), ChunkPos.getZ((long)l3));
            if (levelChunk == null) {
                return false;
            }
            int[] nArray = (int[])this.g.get(l3);
            LevelChunkSection[] levelChunkSectionArray = levelChunk.getSections();
            LevelChunkSection[] levelChunkSectionArray2 = new LevelChunkSection[levelChunkSectionArray.length];
            int n2 = Math.max(0, serverLevel.getSectionIndex(Math.max(nArray[0], this.b)));
            int n3 = Math.min(levelChunkSectionArray.length - 1, serverLevel.getSectionIndex(Math.min(nArray[1], this.c)));
            for (int i2 = n2; i2 <= n3; ++i2) {
                levelChunkSectionArray2[i2] = levelChunkSectionArray[i2].copy();
            }
            this.h.put(l3, (Object)levelChunkSectionArray2);
            this.s.put(l3, cyou.rimuru.shootingstardemo.star.b.a(serverLevel, l3));
            ++this.f;
            if (System.nanoTime() <= l2) continue;
            break;
        }
        return this.f >= this.e.size();
    }

    boolean a(ServerLevel serverLevel) {
        LongIterator longIterator = this.h.keySet().iterator();
        while (longIterator.hasNext()) {
            long l2 = (Long)longIterator.next();
            if (serverLevel.getChunkSource().getChunkNow(ChunkPos.getX((long)l2), ChunkPos.getZ((long)l2)) != null) continue;
            return false;
        }
        return true;
    }

    boolean b(ServerLevel serverLevel) {
        for (Long2IntMap.Entry entry : this.s.long2IntEntrySet()) {
            if (cyou.rimuru.shootingstardemo.star.b.c(serverLevel, entry.getLongKey()) == entry.getIntValue()) continue;
            return true;
        }
        return false;
    }

    void c(ServerLevel serverLevel) {
        if (!this.t) {
            this.t = true;
            LongIterator longIterator = this.s.keySet().iterator();
            while (longIterator.hasNext()) {
                long l2 = (Long)longIterator.next();
                cyou.rimuru.shootingstardemo.star.b.b(serverLevel, l2);
            }
        }
    }

    void a() {
        for (Long2ObjectMap.Entry entry : this.h.long2ObjectEntrySet()) {
            long l2 = entry.getLongKey();
            LevelChunkSection[] levelChunkSectionArray = (LevelChunkSection[])entry.getValue();
            LevelChunkSection[] levelChunkSectionArray2 = (LevelChunkSection[])levelChunkSectionArray.clone();
            boolean[] blArray = new boolean[levelChunkSectionArray.length];
            boolean[] blArray2 = new boolean[levelChunkSectionArray.length];
            int n2 = ChunkPos.getX((long)l2) << 4;
            int n3 = ChunkPos.getZ((long)l2) << 4;
            boolean bl = n2 >= this.l && n2 + 16 <= this.n && n3 >= this.m && n3 + 16 <= this.o;
            for (int i2 = 0; i2 < levelChunkSectionArray.length; ++i2) {
                int n4 = this.b + (i2 << 4);
                if (!bl || levelChunkSectionArray[i2] == null || n4 < this.p || n4 + 15 > this.q) continue;
                levelChunkSectionArray2[i2] = new LevelChunkSection(this.d.createForBlockStates(), levelChunkSectionArray[i2].getBiomes());
                blArray[i2] = !levelChunkSectionArray[i2].hasOnlyAir();
                blArray2[i2] = true;
            }
            this.i.put(l2, (Object)levelChunkSectionArray2);
            this.j.put(l2, (Object)blArray);
            this.k.put(l2, (Object)blArray2);
        }
    }

    @Override
    public BlockState a(int n2, int n3, int n4) {
        LevelChunkSection levelChunkSection;
        if (n3 < this.b || n3 > this.c) {
            return a;
        }
        long l2 = ChunkPos.pack((int)(n2 >> 4), (int)(n4 >> 4));
        if (l2 != this.u) {
            this.u = l2;
            this.v = (LevelChunkSection[])this.h.get(l2);
        }
        LevelChunkSection levelChunkSection2 = levelChunkSection = this.v == null ? null : this.v[n3 - this.b >> 4];
        if (levelChunkSection == null) {
            ++this.r;
            return a;
        }
        return levelChunkSection.getBlockState(n2 & 0xF, n3 & 0xF, n4 & 0xF);
    }

    @Override
    public void put(int n2, int n3, int n4, BlockState blockState) {
        LevelChunkSection levelChunkSection;
        if (n3 < this.b || n3 > this.c) {
            return;
        }
        long l2 = ChunkPos.pack((int)(n2 >> 4), (int)(n4 >> 4));
        if (l2 != this.w) {
            this.w = l2;
            this.x = (LevelChunkSection[])this.i.get(l2);
            this.y = (boolean[])this.j.get(l2);
        }
        int n5 = n3 - this.b >> 4;
        LevelChunkSection levelChunkSection2 = levelChunkSection = this.x == null ? null : this.x[n5];
        if (levelChunkSection == null) {
            ++this.r;
            return;
        }
        if (levelChunkSection.setBlockState(n2 & 0xF, n3 & 0xF, n4 & 0xF, blockState, false) != blockState) {
            this.y[n5] = true;
        }
    }

    @Override
    public void a(int n2, int n3, int n4, int n5) {
        boolean[] blArray = (boolean[])this.k.get(ChunkPos.pack((int)(n2 >> 4), (int)(n3 >> 4)));
        int n6 = Math.max(n4, this.b);
        int n7 = Math.min(n5, this.c);
        while (n6 <= n7) {
            int n8 = n6 - this.b >> 4;
            int n9 = Math.min(n7, this.b + (n8 << 4) + 15);
            if (blArray == null || !blArray[n8]) {
                for (int i2 = n6; i2 <= n9; ++i2) {
                    this.put(n2, i2, n3, a);
                }
            }
            n6 = n9 + 1;
        }
    }

    BlockState b(int n2, int n3, int n4) {
        LevelChunkSection[] levelChunkSectionArray = (LevelChunkSection[])this.i.get(ChunkPos.pack((int)(n2 >> 4), (int)(n4 >> 4)));
        LevelChunkSection levelChunkSection = levelChunkSectionArray == null || n3 < this.b || n3 > this.c ? null : levelChunkSectionArray[n3 - this.b >> 4];
        return levelChunkSection == null ? null : levelChunkSection.getBlockState(n2 & 0xF, n3 & 0xF, n4 & 0xF);
    }

    int b() {
        return this.r;
    }

    long[] d(ServerLevel serverLevel) {
        this.c(serverLevel);
        ThreadedLevelLightEngine threadedLevelLightEngine = serverLevel.getChunkSource().getLightEngine();
        LongArrayList longArrayList = new LongArrayList();
        for (Long2ObjectMap.Entry entry : this.j.long2ObjectEntrySet()) {
            long l2 = entry.getLongKey();
            boolean[] blArray = (boolean[])entry.getValue();
            LevelChunk levelChunk = serverLevel.getChunkSource().getChunkNow(ChunkPos.getX((long)l2), ChunkPos.getZ((long)l2));
            if (levelChunk == null) {
                ShootingStarDemo.LOGGER.b("[carve-timer] Tesseract: chunk {} was gone when its cell was swapped in", ChunkPos.unpack((long)l2));
                continue;
            }
            LevelChunkSection[] levelChunkSectionArray = levelChunk.getSections();
            LevelChunkSection[] levelChunkSectionArray2 = (LevelChunkSection[])this.i.get(l2);
            boolean bl = false;
            for (int i2 = 0; i2 < blArray.length; ++i2) {
                if (!blArray[i2]) continue;
                bl = true;
                levelChunkSectionArray[i2] = levelChunkSectionArray2[i2];
                if (levelChunkSectionArray2[i2].hasOnlyAir()) continue;
                threadedLevelLightEngine.updateSectionStatus(SectionPos.of((ChunkPos)levelChunk.getPos(), (int)serverLevel.getSectionYFromSectionIndex(i2)), false);
            }
            if (!bl) continue;
            if (!levelChunk.getBlockEntities().isEmpty()) {
                ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
                for (BlockPos blockPos : levelChunk.getBlockEntities().keySet()) {
                    int n2 = levelChunk.getSectionIndex(blockPos.getY());
                    if (n2 < 0 || n2 >= blArray.length || !blArray[n2] || levelChunkSectionArray[n2].getBlockState(blockPos.getX() & 0xF, blockPos.getY() & 0xF, blockPos.getZ() & 0xF).hasBlockEntity()) continue;
                    arrayList.add(blockPos);
                }
                for (BlockPos blockPos : arrayList) {
                    levelChunk.removeBlockEntity(blockPos);
                }
            }
            longArrayList.add(l2);
            cyou.rimuru.shootingstardemo.star.b.d(serverLevel, l2);
        }
        return longArrayList.toLongArray();
    }
}

