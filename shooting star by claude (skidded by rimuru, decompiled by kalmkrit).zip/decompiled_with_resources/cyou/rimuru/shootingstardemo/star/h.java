/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.resources.Identifier
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.server.level.TicketType
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.level.ChunkPos
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.levelgen.Heightmap$Types
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 */
package cyou.rimuru.shootingstardemo.star;

import cyou.rimuru.shootingstardemo.magic.f;
import cyou.rimuru.shootingstardemo.registry.b;
import cyou.rimuru.shootingstardemo.spell.d;
import cyou.rimuru.shootingstardemo.star.a;
import cyou.rimuru.shootingstardemo.star.c;
import cyou.rimuru.shootingstardemo.star.j;
import cyou.rimuru.shootingstardemo.star.k;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class h
extends cyou.rimuru.shootingstardemo.spell.a {
    public static final int l = 5;
    public static final int m = 7;
    public static final int n = 9;
    public static final int o = 24;
    public static final int p = 4;
    public static final int q = 290;
    public static final int r = 16;
    public static final int s = 398;
    public static final int t = 5;
    public static final int u = 8;
    public static final int v = 440;
    public static final int w = 560;
    public static final double x = 5.5;
    public static final double y = 12.0;
    public static final double z = 400.0;
    public static final double A = 320.0;
    private static final int B = 24;
    private static final double C = 2.0;
    private static final int D = 12;
    private static final TicketType E = (TicketType)Registry.register((Registry)BuiltInRegistries.TICKET_TYPE, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"seven_stars"), (Object)new TicketType(0L, 2));
    private static final int F = 4;
    private static final int G = 2;
    private final List<int[]> H = new ArrayList<int[]>();
    private final double I;
    private final double J;
    private final double K;
    private final double L;
    private final double M;
    private final double[][] N = new double[7][];
    private final int[] O = new int[7];
    private final a[] P = new a[7];
    private final a[] Q = new a[cyou.rimuru.shootingstardemo.star.c.i.length];
    private boolean R = true;

    public h(ServerPlayer serverPlayer, Vec3 vec3, long l2, f f2) {
        super(cyou.rimuru.shootingstardemo.star.k.c, serverPlayer, serverPlayer.position(), vec3, l2, false, f2);
        int n2;
        this.I = f2.b();
        this.J = 5.5 * this.I;
        this.K = 12.0 * this.I;
        this.L = 2.0 * this.I;
        this.M = cyou.rimuru.shootingstardemo.star.c.a(serverPlayer.getX(), serverPlayer.getZ(), vec3.x, vec3.z);
        for (n2 = 0; n2 < 7; ++n2) {
            double[] dArray = cyou.rimuru.shootingstardemo.star.c.a(n2, this.M, this.I);
            this.N[n2] = new double[]{vec3.x + dArray[0], vec3.z + dArray[1]};
        }
        for (n2 = 0; n2 < 7; ++n2) {
            this.H.add(new int[]{Mth.floor((double)this.N[n2][0]) >> 4, Mth.floor((double)this.N[n2][1]) >> 4, Math.min((int)Math.ceil((cyou.rimuru.shootingstardemo.star.c.a(n2, this.I) * 1.1 + this.L) / 16.0), 12)});
        }
        for (int[] nArray : cyou.rimuru.shootingstardemo.star.c.i) {
            double[] dArray = this.N[nArray[0]];
            double[] dArray2 = this.N[nArray[1]];
            int n3 = Math.max(1, (int)Math.ceil(Math.hypot(dArray2[0] - dArray[0], dArray2[1] - dArray[1]) / 64.0));
            for (int i2 = 0; i2 <= n3; ++i2) {
                double d2 = (double)i2 / (double)n3;
                this.H.add(new int[]{Mth.floor((double)Mth.lerp((double)d2, (double)dArray[0], (double)dArray2[0])) >> 4, Mth.floor((double)Mth.lerp((double)d2, (double)dArray[1], (double)dArray2[1])) >> 4, 2});
            }
        }
        Object object = this.H.iterator();
        while (object.hasNext()) {
            int[] nArray = (int[])object.next();
            this.b.getChunkSource().addTicketWithRadius(E, new ChunkPos(nArray[0], nArray[1]), nArray[2]);
        }
    }

    public static void j() {
    }

    @Override
    public double f() {
        return cyou.rimuru.shootingstardemo.star.c.a(this.I) + 400.0;
    }

    private a.h k() {
        return new a.h(this){
            final /* synthetic */ h a;
            {
                h h3 = h2;
                Objects.requireNonNull(h3);
                this.a = h3;
            }

            @Override
            public void a(ChunkPos chunkPos) {
                this.a.b.getChunkSource().addTicketWithRadius(E, chunkPos, 0);
            }

            @Override
            public void b(ChunkPos chunkPos) {
                this.a.b.getChunkSource().removeTicketWithRadius(E, chunkPos, 0);
            }
        };
    }

    public static int c(int n2) {
        return 290 + n2 * 16;
    }

    public static int d(int n2) {
        return 398 + n2 * 5;
    }

    private double a(int n2, int n3) {
        long l2 = this.f ^ (long)n2 * -7046029254386353131L ^ (long)n3 * -4417276706812531889L;
        l2 = (l2 ^ l2 >>> 31) * -4658895280553007687L;
        l2 ^= l2 >>> 29;
        return (double)(l2 >>> 11) / 9.007199254740992E15;
    }

    private int a(int n2, int n3, int n4) {
        double d2;
        double d3 = cyou.rimuru.shootingstardemo.star.c.a(n2, this.I);
        double d4 = Math.hypot((double)n3 + 0.5 - this.N[n2][0], (double)n4 + 0.5 - this.N[n2][1]);
        if (d4 > (d2 = d3 * (1.0 + 0.07 * Math.sin(Math.atan2((double)n4 - this.N[n2][1], (double)n3 - this.N[n2][0]) * 5.0 + (double)n2)))) {
            return Integer.MIN_VALUE;
        }
        double d5 = d4 / d2;
        double d6 = (double)this.O[n2] - cyou.rimuru.shootingstardemo.star.c.b(n2, this.I) * (1.0 - d5 * d5) * (1.0 - 0.3 * d5 * d5);
        return Math.max(Mth.floor((double)d6), this.b.getMinY());
    }

    private BlockState a(int n2, int n3, int n4, int n5, BlockState blockState) {
        if (!blockState.getFluidState().isEmpty() || blockState.is((Object)cyou.rimuru.shootingstardemo.registry.b.c) || blockState.is((Object)cyou.rimuru.shootingstardemo.registry.b.d)) {
            return null;
        }
        double d2 = Math.hypot((double)n3 + 0.5 - this.N[n2][0], (double)n5 + 0.5 - this.N[n2][1]) / cyou.rimuru.shootingstardemo.star.c.a(n2, this.I) + (this.a(n3, n5) - 0.5) * 0.18;
        double d3 = this.a(n5 * 3 + 7, n3 * 5 - 1);
        if (d2 < 0.25) {
            return d3 < 0.5 ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : (d3 < 0.8 ? Blocks.OBSIDIAN.defaultBlockState() : Blocks.AMETHYST_BLOCK.defaultBlockState());
        }
        if (d2 < 0.7) {
            return d3 < 0.35 ? Blocks.AMETHYST_BLOCK.defaultBlockState() : (d3 < 0.55 ? Blocks.CALCITE.defaultBlockState() : (d3 < 0.8 ? Blocks.BLACKSTONE.defaultBlockState() : Blocks.SMOOTH_BASALT.defaultBlockState()));
        }
        return d3 < 0.3 ? Blocks.CALCITE.defaultBlockState() : (d3 < 0.55 ? Blocks.TUFF.defaultBlockState() : (d3 < 0.8 ? Blocks.COBBLED_DEEPSLATE.defaultBlockState() : null));
    }

    private double[] a(int n2, double d2, double d3) {
        double[] dArray = this.N[cyou.rimuru.shootingstardemo.star.c.i[n2][0]];
        double[] dArray2 = this.N[cyou.rimuru.shootingstardemo.star.c.i[n2][1]];
        double d4 = dArray2[0] - dArray[0];
        double d5 = dArray2[1] - dArray[1];
        double d6 = Mth.clamp((double)(((d2 - dArray[0]) * d4 + (d3 - dArray[1]) * d5) / (d4 * d4 + d5 * d5)), (double)0.0, (double)1.0);
        return new double[]{Math.hypot(d2 - dArray[0] - d4 * d6, d3 - dArray[1] - d5 * d6), d6};
    }

    private int b(int n2, int n3, int n4) {
        double[] dArray = this.a(n2, (double)n3 + 0.5, (double)n4 + 0.5);
        if (dArray[0] > this.J) {
            return Integer.MIN_VALUE;
        }
        double d2 = Mth.lerp((double)dArray[1], (double)this.O[cyou.rimuru.shootingstardemo.star.c.i[n2][0]], (double)this.O[cyou.rimuru.shootingstardemo.star.c.i[n2][1]]);
        double d3 = dArray[0] / this.J;
        return Math.max(Mth.floor((double)(d2 - this.K * (1.0 - d3 * d3 * d3 * d3))), this.b.getMinY());
    }

    private BlockState b(int n2, int n3, int n4, int n5, BlockState blockState) {
        if (!blockState.getFluidState().isEmpty() || blockState.is((Object)cyou.rimuru.shootingstardemo.registry.b.c)) {
            return null;
        }
        double d2 = this.a(n2, (double)n3 + 0.5, (double)n5 + 0.5)[0];
        if (d2 < Math.max(this.I, 0.6)) {
            return cyou.rimuru.shootingstardemo.registry.b.d.defaultBlockState();
        }
        double d3 = this.a(n3 * 11 + n2, n5 * 7 - n2);
        return d3 < 0.3 ? Blocks.BLACKSTONE.defaultBlockState() : (d3 < 0.5 ? Blocks.AMETHYST_BLOCK.defaultBlockState() : (d3 < 0.75 ? Blocks.SMOOTH_BASALT.defaultBlockState() : Blocks.CALCITE.defaultBlockState()));
    }

    private Map<BlockPos, BlockState> e(int n2) {
        HashMap<BlockPos, BlockState> hashMap = new HashMap<BlockPos, BlockState>();
        BlockState blockState = cyou.rimuru.shootingstardemo.registry.b.c.defaultBlockState();
        int n3 = Mth.floor((double)this.N[n2][0]);
        int n4 = Mth.floor((double)this.N[n2][1]);
        int n5 = Mth.floor((double)((double)this.O[n2] - cyou.rimuru.shootingstardemo.star.c.b(n2, this.I)));
        n5 = Math.max(n5, this.b.getMinY());
        double d2 = cyou.rimuru.shootingstardemo.star.c.a(n2, this.I) / (36.0 * this.I);
        int n6 = 5 + (int)(this.a(n2, 17) * 3.0);
        for (int i2 = -1; i2 < n6; ++i2) {
            double d3 = i2 < 0 ? 0.0 : ((double)i2 + this.a(n2 * 13 + i2, 5) * 0.6) / (double)n6 * Math.PI * 2.0;
            double d4 = i2 < 0 ? 0.0 : 0.35 + this.a(i2, n2 * 7) * 0.5;
            double d5 = (i2 < 0 ? 16.0 : 7.0 + this.a(n2 + i2 * 3, 9) * 7.0) * (0.6 + 0.6 * d2) * this.I;
            double d6 = (i2 < 0 ? 2.2 : 1.2) * this.I;
            for (double d7 = 0.0; d7 < d5; d7 += 1.0) {
                double d8 = d6 * (1.0 - d7 / d5 * 0.85);
                double d9 = (double)n3 + 0.5 + Math.cos(d3) * Math.sin(d4) * d7;
                double d10 = (double)n5 + Math.cos(d4) * d7;
                double d11 = (double)n4 + 0.5 + Math.sin(d3) * Math.sin(d4) * d7;
                int n7 = (int)Math.ceil(d8);
                for (int i3 = -n7; i3 <= n7; ++i3) {
                    for (int i4 = -n7; i4 <= n7; ++i4) {
                        for (int i5 = -n7; i5 <= n7; ++i5) {
                            if (!((double)(i3 * i3 + i4 * i4 + i5 * i5) <= d8 * d8)) continue;
                            hashMap.put(BlockPos.containing((double)(d9 + (double)i3), (double)(d10 + (double)i4), (double)(d11 + (double)i5)), blockState);
                        }
                    }
                }
            }
        }
        return hashMap;
    }

    @Override
    protected void a(int n2) {
        int n6;
        if (this.j != null && n2 % 10 == 0) {
            cyou.rimuru.shootingstardemo.spell.d.a(this.j);
        }
        for (n6 = 0; n6 < 7; ++n6) {
            if (n2 == cyou.rimuru.shootingstardemo.star.h.c(n6)) {
                this.f(n6);
            }
            if (this.P[n6] == null || this.P[n6].i()) continue;
            this.P[n6].j();
        }
        for (n6 = 0; n6 < this.Q.length; ++n6) {
            int n7;
            int n8;
            if (n2 == cyou.rimuru.shootingstardemo.star.h.d(n6)) {
                n8 = cyou.rimuru.shootingstardemo.star.c.i[n6][0];
                n7 = cyou.rimuru.shootingstardemo.star.c.i[n6][1];
                double d2 = (this.N[n8][0] + this.N[n7][0]) * 0.5;
                double d3 = (this.N[n8][1] + this.N[n7][1]) * 0.5;
                double d4 = Math.hypot(this.N[n7][0] - this.N[n8][0], this.N[n7][1] - this.N[n8][1]) * 0.5;
                int n9 = n6;
                this.Q[n6] = cyou.rimuru.shootingstardemo.star.a.a(this.b, new Vec3(d2, this.e.y, d3), d4 + this.J + this.L, (n3, n4) -> this.b(n9, n3, n4), (n3, n4, n5, blockState) -> this.b(n9, n3, n4, n5, blockState), null).a(24).a(this.k()).a().a("Seven Stars line");
            }
            if (this.Q[n6] != null && !this.Q[n6].i()) {
                n8 = n2 - cyou.rimuru.shootingstardemo.star.h.d(n6);
                n7 = cyou.rimuru.shootingstardemo.star.c.i[n6][0];
                int n10 = cyou.rimuru.shootingstardemo.star.c.i[n6][1];
                double d5 = Math.hypot(this.N[n10][0] - this.N[n7][0], this.N[n10][1] - this.N[n7][1]) * 0.5;
                this.Q[n6].a(n8 >= 8 ? Double.MAX_VALUE : (d5 + this.J) * (double)(n8 + 1) / 8.0);
            }
            if (n2 < cyou.rimuru.shootingstardemo.star.h.d(n6) || n2 > cyou.rimuru.shootingstardemo.star.h.d(n6) + 8 + 2 || (n2 - cyou.rimuru.shootingstardemo.star.h.d(n6)) % 2 != 0) continue;
            this.g(n6);
        }
        if (this.R && n2 > 440 && this.l()) {
            this.m();
        }
    }

    private boolean l() {
        for (a a2 : this.P) {
            if (a2 != null && a2.i()) continue;
            return false;
        }
        for (a a2 : this.Q) {
            if (a2 != null && a2.i()) continue;
            return false;
        }
        return true;
    }

    private void f(int n2) {
        int n6 = Mth.floor((double)this.N[n2][0]);
        int n7 = Mth.floor((double)this.N[n2][1]);
        this.b.getChunk(n6 >> 4, n7 >> 4);
        this.O[n2] = this.b.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, n6, n7) - 1;
        double d2 = cyou.rimuru.shootingstardemo.star.c.a(n2, this.I);
        int n8 = n2;
        this.P[n2] = cyou.rimuru.shootingstardemo.star.a.a(this.b, new Vec3(this.N[n2][0], (double)this.O[n2], this.N[n2][1]), d2 * 1.1 + this.L, (n3, n4) -> this.a(n8, n3, n4), (n3, n4, n5, blockState) -> this.a(n8, n3, n4, n5, blockState), null).a(24).a(this.k()).a().a("Seven Stars crater");
        this.P[n2].j();
        this.P[n2].j();
        cyou.rimuru.shootingstardemo.star.a.a(this.b, this.e(n2));
        this.a(this.N[n2][0], this.N[n2][1], d2 + 4.0 * this.L, (double)this.O[n2] - cyou.rimuru.shootingstardemo.star.c.b(n2, this.I) - 4.0 * this.L, true);
    }

    private void g(int n2) {
        int n3 = cyou.rimuru.shootingstardemo.star.c.i[n2][0];
        int n4 = cyou.rimuru.shootingstardemo.star.c.i[n2][1];
        double d2 = Math.min(this.N[n3][0], this.N[n4][0]) - this.J - this.L;
        double d3 = Math.max(this.N[n3][0], this.N[n4][0]) + this.J + this.L;
        double d4 = Math.min(this.N[n3][1], this.N[n4][1]) - this.J - this.L;
        double d5 = Math.max(this.N[n3][1], this.N[n4][1]) + this.J + this.L;
        AABB aABB = new AABB(d2, (double)(this.b.getMinY() - 16), d4, d3, (double)(this.b.getMaxY() + 16), d5);
        List list = this.b.getEntities((Entity)null, aABB, entity -> this.a(n2, entity.getX(), entity.getZ())[0] <= this.J + this.L * 0.75);
        for (Entity entity2 : list) {
            this.a(entity2, true);
        }
    }

    private void a(double d2, double d3, double d4, double d5, boolean bl) {
        AABB aABB = new AABB(d2 - d4, d5, d3 - d4, d2 + d4, (double)(this.b.getMaxY() + 64), d3 + d4);
        for (Entity entity2 : this.b.getEntities((Entity)null, aABB, entity -> Math.hypot(entity.getX() - d2, entity.getZ() - d3) <= d4)) {
            this.a(entity2, bl);
        }
    }

    private void a(Entity entity, boolean bl) {
        if ((bl || entity instanceof LivingEntity) && cyou.rimuru.shootingstardemo.star.j.a(entity, this.j)) {
            cyou.rimuru.shootingstardemo.star.j.a(this.b, entity, this.j, this.i.c());
        }
    }

    private void m() {
        if (this.R) {
            this.R = false;
            for (int[] nArray : this.H) {
                this.b.getChunkSource().removeTicketWithRadius(E, new ChunkPos(nArray[0], nArray[1]), nArray[2]);
            }
        }
    }

    @Override
    protected void g() {
        for (a a2 : this.P) {
            cyou.rimuru.shootingstardemo.star.a.a(a2);
        }
        for (a a2 : this.Q) {
            cyou.rimuru.shootingstardemo.star.a.a(a2);
        }
        this.m();
    }
}

