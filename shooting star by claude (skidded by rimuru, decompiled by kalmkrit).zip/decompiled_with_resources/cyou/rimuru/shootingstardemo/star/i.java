/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Position
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.resources.Identifier
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.server.level.TicketType
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.level.ChunkPos
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 */
package cyou.rimuru.shootingstardemo.star;

import cyou.rimuru.shootingstardemo.magic.f;
import cyou.rimuru.shootingstardemo.spell.d;
import cyou.rimuru.shootingstardemo.star.a;
import cyou.rimuru.shootingstardemo.star.j;
import cyou.rimuru.shootingstardemo.star.k;
import java.util.List;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class i
extends cyou.rimuru.shootingstardemo.spell.a {
    public static final double l = 200.0;
    public static final int m = 5;
    public static final int n = 7;
    public static final int o = 9;
    public static final int p = 314;
    public static final int q = 352;
    public static final int r = 462;
    public static final int s = 486;
    public static final int t = 526;
    public static final double u = 260.0;
    public static final double v = 420.0;
    private static final TicketType x = (TicketType)Registry.register((Registry)BuiltInRegistries.TICKET_TYPE, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"shooting_star"), (Object)new TicketType(0L, 2));
    public final double w;
    private final int y;
    private final ChunkPos z;
    private boolean A = true;
    private a B;

    public i(ServerPlayer serverPlayer, Vec3 vec3, long l2, f f2) {
        super(cyou.rimuru.shootingstardemo.star.k.a, serverPlayer, serverPlayer.position(), vec3, l2, false, f2);
        this.w = f2.b();
        this.y = Math.min((int)Math.ceil((this.w + 16.0) / 16.0), 32);
        this.z = ChunkPos.containing((BlockPos)BlockPos.containing((Position)vec3));
        this.b.getChunkSource().addTicketWithRadius(x, this.z, this.y);
    }

    public static void j() {
    }

    public static double a(double d2, double d3) {
        if (d2 < 352.0) {
            return 0.0;
        }
        if (d2 < 462.0) {
            return d3;
        }
        double d4 = Mth.clamp((double)((d2 - 462.0) / 24.0), (double)0.0, (double)1.0);
        return d3 * Math.pow(1.0 - d4, 1.6);
    }

    @Override
    public double f() {
        return this.w + 400.0;
    }

    @Override
    protected void a(int n2) {
        if (this.j != null && n2 % 10 == 0) {
            cyou.rimuru.shootingstardemo.spell.d.a(this.j);
        }
        if (n2 == 352) {
            this.B = new a(this.b, this.e, this.w, null).a(new a.h(this){
                final /* synthetic */ i a;
                {
                    i i3 = i2;
                    Objects.requireNonNull(i3);
                    this.a = i3;
                }

                @Override
                public void a(ChunkPos chunkPos) {
                    this.a.b.getChunkSource().addTicketWithRadius(x, chunkPos, 0);
                }

                @Override
                public void b(ChunkPos chunkPos) {
                    this.a.b.getChunkSource().removeTicketWithRadius(x, chunkPos, 0);
                }
            });
        }
        if (this.B != null && !this.B.i()) {
            this.B.j();
        }
        if (n2 >= 352 && n2 < 486 && (n2 - 352) % 2 == 0) {
            this.a(cyou.rimuru.shootingstardemo.star.i.a(n2, this.w), n2 == 352 || (n2 - 352) % 10 == 0);
        }
        if (this.A && n2 > 352 && (this.B == null || this.B.i())) {
            this.k();
        }
    }

    private void a(double d2, boolean bl) {
        if (d2 <= 0.5) {
            return;
        }
        AABB aABB = new AABB(this.e.x - d2, (double)(this.b.getMinY() - 64), this.e.z - d2, this.e.x + d2, (double)(this.b.getMaxY() + 64), this.e.z + d2);
        double d3 = d2 * d2;
        List list = this.b.getEntities((Entity)null, aABB, entity -> Mth.square((double)(entity.getX() - this.e.x)) + Mth.square((double)(entity.getZ() - this.e.z)) <= d3);
        for (Entity entity2 : list) {
            if (!bl && !(entity2 instanceof LivingEntity) || !cyou.rimuru.shootingstardemo.star.j.a(entity2, this.j)) continue;
            cyou.rimuru.shootingstardemo.star.j.a(this.b, entity2, this.j, this.i.c());
        }
    }

    private void k() {
        if (this.A) {
            this.A = false;
            this.b.getChunkSource().removeTicketWithRadius(x, this.z, this.y);
        }
    }

    @Override
    protected void g() {
        cyou.rimuru.shootingstardemo.star.a.a(this.B);
        this.k();
    }
}

