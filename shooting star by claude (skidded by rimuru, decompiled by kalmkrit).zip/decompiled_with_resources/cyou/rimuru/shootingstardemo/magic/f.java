/*
 * Decompiled with CFR 0.152.
 */
package cyou.rimuru.shootingstardemo.magic;

import cyou.rimuru.shootingstardemo.magic.c;
import cyou.rimuru.shootingstardemo.magic.d;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;

public final class f
extends Record {
    private final float e;
    private final float f;
    private final float g;
    public static final float a = Float.POSITIVE_INFINITY;
    public static final float[] b = new float[]{2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 8.0f, 10.0f, 12.0f, 15.0f, 20.0f, 25.0f, 30.0f, 40.0f, 50.0f, 60.0f, 80.0f, 100.0f, 150.0f, 200.0f, 300.0f, 500.0f, 1000.0f, Float.POSITIVE_INFINITY};
    public static final float c = b[b.length - 1];
    public static final c d = new c(0.3f, 3.0f, 1.0f, true, 0.0f);

    public f(float f2, float f3, float f4) {
        this.e = f2;
        this.f = f3;
        this.g = f4;
    }

    public static f a(d d2) {
        c c2 = d2.j();
        return new f(c2 == null ? 1.0f : c2.c(), c, d.c());
    }

    public f b(d d2) {
        c c2 = d2.j();
        float f2 = c2 == null ? 1.0f : c2.a(this.e);
        float f3 = this.f >= b[0] ? Math.min(this.f, c) : b[0];
        return new f(f2, f3, d.a(this.g));
    }

    public boolean a() {
        return this.f == Float.POSITIVE_INFINITY;
    }

    public static int a(float f2) {
        if (f2 >= c) {
            return b.length - 1;
        }
        int n2 = 0;
        for (int i2 = 1; i2 < b.length; ++i2) {
            if (!(Math.abs(Math.log(b[i2] / f2)) < Math.abs(Math.log(b[n2] / f2)))) continue;
            n2 = i2;
        }
        return n2;
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{f.class, "power;damage;speed", "e", "f", "g"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{f.class, "power;damage;speed", "e", "f", "g"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{f.class, "power;damage;speed", "e", "f", "g"}, this, object);
    }

    public float b() {
        return this.e;
    }

    public float c() {
        return this.f;
    }

    public float d() {
        return this.g;
    }
}

