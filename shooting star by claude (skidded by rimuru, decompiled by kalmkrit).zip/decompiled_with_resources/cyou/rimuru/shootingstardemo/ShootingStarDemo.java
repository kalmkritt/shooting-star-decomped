/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ModInitializer
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
 *  net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry
 *  net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents
 *  net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking
 */
package cyou.rimuru.shootingstardemo;

import cyou.rimuru.shootingstardemo.magic.a;
import cyou.rimuru.shootingstardemo.magic.e;
import cyou.rimuru.shootingstardemo.net.d;
import cyou.rimuru.shootingstardemo.registry.b;
import cyou.rimuru.shootingstardemo.registry.f;
import cyou.rimuru.shootingstardemo.registry.g;
import cyou.rimuru.shootingstardemo.spell.c;
import cyou.rimuru.shootingstardemo.star.h;
import cyou.rimuru.shootingstardemo.star.i;
import cyou.rimuru.shootingstardemo.star.l;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public final class ShootingStarDemo
implements ModInitializer {
    public static final String MOD_ID = "shooting_star_demo";
    public static final cyou.rimuru.shootingstardemo.b LOGGER = new cyou.rimuru.shootingstardemo.b();
    public static final String DEMO_NOTICE = ShootingStarDemo.decoded("RGVtbyBtYWRlIGJ5IHRpa3Rvay5jb20vQHJpbXVydS5kZXYgLSBBbGwgcmlnaHRzIHJlc2VydmVkIC0gZGlzY29yZC5nZy9yaW11cnVkZXY=");
    public static final String DEMO_HANDLE = ShootingStarDemo.decoded("dGlrdG9rLmNvbS9AcmltdXJ1LmRldg==");

    public void onInitialize() {
        g.a();
        b.a();
        f.a();
        cyou.rimuru.shootingstardemo.registry.e.a();
        i.j();
        cyou.rimuru.shootingstardemo.star.e.k();
        h.j();
        l.j();
        PayloadTypeRegistry.serverboundPlay().register(cyou.rimuru.shootingstardemo.net.a.a, cyou.rimuru.shootingstardemo.net.a.b);
        PayloadTypeRegistry.clientboundPlay().register(d.f, d.g);
        PayloadTypeRegistry.clientboundPlay().register(cyou.rimuru.shootingstardemo.net.b.a, cyou.rimuru.shootingstardemo.net.b.b);
        PayloadTypeRegistry.clientboundPlay().register(cyou.rimuru.shootingstardemo.net.c.a, cyou.rimuru.shootingstardemo.net.c.b);
        ServerPlayNetworking.registerGlobalReceiver(cyou.rimuru.shootingstardemo.net.a.a, (a2, context) -> a.a(context.player(), a2.a(), a2.b(), a2.c(), a2.d(), a2.e()));
        ServerPlayConnectionEvents.JOIN.register((serverGamePacketListenerImpl, packetSender, minecraftServer) -> a.a(serverGamePacketListenerImpl.getPlayer()));
        ServerTickEvents.END_SERVER_TICK.register(c::a);
        ServerTickEvents.END_SERVER_TICK.register(cyou.rimuru.shootingstardemo.star.d::a);
        ServerLifecycleEvents.SERVER_STOPPING.register(minecraftServer -> {
            c.a();
            a.a();
        });
        LOGGER.a("The Shooting Star demo is armed with {} skills. {}", e.b(), DEMO_NOTICE);
    }

    private static String decoded(String string) {
        return new String(Base64.getDecoder().decode(string), StandardCharsets.UTF_8);
    }
}

