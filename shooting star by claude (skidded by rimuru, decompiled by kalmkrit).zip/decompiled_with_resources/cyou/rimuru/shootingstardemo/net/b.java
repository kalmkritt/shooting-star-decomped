/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.RegistryFriendlyByteBuf
 *  net.minecraft.network.codec.StreamCodec
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload$Type
 *  net.minecraft.resources.Identifier
 */
package cyou.rimuru.shootingstardemo.net;

import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public final class b
extends Record
implements CustomPacketPayload {
    private final int[] c;
    private final int[] d;
    public static final CustomPacketPayload.Type<b> a = new CustomPacketPayload.Type(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"cooldowns"));
    public static final StreamCodec<RegistryFriendlyByteBuf, b> b = CustomPacketPayload.codec(b::b, b::a);

    public b(int[] nArray, int[] nArray2) {
        this.c = nArray;
        this.d = nArray2;
    }

    private static b a(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        int n2 = Math.min(registryFriendlyByteBuf.readVarInt(), 4096);
        int[] nArray = new int[n2];
        int[] nArray2 = new int[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            nArray[i2] = registryFriendlyByteBuf.readVarInt();
            nArray2[i2] = registryFriendlyByteBuf.readVarInt();
        }
        return new b(nArray, nArray2);
    }

    private void b(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        registryFriendlyByteBuf.writeVarInt(this.c.length);
        for (int i2 = 0; i2 < this.c.length; ++i2) {
            registryFriendlyByteBuf.writeVarInt(this.c[i2]);
            registryFriendlyByteBuf.writeVarInt(this.d[i2]);
        }
    }

    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return a;
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{b.class, "remaining;total", "c", "d"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{b.class, "remaining;total", "c", "d"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{b.class, "remaining;total", "c", "d"}, this, object);
    }

    public int[] a() {
        return this.c;
    }

    public int[] b() {
        return this.d;
    }
}

