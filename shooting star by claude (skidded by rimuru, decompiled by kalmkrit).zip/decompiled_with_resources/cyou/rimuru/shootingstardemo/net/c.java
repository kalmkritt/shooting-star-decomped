/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.RegistryFriendlyByteBuf
 *  net.minecraft.network.codec.StreamCodec
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload$Type
 *  net.minecraft.resources.Identifier
 */
package cyou.rimuru.shootingstardemo.net;

import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public final class c
extends Record
implements CustomPacketPayload {
    private final int[] c;
    public static final CustomPacketPayload.Type<c> a = new CustomPacketPayload.Type(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"erase"));
    public static final StreamCodec<RegistryFriendlyByteBuf, c> b = CustomPacketPayload.codec(c::b, c::a);

    public c(int[] nArray) {
        this.c = nArray;
    }

    private static c a(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        int n2 = Math.min(registryFriendlyByteBuf.readVarInt(), 4096);
        int[] nArray = new int[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            nArray[i2] = registryFriendlyByteBuf.readVarInt();
        }
        return new c(nArray);
    }

    private void b(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        registryFriendlyByteBuf.writeVarInt(this.c.length);
        for (int n2 : this.c) {
            registryFriendlyByteBuf.writeVarInt(n2);
        }
    }

    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return a;
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{c.class, "ids", "c"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{c.class, "ids", "c"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{c.class, "ids", "c"}, this, object);
    }

    public int[] a() {
        return this.c;
    }
}

