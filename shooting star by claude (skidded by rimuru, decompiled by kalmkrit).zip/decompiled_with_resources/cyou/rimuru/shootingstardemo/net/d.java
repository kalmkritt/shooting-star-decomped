/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.RegistryFriendlyByteBuf
 *  net.minecraft.network.codec.StreamCodec
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload$Type
 *  net.minecraft.resources.Identifier
 */
package cyou.rimuru.shootingstardemo.net;

import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public final class d
extends Record
implements CustomPacketPayload {
    private final int h;
    private final int i;
    private final double j;
    private final double k;
    private final double l;
    private final double m;
    private final double n;
    private final double o;
    private final float p;
    private final long q;
    private final int[] r;
    private final int s;
    private final float t;
    private final float u;
    public static final int a = 1;
    public static final int b = 2;
    public static final int c = 4;
    public static final int d = 8;
    public static final int e = 2048;
    public static final CustomPacketPayload.Type<d> f = new CustomPacketPayload.Type(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"spell_fx"));
    public static final StreamCodec<RegistryFriendlyByteBuf, d> g = CustomPacketPayload.codec(d::b, d::new);

    private d(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        this(registryFriendlyByteBuf.readVarInt(), registryFriendlyByteBuf.readVarInt(), registryFriendlyByteBuf.readDouble(), registryFriendlyByteBuf.readDouble(), registryFriendlyByteBuf.readDouble(), registryFriendlyByteBuf.readDouble(), registryFriendlyByteBuf.readDouble(), registryFriendlyByteBuf.readDouble(), registryFriendlyByteBuf.readFloat(), registryFriendlyByteBuf.readLong(), cyou.rimuru.shootingstardemo.net.d.a(registryFriendlyByteBuf), registryFriendlyByteBuf.readVarInt(), registryFriendlyByteBuf.readFloat(), registryFriendlyByteBuf.readFloat());
    }

    public d(int n2, int n3, double d2, double d3, double d4, double d5, double d6, double d7, float f2, long l2, int[] nArray, int n4, float f3, float f4) {
        this.h = n2;
        this.i = n3;
        this.j = d2;
        this.k = d3;
        this.l = d4;
        this.m = d5;
        this.n = d6;
        this.o = d7;
        this.p = f2;
        this.q = l2;
        this.r = nArray;
        this.s = n4;
        this.t = f3;
        this.u = f4;
    }

    private static int[] a(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        int[] nArray = new int[Math.min(registryFriendlyByteBuf.readVarInt(), 2048)];
        for (int i2 = 0; i2 < nArray.length; ++i2) {
            nArray[i2] = registryFriendlyByteBuf.readVarInt();
        }
        return nArray;
    }

    public int a() {
        return this.r.length > 0 ? this.r[0] : -1;
    }

    private void b(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        registryFriendlyByteBuf.writeVarInt(this.h);
        registryFriendlyByteBuf.writeVarInt(this.i);
        registryFriendlyByteBuf.writeDouble(this.j);
        registryFriendlyByteBuf.writeDouble(this.k);
        registryFriendlyByteBuf.writeDouble(this.l);
        registryFriendlyByteBuf.writeDouble(this.m);
        registryFriendlyByteBuf.writeDouble(this.n);
        registryFriendlyByteBuf.writeDouble(this.o);
        registryFriendlyByteBuf.writeFloat(this.p);
        registryFriendlyByteBuf.writeLong(this.q);
        int n2 = Math.min(this.r.length, 2048);
        registryFriendlyByteBuf.writeVarInt(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            registryFriendlyByteBuf.writeVarInt(this.r[i2]);
        }
        registryFriendlyByteBuf.writeVarInt(this.s);
        registryFriendlyByteBuf.writeFloat(this.t);
        registryFriendlyByteBuf.writeFloat(this.u);
    }

    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return f;
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{d.class, "spell;casterId;ox;oy;oz;tx;ty;tz;yaw;seed;targets;flags;power;speed", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{d.class, "spell;casterId;ox;oy;oz;tx;ty;tz;yaw;seed;targets;flags;power;speed", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{d.class, "spell;casterId;ox;oy;oz;tx;ty;tz;yaw;seed;targets;flags;power;speed", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u"}, this, object);
    }

    public int b() {
        return this.h;
    }

    public int c() {
        return this.i;
    }

    public double d() {
        return this.j;
    }

    public double e() {
        return this.k;
    }

    public double f() {
        return this.l;
    }

    public double g() {
        return this.m;
    }

    public double h() {
        return this.n;
    }

    public double i() {
        return this.o;
    }

    public float j() {
        return this.p;
    }

    public long k() {
        return this.q;
    }

    public int[] l() {
        return this.r;
    }

    public int m() {
        return this.s;
    }

    public float n() {
        return this.t;
    }

    public float o() {
        return this.u;
    }
}

