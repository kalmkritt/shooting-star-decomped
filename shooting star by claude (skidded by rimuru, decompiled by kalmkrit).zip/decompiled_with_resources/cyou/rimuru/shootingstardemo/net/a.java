/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.RegistryFriendlyByteBuf
 *  net.minecraft.network.codec.StreamCodec
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload$Type
 *  net.minecraft.resources.Identifier
 */
package cyou.rimuru.shootingstardemo.net;

import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public final class a
extends Record
implements CustomPacketPayload {
    private final int c;
    private final float d;
    private final float e;
    private final float f;
    private final boolean g;
    public static final CustomPacketPayload.Type<a> a = new CustomPacketPayload.Type(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"cast"));
    public static final StreamCodec<RegistryFriendlyByteBuf, a> b = CustomPacketPayload.codec(a::a, a::new);

    private a(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        this(registryFriendlyByteBuf.readVarInt(), registryFriendlyByteBuf.readFloat(), registryFriendlyByteBuf.readFloat(), registryFriendlyByteBuf.readFloat(), registryFriendlyByteBuf.readBoolean());
    }

    public a(int n2, float f2, float f3, float f4, boolean bl) {
        this.c = n2;
        this.d = f2;
        this.e = f3;
        this.f = f4;
        this.g = bl;
    }

    private void a(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        registryFriendlyByteBuf.writeVarInt(this.c);
        registryFriendlyByteBuf.writeFloat(this.d);
        registryFriendlyByteBuf.writeFloat(this.e);
        registryFriendlyByteBuf.writeFloat(this.f);
        registryFriendlyByteBuf.writeBoolean(this.g);
    }

    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return a;
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{a.class, "skill;power;damage;speed;filmAll", "c", "d", "e", "f", "g"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{a.class, "skill;power;damage;speed;filmAll", "c", "d", "e", "f", "g"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{a.class, "skill;power;damage;speed;filmAll", "c", "d", "e", "f", "g"}, this, object);
    }

    public int a() {
        return this.c;
    }

    public float b() {
        return this.d;
    }

    public float c() {
        return this.e;
    }

    public float d() {
        return this.f;
    }

    public boolean e() {
        return this.g;
    }
}

