/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  net.minecraft.client.renderer.RenderPipelines
 */
package cyou.rimuru.shootingstardemo.client.magic;

import cyou.rimuru.shootingstardemo.client.magic.a;
import cyou.rimuru.shootingstardemo.magic.e;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;

final class d {
    static final int a = 64;
    static final int b = 32;
    static final int c = 0xFF5A5A;

    private d() {
    }

    static int a(int n2, int n3) {
        return Math.max(0, Math.min(255, n2)) << 24 | n3 & 0xFFFFFF;
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, e e2, cyou.rimuru.shootingstardemo.magic.d d2, int n2, int n3) {
        boolean bl = cyou.rimuru.shootingstardemo.client.magic.a.b(d2) <= 0;
        guiGraphicsExtractor.blitSprite(RenderPipelines.GUI_TEXTURED, e2.c(d2), n2, n3, 64, 32, bl ? -1 : -8752000);
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, e e2, cyou.rimuru.shootingstardemo.magic.d d2, int n2, int n3, int n4, int n5, float f2) {
        guiGraphicsExtractor.blitSprite(RenderPipelines.GUI_TEXTURED, e2.c(d2), n2, n3, n4, n5, d.a(Math.round(f2 * 255.0f), 0xFFFFFF));
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, Font font, cyou.rimuru.shootingstardemo.magic.d d2, int n2, int n3) {
        int n4 = cyou.rimuru.shootingstardemo.client.magic.a.b(d2);
        if (n4 <= 0) {
            return;
        }
        int n5 = Math.max(1, Math.round(32.0f * cyou.rimuru.shootingstardemo.client.magic.a.c(d2)));
        guiGraphicsExtractor.fill(n2, n3 + 32 - n5, n2 + 64, n3 + 32, -1710947830);
        guiGraphicsExtractor.fill(n2, n3 + 32 - n5, n2 + 64, n3 + 32 - n5 + 1, d.a(192, d2.d()));
        String string = (n4 + 19) / 20 + "s";
        guiGraphicsExtractor.text(font, string, n2 + (64 - font.width(string)) / 2 + 1, n3 + 12 + 1, -1, true);
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, Font font, String string, int n2, int n3, int n4) {
        int n5 = font.width(string) + 5;
        int n6 = n2 - n5;
        int n7 = n3 - 11;
        guiGraphicsExtractor.fill(n6, n7, n2, n3, -267253224);
        guiGraphicsExtractor.outline(n6, n7, n5, 11, d.a(224, n4));
        guiGraphicsExtractor.text(font, string, n6 + 3, n7 + 2, d.a(255, n4), false);
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4) {
        guiGraphicsExtractor.fill(n2 - 2, n3, n2 + 3, n3 + 1, d.a(255, n4));
        guiGraphicsExtractor.fill(n2 - 1, n3 - 1, n2 + 2, n3 + 2, d.a(255, n4));
        guiGraphicsExtractor.fill(n2, n3 - 2, n2 + 1, n3 + 3, d.a(255, n4));
        guiGraphicsExtractor.fill(n2, n3, n2 + 1, n3 + 1, -2344);
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, int n6) {
        for (int i2 = 0; i2 < 6; ++i2) {
            int n7 = n4 * i2 / 12;
            guiGraphicsExtractor.fill(n2 + n7, n3, n2 + n4 - n7, n3 + 1, d.a(n6 / 6 + n6 * i2 / 12, n5));
        }
    }

    static void b(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, int n6) {
        for (int i2 = 0; i2 < 6; ++i2) {
            int n7 = n4 * i2 / 12;
            guiGraphicsExtractor.fill(n2, n3 + n7, n2 + 1, n3 + n4 - n7, d.a(n6 / 6 + n6 * i2 / 12, n5));
        }
    }
}

