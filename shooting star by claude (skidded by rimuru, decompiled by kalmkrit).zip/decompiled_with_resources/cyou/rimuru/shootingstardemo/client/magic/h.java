/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.InputConstants
 *  com.mojang.blaze3d.platform.InputConstants$Type
 *  net.minecraft.client.KeyMapping
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  net.minecraft.client.gui.screens.DeathScreen
 *  net.minecraft.client.input.KeyEvent
 *  net.minecraft.client.input.MouseButtonEvent
 *  net.minecraft.client.input.MouseButtonInfo
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.client.resources.sounds.SimpleSoundInstance
 *  net.minecraft.client.resources.sounds.SoundInstance
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.util.Mth
 *  net.minecraft.util.Util
 *  net.minecraft.util.Util$OS
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 *  org.joml.Vector3f
 *  org.joml.Vector3fc
 */
package cyou.rimuru.shootingstardemo.client.magic;

import com.mojang.blaze3d.platform.InputConstants;
import cyou.rimuru.shootingstardemo.client.cinematic.d;
import cyou.rimuru.shootingstardemo.client.magic.f;
import cyou.rimuru.shootingstardemo.client.magic.g;
import cyou.rimuru.shootingstardemo.client.magic.k;
import cyou.rimuru.shootingstardemo.client.magic.l;
import cyou.rimuru.shootingstardemo.magic.e;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public final class h {
    static final int a = 10;
    static final int b = 8;
    static final int c = 14;
    static final int d = 13;
    static final int e = 8;
    static final int f = 5;
    static final List<cyou.rimuru.shootingstardemo.magic.b> g = new ArrayList<cyou.rimuru.shootingstardemo.magic.b>();
    static final List<ItemStack> h = new ArrayList<ItemStack>();
    static boolean[] i = new boolean[0];
    static b j = cyou.rimuru.shootingstardemo.client.magic.h$b.a;
    static int k;
    static int l;
    static float m;
    static float n;
    static float o;
    static float p;
    static int q;
    static float r;
    static float s;
    static int t;
    static float u;
    static a v;
    static a w;
    static cyou.rimuru.shootingstardemo.magic.d x;
    static String y;
    private static String O;
    private static int P;
    static final Map<String, float[]> z;
    static String A;
    static int B;
    static String C;
    static int D;
    private static int Q;
    static String E;
    static int F;
    static String G;
    private static final float[] R;
    private static final float[] S;
    private static final float[] T;
    private static double U;
    private static String V;
    static int H;
    private static int W;
    static float I;
    static float J;
    static float K;
    static float L;
    static boolean M;
    private static double X;
    private static int Y;
    private static ClientLevel Z;
    private static LocalPlayer aa;
    private static float ab;
    private static int ac;
    private static boolean ad;
    static float N;
    private static final float ae = 55.0f;
    private static final float af = 45.0f;

    private h() {
    }

    public static boolean a() {
        return j == cyou.rimuru.shootingstardemo.client.magic.h$b.b || j == cyou.rimuru.shootingstardemo.client.magic.h$b.c;
    }

    public static boolean b() {
        return j != cyou.rimuru.shootingstardemo.client.magic.h$b.a;
    }

    public static boolean c() {
        return j == cyou.rimuru.shootingstardemo.client.magic.h$b.c || j == cyou.rimuru.shootingstardemo.client.magic.h$b.d && k - l < 3;
    }

    public static void a(Minecraft minecraft) {
        LocalPlayer localPlayer = minecraft.player;
        if (localPlayer == null || j != cyou.rimuru.shootingstardemo.client.magic.h$b.a || localPlayer.isDeadOrDying()) {
            return;
        }
        cyou.rimuru.shootingstardemo.client.magic.h.f();
        cyou.rimuru.shootingstardemo.client.magic.h.b(localPlayer);
        j = cyou.rimuru.shootingstardemo.client.magic.h$b.b;
        k = 0;
        l = 0;
        m = localPlayer.getYRot();
        n = localPlayer.getXRot();
        Z = minecraft.level;
        aa = localPlayer;
        ab = localPlayer.getHealth();
        ac = localPlayer.hurtTime;
        q = cyou.rimuru.shootingstardemo.client.magic.h.c(localPlayer);
        r = 13.0f;
        s = 13.0f;
        t = -1;
        v = null;
        w = null;
        x = null;
        y = null;
        O = null;
        z.clear();
        A = null;
        C = null;
        E = null;
        G = null;
        cyou.rimuru.shootingstardemo.client.magic.h.R[1] = cyou.rimuru.shootingstardemo.client.cinematic.d.b() ? 1.0f : 0.0f;
        cyou.rimuru.shootingstardemo.client.magic.h.R[0] = cyou.rimuru.shootingstardemo.client.magic.h.R[1];
        cyou.rimuru.shootingstardemo.client.magic.h.S[1] = cyou.rimuru.shootingstardemo.client.cinematic.d.d() ? 1.0f : 0.0f;
        cyou.rimuru.shootingstardemo.client.magic.h.S[0] = cyou.rimuru.shootingstardemo.client.magic.h.S[1];
        cyou.rimuru.shootingstardemo.client.magic.h.T[1] = cyou.rimuru.shootingstardemo.client.cinematic.d.b() ? 1.0f : 0.0f;
        cyou.rimuru.shootingstardemo.client.magic.h.T[0] = cyou.rimuru.shootingstardemo.client.magic.h.T[1];
        Q = -1;
        K = 0.0f;
        J = 0.0f;
        I = 0.0f;
        Y = -100;
        X = 0.0;
        M = true;
        cyou.rimuru.shootingstardemo.client.magic.k.a();
        KeyMapping.releaseAll();
        ad = minecraft.gui.hud.isHidden();
        minecraft.gui.hud.isHidden = false;
        cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.Q, 1.0f, 0.65f);
    }

    static void d() {
        if (!cyou.rimuru.shootingstardemo.client.magic.h.a()) {
            return;
        }
        cyou.rimuru.shootingstardemo.client.magic.h.o();
        j = cyou.rimuru.shootingstardemo.client.magic.h$b.d;
        l = k;
        x = null;
        G = null;
        cyou.rimuru.shootingstardemo.client.magic.g.a();
        cyou.rimuru.shootingstardemo.client.magic.h.p();
        cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.R, 1.0f, 0.6f);
    }

    private static void a(LocalPlayer localPlayer) {
        cyou.rimuru.shootingstardemo.client.magic.h.o();
        j = cyou.rimuru.shootingstardemo.client.magic.h$b.e;
        l = k;
        x = null;
        G = null;
        cyou.rimuru.shootingstardemo.client.magic.g.a();
        float f2 = localPlayer.getHurtDir();
        N = Mth.clamp((float)((float)(-Math.sin(Math.toRadians(f2)))), (float)-1.0f, (float)1.0f) * 0.5f;
        cyou.rimuru.shootingstardemo.client.magic.h.p();
        cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.Z, 1.0f, 0.85f);
    }

    public static void e() {
        boolean bl = j != cyou.rimuru.shootingstardemo.client.magic.h$b.a;
        j = cyou.rimuru.shootingstardemo.client.magic.h$b.a;
        v = null;
        w = null;
        x = null;
        G = null;
        cyou.rimuru.shootingstardemo.client.magic.g.a();
        Z = null;
        aa = null;
        if (bl) {
            Minecraft.getInstance().gui.hud.isHidden = ad;
        }
    }

    private static void c(Minecraft minecraft) {
        j = cyou.rimuru.shootingstardemo.client.magic.h$b.a;
        G = null;
        cyou.rimuru.shootingstardemo.client.magic.g.a();
        v = null;
        w = null;
        Z = null;
        aa = null;
        KeyMapping.restoreToggleStatesOnScreenClosed();
        minecraft.gui.hud.isHidden = ad;
    }

    private static void o() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            o = Mth.wrapDegrees((float)(minecraft.player.getViewYRot(1.0f) - m));
            p = minecraft.player.getViewXRot(1.0f);
        }
    }

    private static void p() {
        LocalPlayer localPlayer = Minecraft.getInstance().player;
        if (localPlayer == null) {
            return;
        }
        localPlayer.setYRot(m);
        localPlayer.setXRot(n);
        localPlayer.yRotO = m;
        localPlayer.xRotO = n;
        localPlayer.yHeadRot = m;
        localPlayer.yHeadRotO = m;
        localPlayer.yBob = m;
        localPlayer.yBobO = m;
        localPlayer.xBob = n;
        localPlayer.xBobO = n;
    }

    public static void b(Minecraft minecraft) {
        if (j == cyou.rimuru.shootingstardemo.client.magic.h$b.a) {
            return;
        }
        LocalPlayer localPlayer = minecraft.player;
        if (localPlayer == null || localPlayer != aa || minecraft.level != Z) {
            cyou.rimuru.shootingstardemo.client.magic.h.e();
            return;
        }
        ++k;
        for (Map.Entry<String, float[]> entry : z.entrySet()) {
            float[] fArray2 = entry.getValue();
            fArray2[0] = fArray2[1];
            float f2 = entry.getKey().equals(y) && cyou.rimuru.shootingstardemo.client.magic.h.a() ? 1.0f : 0.0f;
            fArray2[1] = fArray2[1] + (f2 - fArray2[1]) * 0.5f;
        }
        if (y != null && cyou.rimuru.shootingstardemo.client.magic.h.a()) {
            z.computeIfAbsent(y, string -> new float[2]);
        }
        z.values().removeIf(fArray -> fArray[0] < 0.002f && fArray[1] < 0.002f && !cyou.rimuru.shootingstardemo.client.magic.h.a());
        cyou.rimuru.shootingstardemo.client.magic.h.R[0] = R[1];
        R[1] = R[1] + ((cyou.rimuru.shootingstardemo.client.cinematic.d.b() ? 1.0f : 0.0f) - R[1]) * 0.6f;
        cyou.rimuru.shootingstardemo.client.magic.h.S[0] = S[1];
        S[1] = S[1] + ((cyou.rimuru.shootingstardemo.client.cinematic.d.d() ? 1.0f : 0.0f) - S[1]) * 0.6f;
        cyou.rimuru.shootingstardemo.client.magic.h.T[0] = T[1];
        T[1] = T[1] + ((cyou.rimuru.shootingstardemo.client.cinematic.d.b() ? 1.0f : 0.0f) - T[1]) * 0.45f;
        J = I;
        I += (K - I) * 0.45f;
        if (Math.abs(K - I) < 0.05f) {
            I = K;
        }
        cyou.rimuru.shootingstardemo.client.magic.h.b(localPlayer);
        if (G != null && !minecraft.isWindowActive()) {
            cyou.rimuru.shootingstardemo.client.magic.h.a(0);
        }
        if (cyou.rimuru.shootingstardemo.client.magic.h.a()) {
            boolean bl;
            boolean bl2 = bl = localPlayer.hurtTime > ac || localPlayer.getHealth() < ab - 0.01f || localPlayer.isDeadOrDying();
            if (bl || minecraft.gui.screen() instanceof DeathScreen) {
                cyou.rimuru.shootingstardemo.client.magic.h.a(localPlayer);
            } else if (minecraft.gui.screen() != null) {
                cyou.rimuru.shootingstardemo.client.magic.h.d();
            } else if (Q >= 0 && k >= Q) {
                cyou.rimuru.shootingstardemo.client.magic.h.d();
            }
        }
        ab = localPlayer.getHealth();
        ac = localPlayer.hurtTime;
        if (y != null && !y.equals(O) && cyou.rimuru.shootingstardemo.client.magic.h.a() && k - P >= 2 && !y.equals("info")) {
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.S, 1.0f, 0.25f);
            P = k;
        }
        O = y;
        if (q >= 0 && cyou.rimuru.shootingstardemo.client.magic.h.a() && k == (int)Math.ceil(r)) {
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.T, 1.0f, 0.45f);
        }
        if (w != null && k - cyou.rimuru.shootingstardemo.client.magic.h.w.j >= 5) {
            w = null;
        }
        if (j == cyou.rimuru.shootingstardemo.client.magic.h$b.b && k - l >= 10) {
            j = cyou.rimuru.shootingstardemo.client.magic.h$b.c;
            l = k;
        } else if (j == cyou.rimuru.shootingstardemo.client.magic.h$b.d && k - l >= 8 || j == cyou.rimuru.shootingstardemo.client.magic.h$b.e && k - l >= 14) {
            cyou.rimuru.shootingstardemo.client.magic.h.c(minecraft);
        }
    }

    public static void a(KeyEvent keyEvent) {
        if (!cyou.rimuru.shootingstardemo.client.magic.h.a()) {
            return;
        }
        if (x != null) {
            if (keyEvent.key() == 42 || keyEvent.key() == 76) {
                cyou.rimuru.shootingstardemo.client.magic.f.a(x, InputConstants.UNKNOWN);
                cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.X, 0.8f, 0.45f);
            } else if (!keyEvent.isEscape()) {
                cyou.rimuru.shootingstardemo.client.magic.f.a(x, InputConstants.getKey((KeyEvent)keyEvent));
                cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.X, 1.0f, 0.45f);
            }
            x = null;
            return;
        }
        if (C != null) {
            return;
        }
        if (keyEvent.isEscape()) {
            if (v != null) {
                cyou.rimuru.shootingstardemo.client.magic.h.q();
            } else {
                cyou.rimuru.shootingstardemo.client.magic.h.d();
            }
            return;
        }
        if (cyou.rimuru.shootingstardemo.client.magic.f.a.matches(keyEvent)) {
            cyou.rimuru.shootingstardemo.client.magic.h.d();
            return;
        }
        if (cyou.rimuru.shootingstardemo.client.magic.h.a(y) && v == null && (keyEvent.key() == 80 || keyEvent.key() == 79)) {
            cyou.rimuru.shootingstardemo.client.magic.h.a(y, keyEvent.key() == 79 ? 1 : -1);
            return;
        }
        if (L > 0.0f && v == null && (keyEvent.key() == 82 || keyEvent.key() == 81)) {
            cyou.rimuru.shootingstardemo.client.magic.h.c(keyEvent.key() == 81 ? 1 : -1);
            return;
        }
        if (L > 0.0f && v == null && (keyEvent.key() == 75 || keyEvent.key() == 78)) {
            int n2 = cyou.rimuru.shootingstardemo.client.magic.k.a(K);
            cyou.rimuru.shootingstardemo.client.magic.h.c(keyEvent.key() == 78 ? n2 : -n2);
            return;
        }
        if (q >= 0) {
            for (cyou.rimuru.shootingstardemo.magic.d d2 : cyou.rimuru.shootingstardemo.client.magic.h.b((int)cyou.rimuru.shootingstardemo.client.magic.h.q).c) {
                KeyMapping keyMapping = cyou.rimuru.shootingstardemo.client.magic.f.a(d2);
                if (keyMapping == null || !keyMapping.matches(keyEvent)) continue;
                cyou.rimuru.shootingstardemo.client.magic.h.a(d2, "skill:" + d2.a());
                return;
            }
        }
    }

    public static void a(MouseButtonInfo mouseButtonInfo) {
        String string;
        if (!cyou.rimuru.shootingstardemo.client.magic.h.a()) {
            return;
        }
        int n2 = mouseButtonInfo.button();
        if (n2 == 1 && Util.getPlatform() == Util.OS.OSX && (mouseButtonInfo.modifiers() & 0xC0) != 0) {
            n2 = 3;
        }
        if (x != null) {
            if (n2 > 3) {
                cyou.rimuru.shootingstardemo.client.magic.f.a(x, InputConstants.Type.MOUSE.getOrCreate(n2));
                cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.X, 1.0f, 0.45f);
            }
            x = null;
            return;
        }
        if (C != null) {
            return;
        }
        if (cyou.rimuru.shootingstardemo.client.magic.f.a.matchesMouse(new MouseButtonEvent(0.0, 0.0, mouseButtonInfo))) {
            cyou.rimuru.shootingstardemo.client.magic.h.d();
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        y = string = cyou.rimuru.shootingstardemo.client.magic.k.a(minecraft.getWindow().getGuiScaledWidth(), minecraft.getWindow().getGuiScaledHeight(), 1.0f);
        A = string;
        B = k;
        if (n2 == 1) {
            cyou.rimuru.shootingstardemo.client.magic.h.e(string);
        } else if (n2 == 3) {
            cyou.rimuru.shootingstardemo.client.magic.h.f(string);
        }
    }

    private static void e(String string) {
        if (string == null) {
            if (v != null) {
                cyou.rimuru.shootingstardemo.client.magic.h.q();
            }
            return;
        }
        if (string.equals("switch:cutscenes")) {
            boolean bl = !cyou.rimuru.shootingstardemo.client.cinematic.d.b();
            cyou.rimuru.shootingstardemo.client.cinematic.d.a(bl);
            cyou.rimuru.shootingstardemo.client.magic.h.a(bl ? cyou.rimuru.shootingstardemo.registry.g.X : cyou.rimuru.shootingstardemo.registry.g.W, bl ? 1.2f : 0.9f, 0.4f);
            return;
        }
        if (string.equals("switch:everyone")) {
            boolean bl = !cyou.rimuru.shootingstardemo.client.cinematic.d.d();
            cyou.rimuru.shootingstardemo.client.cinematic.d.b(bl);
            cyou.rimuru.shootingstardemo.client.magic.h.a(bl ? cyou.rimuru.shootingstardemo.registry.g.X : cyou.rimuru.shootingstardemo.registry.g.W, bl ? 1.2f : 0.9f, 0.4f);
            return;
        }
        if (cyou.rimuru.shootingstardemo.client.magic.h.a(string)) {
            G = string;
            cyou.rimuru.shootingstardemo.client.magic.h.d(cyou.rimuru.shootingstardemo.client.magic.k.a(string, Minecraft.getInstance().getWindow().getGuiScaledWidth(), Minecraft.getInstance().getWindow().getGuiScaledHeight(), 1.0f));
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.W, 1.3f, 0.3f);
            return;
        }
        if (string.startsWith("item:")) {
            int n2 = cyou.rimuru.shootingstardemo.client.magic.h.c(string.substring(5));
            if (n2 < 0 || n2 == q && t != n2) {
                return;
            }
            cyou.rimuru.shootingstardemo.client.magic.h.d(n2);
        } else if (string.startsWith("skill:")) {
            cyou.rimuru.shootingstardemo.client.magic.b b2 = cyou.rimuru.shootingstardemo.client.magic.b.a(string.substring(6));
            if (b2 != null) {
                E = string;
                F = k;
                cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.Y, 1.0f, 0.35f);
                cyou.rimuru.shootingstardemo.client.magic.h.a(b2, q, string);
                return;
            }
            cyou.rimuru.shootingstardemo.magic.d d2 = cyou.rimuru.shootingstardemo.client.magic.h.g(string.substring(6));
            if (d2 != null) {
                cyou.rimuru.shootingstardemo.client.magic.h.a(d2, string);
            }
        } else if (string.equals("info:setkey") && cyou.rimuru.shootingstardemo.client.magic.h.r()) {
            x = cyou.rimuru.shootingstardemo.client.magic.h.v.a;
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.W, 1.0f, 0.45f);
        } else if (string.equals("info:select") && cyou.rimuru.shootingstardemo.client.magic.h.r()) {
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.client.magic.h.v.a, string);
        } else if (string.equals("info:close")) {
            cyou.rimuru.shootingstardemo.client.magic.h.q();
        }
    }

    private static void f(String string) {
        if (string == null) {
            if (v != null) {
                cyou.rimuru.shootingstardemo.client.magic.h.q();
            }
            return;
        }
        if (string.startsWith("item:")) {
            int n2 = cyou.rimuru.shootingstardemo.client.magic.h.c(string.substring(5));
            if (n2 >= 0) {
                cyou.rimuru.shootingstardemo.client.magic.h.a(null, n2, string);
            }
        } else if (string.startsWith("skill:")) {
            cyou.rimuru.shootingstardemo.client.magic.b b2;
            cyou.rimuru.shootingstardemo.client.magic.b b3 = cyou.rimuru.shootingstardemo.client.magic.b.a(string.substring(6));
            cyou.rimuru.shootingstardemo.magic.d d2 = b2 = b3 != null ? b3 : cyou.rimuru.shootingstardemo.client.magic.h.g(string.substring(6));
            if (b2 != null) {
                cyou.rimuru.shootingstardemo.client.magic.h.a(b2, q, string);
            }
        }
    }

    public static void a(int n2) {
        if (G != null && n2 == 0) {
            G = null;
            cyou.rimuru.shootingstardemo.client.magic.g.a();
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.X, 1.2f, 0.3f);
        }
    }

    public static void a(double d2) {
        if (cyou.rimuru.shootingstardemo.client.magic.h.a() && G == null && v == null && L > 0.0f && (!cyou.rimuru.shootingstardemo.client.magic.h.a(y) || k - Y < 10)) {
            int n2 = (int)(X += d2);
            X -= (double)n2;
            if (n2 != 0) {
                cyou.rimuru.shootingstardemo.client.magic.h.c(-n2);
            }
            return;
        }
        if (!(cyou.rimuru.shootingstardemo.client.magic.h.a() && G == null && v == null && cyou.rimuru.shootingstardemo.client.magic.h.a(y) && y.equals(V))) {
            U = 0.0;
            V = y;
        }
        if (!cyou.rimuru.shootingstardemo.client.magic.h.a() || G != null || v != null || !cyou.rimuru.shootingstardemo.client.magic.h.a(y)) {
            return;
        }
        int n3 = (int)(U += d2);
        U -= (double)n3;
        for (int i2 = 0; i2 < Math.min(Math.abs(n3), 5); ++i2) {
            cyou.rimuru.shootingstardemo.client.magic.h.a(y, n3 > 0 ? 1 : -1);
        }
    }

    private static void c(int n2) {
        Y = k;
        float f2 = cyou.rimuru.shootingstardemo.client.magic.k.a(K, n2);
        if (f2 != K) {
            K = f2;
            if (k - W >= 1) {
                cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.S, 1.0f, 0.18f);
                W = k;
            }
        }
    }

    static float a(float f2) {
        return Mth.lerp((float)f2, (float)R[0], (float)R[1]);
    }

    static float b(float f2) {
        return Mth.lerp((float)f2, (float)S[0], (float)S[1]);
    }

    static float c(float f2) {
        return Mth.lerp((float)f2, (float)T[0], (float)T[1]);
    }

    static boolean a(String string) {
        return string != null && (string.startsWith("power:") || string.startsWith("damage:") || string.startsWith("speed:"));
    }

    static cyou.rimuru.shootingstardemo.magic.d b(String string) {
        return cyou.rimuru.shootingstardemo.client.magic.h.g(string.substring(string.indexOf(58) + 1));
    }

    static void d(float f2) {
        boolean bl;
        if (G == null || Float.isNaN(f2)) {
            return;
        }
        cyou.rimuru.shootingstardemo.magic.d d2 = cyou.rimuru.shootingstardemo.client.magic.h.b(G);
        if (d2 == null || d2.j() == null) {
            return;
        }
        boolean bl2 = G.startsWith("power:") ? cyou.rimuru.shootingstardemo.client.magic.g.b(d2, d2.j().c(f2)) : (bl = G.startsWith("speed:") ? cyou.rimuru.shootingstardemo.client.magic.g.a(d2, cyou.rimuru.shootingstardemo.magic.f.d.c(f2)) : cyou.rimuru.shootingstardemo.client.magic.g.a(d2, Math.round(f2 * (float)(cyou.rimuru.shootingstardemo.magic.f.b.length - 1))));
        if (bl) {
            cyou.rimuru.shootingstardemo.client.magic.h.g(f2);
        }
    }

    private static void a(String string, int n2) {
        cyou.rimuru.shootingstardemo.magic.d d2 = cyou.rimuru.shootingstardemo.client.magic.h.b(string);
        if (d2 == null || d2.j() == null) {
            return;
        }
        boolean bl = string.startsWith("power:") ? cyou.rimuru.shootingstardemo.client.magic.g.b(d2, d2.j().a(cyou.rimuru.shootingstardemo.client.magic.g.b(d2), n2)) : (string.startsWith("speed:") ? cyou.rimuru.shootingstardemo.client.magic.g.a(d2, cyou.rimuru.shootingstardemo.magic.f.d.a(cyou.rimuru.shootingstardemo.client.magic.g.e(d2), n2)) : cyou.rimuru.shootingstardemo.client.magic.g.a(d2, cyou.rimuru.shootingstardemo.magic.f.a(cyou.rimuru.shootingstardemo.client.magic.g.d(d2)) + n2));
        if (bl) {
            cyou.rimuru.shootingstardemo.client.magic.h.g(cyou.rimuru.shootingstardemo.client.magic.k.b(string));
            cyou.rimuru.shootingstardemo.client.magic.g.a();
        }
    }

    private static void g(float f2) {
        H = k;
        if (k - W >= 1) {
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.S, 0.8f + 0.8f * Mth.clamp((float)f2, (float)0.0f, (float)1.0f), 0.22f);
            W = k;
        }
    }

    private static void d(int n2) {
        float f2 = k;
        t = q;
        u = f2;
        q = n2;
        r = f2;
        s = t >= 0 ? f2 + 3.0f : f2;
        K = 0.0f;
        J = 0.0f;
        I = 0.0f;
    }

    private static void a(cyou.rimuru.shootingstardemo.magic.d d2, String string) {
        int n2 = g.indexOf((Object)cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.magic.e.b(d2)));
        if (n2 < 0 || !i[n2]) {
            E = string;
            F = k;
            cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.Y, 1.0f, 0.5f);
            return;
        }
        cyou.rimuru.shootingstardemo.client.magic.a.a(d2);
        C = string;
        D = k;
        Q = k + 4;
    }

    private static void a(cyou.rimuru.shootingstardemo.magic.d d2, int n2, String string) {
        l.a a2 = cyou.rimuru.shootingstardemo.client.magic.k.a(string);
        Vector3f vector3f = a2 != null ? new Vector3f((Vector3fc)a2.b) : cyou.rimuru.shootingstardemo.client.magic.l.a(0.0f, 0.0f, 1.88f);
        int n3 = a2 != null ? a2.e : 40;
        int n4 = a2 != null ? a2.f : 20;
        Minecraft minecraft = Minecraft.getInstance();
        float f2 = Mth.wrapDegrees((float)(minecraft.player.getViewYRot(1.0f) - m));
        float f3 = minecraft.player.getViewXRot(1.0f);
        float f4 = Mth.clamp((float)(f2 * 0.7f), (float)-24.0f, (float)24.0f) / 0.17f;
        float f5 = Mth.clamp((float)(-f3 * 0.7f), (float)-10.0f, (float)10.0f) / 0.17f;
        if (v != null) {
            cyou.rimuru.shootingstardemo.client.magic.h.v.j = k;
            w = v;
        }
        v = new a(d2, n2, string, vector3f, n3, n4, f4, f5, k);
        cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.U, 1.0f, 0.45f);
    }

    private static void q() {
        if (v == null) {
            return;
        }
        cyou.rimuru.shootingstardemo.client.magic.h.v.j = k;
        w = v;
        v = null;
        x = null;
        cyou.rimuru.shootingstardemo.client.magic.h.a(cyou.rimuru.shootingstardemo.registry.g.V, 1.0f, 0.4f);
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2) {
        if (j == cyou.rimuru.shootingstardemo.client.magic.h$b.a) {
            return;
        }
        cyou.rimuru.shootingstardemo.client.magic.k.a(guiGraphicsExtractor, f2);
    }

    static float[] e(float f2) {
        LocalPlayer localPlayer = Minecraft.getInstance().player;
        if (!cyou.rimuru.shootingstardemo.client.magic.h.a() || localPlayer == null) {
            return new float[]{o, p};
        }
        return new float[]{Mth.wrapDegrees((float)(localPlayer.getViewYRot(f2) - m)), localPlayer.getViewXRot(f2)};
    }

    public static double[] a(double d2, double d3) {
        float f2;
        double d4;
        LocalPlayer localPlayer = Minecraft.getInstance().player;
        if (localPlayer == null || !cyou.rimuru.shootingstardemo.client.magic.h.a()) {
            return new double[]{d2, d3};
        }
        float f3 = Mth.wrapDegrees((float)(localPlayer.getYRot() - m));
        double d5 = (double)f3 + d2 * 0.15;
        double d6 = Math.sqrt(d5 * d5 / 3025.0 + (d4 = (double)(f2 = localPlayer.getXRot()) + d3 * 0.15) * d4 / 2025.0);
        if (d6 > 1.0) {
            d5 /= d6;
            d4 /= d6;
        }
        return new double[]{(d5 - (double)f3) / 0.15, (d4 - (double)f2) / 0.15};
    }

    static float a(String string, float f2) {
        float[] fArray = z.get(string);
        return fArray == null ? 0.0f : Mth.lerp((float)f2, (float)fArray[0], (float)fArray[1]);
    }

    static List<cyou.rimuru.shootingstardemo.magic.b> f() {
        if (g.isEmpty()) {
            for (Item item : BuiltInRegistries.ITEM) {
                if (!(item instanceof cyou.rimuru.shootingstardemo.magic.b)) continue;
                cyou.rimuru.shootingstardemo.magic.b b2 = (cyou.rimuru.shootingstardemo.magic.b)item;
                g.add(b2);
                h.add(new ItemStack((ItemLike)b2));
            }
            i = new boolean[g.size()];
        }
        return g;
    }

    static e b(int n2) {
        return cyou.rimuru.shootingstardemo.client.magic.h.g.get((int)n2).d;
    }

    private static cyou.rimuru.shootingstardemo.magic.b a(e e2) {
        for (cyou.rimuru.shootingstardemo.magic.b b2 : g) {
            if (b2.d != e2) continue;
            return b2;
        }
        return null;
    }

    static int c(String string) {
        for (int i2 = 0; i2 < g.size(); ++i2) {
            if (!cyou.rimuru.shootingstardemo.client.magic.h.b((int)i2).a.getPath().equals(string)) continue;
            return i2;
        }
        return -1;
    }

    private static boolean r() {
        return v != null && cyou.rimuru.shootingstardemo.client.magic.h.v.a != null && !(cyou.rimuru.shootingstardemo.client.magic.h.v.a instanceof cyou.rimuru.shootingstardemo.client.magic.b);
    }

    private static cyou.rimuru.shootingstardemo.magic.d g(String string) {
        if (q < 0) {
            return null;
        }
        for (cyou.rimuru.shootingstardemo.magic.d d2 : cyou.rimuru.shootingstardemo.client.magic.h.b((int)cyou.rimuru.shootingstardemo.client.magic.h.q).c) {
            if (!d2.a().equals(string)) continue;
            return d2;
        }
        return null;
    }

    private static void b(LocalPlayer localPlayer) {
        Arrays.fill(i, false);
        for (int i2 = 0; i2 < localPlayer.getInventory().getContainerSize(); ++i2) {
            cyou.rimuru.shootingstardemo.magic.b b2;
            int n2;
            ItemStack itemStack = localPlayer.getInventory().getItem(i2);
            Item item = itemStack.getItem();
            if (!(item instanceof cyou.rimuru.shootingstardemo.magic.b) || (n2 = g.indexOf((Object)(b2 = (cyou.rimuru.shootingstardemo.magic.b)item))) < 0) continue;
            cyou.rimuru.shootingstardemo.client.magic.h.i[n2] = true;
        }
    }

    private static int c(LocalPlayer localPlayer) {
        for (ItemStack itemStack : new ItemStack[]{localPlayer.getMainHandItem(), localPlayer.getOffhandItem()}) {
            cyou.rimuru.shootingstardemo.magic.b b2;
            Item item = itemStack.getItem();
            if (!(item instanceof cyou.rimuru.shootingstardemo.magic.b) || !g.contains((Object)(b2 = (cyou.rimuru.shootingstardemo.magic.b)item))) continue;
            return g.indexOf((Object)b2);
        }
        for (int i2 = 0; i2 < g.size(); ++i2) {
            if (!i[i2]) continue;
            return i2;
        }
        return 0;
    }

    static void a(SoundEvent soundEvent, float f2, float f3) {
        Minecraft.getInstance().getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)soundEvent, (float)f2, (float)f3));
    }

    public static float[] d(String string) {
        Vector3f vector3f = cyou.rimuru.shootingstardemo.client.magic.k.c(string);
        if (vector3f == null) {
            return null;
        }
        float[] fArray = cyou.rimuru.shootingstardemo.client.magic.l.a(vector3f);
        return new float[]{m + fArray[0], fArray[1]};
    }

    public static float[] b(String string, float f2) {
        Vector3f vector3f = cyou.rimuru.shootingstardemo.client.magic.k.a(string, f2);
        if (vector3f == null) {
            return null;
        }
        float[] fArray = cyou.rimuru.shootingstardemo.client.magic.l.a(vector3f);
        return new float[]{m + fArray[0], fArray[1]};
    }

    public static String g() {
        return G;
    }

    public static String h() {
        return y;
    }

    public static e i() {
        return q >= 0 && q < g.size() ? cyou.rimuru.shootingstardemo.client.magic.h.b(q) : null;
    }

    public static cyou.rimuru.shootingstardemo.magic.d j() {
        return v == null ? null : cyou.rimuru.shootingstardemo.client.magic.h.v.a;
    }

    public static cyou.rimuru.shootingstardemo.magic.d k() {
        return x;
    }

    public static String l() {
        return j.name();
    }

    public static float m() {
        return L;
    }

    public static float n() {
        return I;
    }

    public static void f(float f2) {
        cyou.rimuru.shootingstardemo.client.magic.k.o = f2;
    }

    static {
        q = -1;
        t = -1;
        P = -10;
        z = new HashMap<String, float[]>();
        B = -100;
        D = -100;
        Q = -1;
        F = -100;
        R = new float[2];
        S = new float[2];
        T = new float[2];
        H = -100;
        W = -10;
        Y = -100;
    }

    static final class b
    extends Enum<b> {
        public static final /* enum */ b a = new b();
        public static final /* enum */ b b = new b();
        public static final /* enum */ b c = new b();
        public static final /* enum */ b d = new b();
        public static final /* enum */ b e = new b();
        private static final /* synthetic */ b[] f;

        public static b[] values() {
            return (b[])f.clone();
        }

        public static b valueOf(String string) {
            return Enum.valueOf(b.class, string);
        }

        private static /* synthetic */ b[] a() {
            return new b[]{a, b, c, d, e};
        }

        static {
            f = cyou.rimuru.shootingstardemo.client.magic.h$b.a();
        }
    }

    static final class a {
        final cyou.rimuru.shootingstardemo.magic.d a;
        final int b;
        final String c;
        final Vector3f d;
        final int e;
        final int f;
        final float g;
        final float h;
        final int i;
        int j = -1;

        a(cyou.rimuru.shootingstardemo.magic.d d2, int n2, String string, Vector3f vector3f, int n3, int n4, float f2, float f3, int n5) {
            this.a = d2;
            this.b = n2;
            this.c = string;
            this.d = vector3f;
            this.e = n3;
            this.f = n4;
            this.g = f2;
            this.h = f3;
            this.i = n5;
        }
    }
}

