/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.renderpearl.api.pipeline.RenderPipeline
 *  com.mojang.renderpearl.api.pipeline.RenderPipeline$Snippet
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  net.minecraft.client.renderer.RenderPipelines
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.FontDescription
 *  net.minecraft.network.chat.FontDescription$Resource
 *  net.minecraft.network.chat.MutableComponent
 *  net.minecraft.resources.Identifier
 *  net.minecraft.util.Mth
 */
package cyou.rimuru.shootingstardemo.client.magic;

import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import cyou.rimuru.shootingstardemo.client.magic.j;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public final class c {
    public static final int a = 0xFFFFFF;
    public static final int b = 0xFBFBFC;
    public static final int c = 15659251;
    public static final int d = 13225686;
    public static final int e = 3883080;
    public static final int f = 9080985;
    public static final int g = 11909826;
    public static final int h = 16037439;
    public static final int i = 16774364;
    public static final int j = 1712688;
    public static final int k = 3055195;
    public static final int l = 14239816;
    public static final int m = 0xF2F8FF;
    public static final int n = 0;
    public static final int o = 1;
    public static final int p = 2;
    public static final int q = 3;
    public static final int r = 0;
    public static final int s = 1;
    public static final int t = 2;
    public static final int u = 3;
    public static final int v = 4;
    public static final int w = 1;
    public static final int x = 2;
    public static final int y = 64;
    private static final int[] D = new int[]{10, 15, 20, 25, 30, 40, 50};
    private static final FontDescription[] E = cyou.rimuru.shootingstardemo.client.magic.c.e("text");
    private static final FontDescription[] F = cyou.rimuru.shootingstardemo.client.magic.c.e("caption");
    private static final FontDescription[] G = cyou.rimuru.shootingstardemo.client.magic.c.e("title");
    private static int H = 2;
    private static final Identifier I = Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"textures/gui/white_space_noise.png");
    private static final RenderPipeline J = RenderPipelines.register((RenderPipeline)RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[]{RenderPipelines.GUI_TEXTURED_SNIPPET}).withLocation(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"pipeline/white_space")).withVertexShader(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"core/white_space")).withFragmentShader(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"core/white_space")).build());
    private static final int K = 0;
    private static final int L = 1;
    private static final int M = 2;
    private static final int N = 3;
    private static final int O = 4;
    private static final int P = 5;
    private static final int Q = 6;
    private static final int R = 7;
    public static final int z = 4;
    public static final int A = 1;
    public static final int B = 2;
    public static final int C = 4;

    private c() {
    }

    public static void a() {
    }

    private static FontDescription[] e(String string) {
        FontDescription[] fontDescriptionArray = new FontDescription[D.length];
        for (int i2 = 0; i2 < D.length; ++i2) {
            fontDescriptionArray[i2] = new FontDescription.Resource(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)("white_space_" + string + "_" + D[i2])));
        }
        return fontDescriptionArray;
    }

    public static void a(float f2) {
        H = cyou.rimuru.shootingstardemo.client.magic.c.b(f2);
    }

    private static int b(float f2) {
        int n2 = 0;
        for (int i2 = 1; i2 < D.length; ++i2) {
            if (!(Math.abs((float)D[i2] / 10.0f - f2) < Math.abs((float)D[n2] / 10.0f - f2))) continue;
            n2 = i2;
        }
        return n2;
    }

    public static MutableComponent a(Component component, float f2) {
        int n2 = cyou.rimuru.shootingstardemo.client.magic.c.b(f2);
        return component.copy().withStyle(style -> style.withFont(F[n2]));
    }

    public static MutableComponent a(Component component) {
        return component.copy().withStyle(style -> style.withFont(E[H]));
    }

    public static MutableComponent a(String string) {
        return cyou.rimuru.shootingstardemo.client.magic.c.a((Component)Component.literal((String)string));
    }

    public static MutableComponent b(Component component) {
        return component.copy().withStyle(style -> style.withFont(F[H]));
    }

    public static MutableComponent b(String string) {
        return cyou.rimuru.shootingstardemo.client.magic.c.b((Component)Component.literal((String)string));
    }

    public static MutableComponent c(String string) {
        return Component.literal((String)string).withStyle(style -> style.withFont(G[H]));
    }

    public static String d(String string) {
        String string2 = string.toUpperCase(Locale.ROOT);
        StringBuilder stringBuilder = new StringBuilder();
        for (int i2 = 0; i2 < string2.length(); ++i2) {
            char c2 = string2.charAt(i2);
            stringBuilder.append(c2 == ' ' ? "  " : String.valueOf(c2));
            if (i2 >= string2.length() - 1) continue;
            stringBuilder.append(' ');
        }
        return stringBuilder.toString();
    }

    public static int a(float f2, int n2) {
        return Mth.clamp((int)Math.round(f2 * 255.0f), (int)0, (int)255) << 24 | n2 & 0xFFFFFF;
    }

    public static int a(int n2, int n3, float f2) {
        f2 = Mth.clamp((float)f2, (float)0.0f, (float)1.0f);
        int n4 = Math.round(Mth.lerp((float)f2, (float)(n2 >> 16 & 0xFF), (float)(n3 >> 16 & 0xFF)));
        int n5 = Math.round(Mth.lerp((float)f2, (float)(n2 >> 8 & 0xFF), (float)(n3 >> 8 & 0xFF)));
        int n6 = Math.round(Mth.lerp((float)f2, (float)(n2 & 0xFF), (float)(n3 & 0xFF)));
        return n4 << 16 | n5 << 8 | n6;
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, int n6, float f2, int n7, boolean bl) {
        int n8 = cyou.rimuru.shootingstardemo.client.magic.c.a(n6);
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 0, n7 & 3 | (bl ? 4 : 0), n2, n3, n4, n5, n8 >> 8, n8, cyou.rimuru.shootingstardemo.client.magic.c.c(f2));
    }

    public static void b(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, int n6, float f2, int n7, boolean bl) {
        int n8 = bl ? 16 : 8;
        int n9 = cyou.rimuru.shootingstardemo.client.magic.c.a(n6);
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 1, n7 & 3 | (bl ? 4 : 0), n2 - n8, n3 - n8, n4 + 2 * n8, n5 + 2 * n8, n9 >> 8, n9, cyou.rimuru.shootingstardemo.client.magic.c.c(f2));
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, float f2, int n6) {
        int n7 = cyou.rimuru.shootingstardemo.client.magic.c.a(n5);
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 2, n6, n2, n3, n4, n4, n7 >> 8, n7, cyou.rimuru.shootingstardemo.client.magic.c.c(f2));
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, float f2, float f3) {
        if (f3 <= 0.0f) {
            return;
        }
        int n6 = cyou.rimuru.shootingstardemo.client.magic.c.a(n5);
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 3, cyou.rimuru.shootingstardemo.client.magic.c.d(f3), n2, n3, n4, n4, n6 >> 8, n6, cyou.rimuru.shootingstardemo.client.magic.c.c(f2));
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, float f2, float f3) {
        int n4 = Math.round(Mth.clamp((float)f2, (float)0.0f, (float)1.0f) * 65535.0f);
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 4, 0, 0, 0, n2, n3, n4 >> 8, n4, cyou.rimuru.shootingstardemo.client.magic.c.c(f3));
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, float f2, int n3) {
        int n4 = cyou.rimuru.shootingstardemo.client.magic.c.a(n2);
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 5, n3, 0, 0, 64, 64, n4 >> 8, n4, cyou.rimuru.shootingstardemo.client.magic.c.c(f2));
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2, float f3, float f4, float f5, float f6, boolean bl) {
        int n2 = Mth.clamp((int)Math.round(f2 * 2047.0f), (int)0, (int)2047);
        int n3 = Mth.clamp((int)Math.round(f3 * 2047.0f), (int)0, (int)2047);
        float f7 = Mth.positiveModulo((float)(f4 / ((float)Math.PI * 2) + 0.5f), (float)1.0f);
        int n4 = Mth.clamp((int)Math.round(f7 * 255.0f), (int)0, (int)255);
        int n5 = Mth.clamp((int)Math.round((f5 - 0.8f) / 0.5f * 255.0f), (int)0, (int)255);
        int n6 = cyou.rimuru.shootingstardemo.client.magic.c.c(f6);
        if (n6 <= 0) {
            return;
        }
        int n7 = (0x80 | (4 | (bl ? 1 : 0)) << 4 | 5) << 24 | n4 << 16 | n5 << 8 | n6;
        guiGraphicsExtractor.blit(J, cyou.rimuru.shootingstardemo.client.magic.j.a, 0, 0, 128.0f * ((float)n2 + 0.25f), 128.0f * ((float)n3 + 0.25f), 64, 64, 128, 128, n7);
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, float f2, float f3) {
        if (f3 <= 0.0f) {
            return;
        }
        int n5 = cyou.rimuru.shootingstardemo.client.magic.c.a(n4);
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 6, cyou.rimuru.shootingstardemo.client.magic.c.d(f3), n2 - 12, n3 - 12, 24, 24, n5 >> 8, n5, cyou.rimuru.shootingstardemo.client.magic.c.c(f2));
    }

    public static void b(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, float f2, float f3) {
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, n2, n3, n4, n5, f2, f3, 0);
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, float f2, float f3, int n6) {
        if (f3 <= 0.0f || f2 <= 0.0f) {
            return;
        }
        int n7 = cyou.rimuru.shootingstardemo.client.magic.c.a(cyou.rimuru.shootingstardemo.client.magic.c.a(0xFFFFFF, n5, f3));
        cyou.rimuru.shootingstardemo.client.magic.c.a(guiGraphicsExtractor, 7, n6, n2, n3 - 3, n4, 6, n7 >> 8, n7, cyou.rimuru.shootingstardemo.client.magic.c.c(f2));
    }

    private static int a(int n2) {
        return (n2 >> 19 & 0x1F) << 11 | (n2 >> 10 & 0x3F) << 5 | n2 >> 3 & 0x1F;
    }

    private static int c(float f2) {
        return Mth.clamp((int)Math.round(f2 * 255.0f), (int)0, (int)255);
    }

    private static int d(float f2) {
        return Mth.clamp((int)(Math.round(f2 * 8.0f) - 1), (int)0, (int)7);
    }

    private static void a(GuiGraphicsExtractor guiGraphicsExtractor, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
        if (n6 <= 0 || n7 <= 0 || n2 != 4 && n2 != 3 && n2 != 6 && n2 != 7 && n10 <= 0) {
            return;
        }
        int n11 = (0x80 | (n3 & 7) << 4 | n2) << 24 | (n8 & 0xFF) << 16 | (n9 & 0xFF) << 8 | n10 & 0xFF;
        guiGraphicsExtractor.blit(J, I, n4, n5, 2.0f * (float)n6 * ((float)n6 + 0.25f), 2.0f * (float)n7 * ((float)n7 + 0.25f), n6, n7, 2 * n6, 2 * n7, n11);
    }
}

