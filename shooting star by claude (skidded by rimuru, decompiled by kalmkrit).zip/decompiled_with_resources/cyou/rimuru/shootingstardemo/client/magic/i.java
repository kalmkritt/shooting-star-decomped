/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.renderpearl.api.textures.GpuTexture
 *  net.minecraft.client.renderer.texture.AbstractTexture
 *  net.minecraft.resources.Identifier
 */
package cyou.rimuru.shootingstardemo.client.magic;

import com.mojang.renderpearl.api.textures.GpuTexture;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;

public final class i {
    private static final Set<GpuTexture> a = Collections.newSetFromMap(new WeakHashMap());

    private i() {
    }

    public static void a(Identifier identifier, AbstractTexture abstractTexture) {
        if (identifier.getNamespace().equals("shooting_star_demo") && identifier.getPath().startsWith("white_space_")) {
            a.add(abstractTexture.getTexture());
        }
    }

    public static boolean a(GpuTexture gpuTexture) {
        return a.contains(gpuTexture);
    }
}

