/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.pipeline.RenderTarget
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.renderpearl.api.GpuFormat
 *  com.mojang.renderpearl.api.device.GpuDevice
 *  com.mojang.renderpearl.api.textures.FilterMode
 *  com.mojang.renderpearl.api.textures.GpuTexture
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.texture.AbstractTexture
 *  net.minecraft.resources.Identifier
 */
package cyou.rimuru.shootingstardemo.client.magic;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuTexture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;

final class j
extends AbstractTexture {
    static final Identifier a = Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"white_space/mirror");
    private static j b;

    private j() {
    }

    static boolean a() {
        Minecraft minecraft = Minecraft.getInstance();
        RenderTarget renderTarget = minecraft.gameRenderer.mainRenderTarget();
        GpuTexture gpuTexture = renderTarget.getColorTexture();
        if (gpuTexture == null || gpuTexture.isClosed()) {
            return false;
        }
        if (b == null) {
            b = new j();
            minecraft.getTextureManager().register(a, (AbstractTexture)b);
        }
        int n2 = gpuTexture.getWidth(0);
        int n3 = gpuTexture.getHeight(0);
        b.a(n2, n3);
        RenderSystem.getDevice().createCommandEncoder().copyTextureToTexture(gpuTexture, j.b.texture, 0, 0, 0, 0, 0, n2, n3);
        return true;
    }

    private void a(int n2, int n3) {
        if (this.texture != null && !this.texture.isClosed() && this.texture.getWidth(0) == n2 && this.texture.getHeight(0) == n3) {
            return;
        }
        if (this.textureView != null) {
            this.textureView.close();
        }
        if (this.texture != null) {
            this.texture.close();
        }
        GpuDevice gpuDevice = RenderSystem.getDevice();
        this.texture = gpuDevice.createTexture(() -> "The Shooting Star demo: White Space mirror", 5, GpuFormat.RGBA8_UNORM, n2, n3, 1, 1);
        this.textureView = gpuDevice.createTextureView(this.texture);
        this.sampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
    }
}

