/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.SubmitNodeCollector
 *  net.minecraft.client.renderer.item.ItemStackRenderState
 *  net.minecraft.world.item.ItemDisplayContext
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import cyou.rimuru.shootingstardemo.client.item.a;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ItemStackRenderState.class})
abstract class ItemStackRenderStateMixin {
    @Shadow
    ItemDisplayContext displayContext;

    ItemStackRenderStateMixin() {
    }

    @Inject(method={"submit"}, at={@At(value="HEAD")})
    private void shootingStarDemo$context(PoseStack poseStack, SubmitNodeCollector submitNodeCollector, int n2, int n3, int n4, CallbackInfo callbackInfo) {
        a.c = this.displayContext;
    }
}

