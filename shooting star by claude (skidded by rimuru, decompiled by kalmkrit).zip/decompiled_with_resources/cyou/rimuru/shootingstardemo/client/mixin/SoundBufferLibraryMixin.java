/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.audio.SoundBuffer
 *  net.minecraft.client.sounds.SoundBufferLibrary
 *  net.minecraft.resources.Identifier
 *  net.minecraft.server.packs.resources.ResourceProvider
 *  net.minecraft.util.Util
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import com.mojang.blaze3d.audio.SoundBuffer;
import cyou.rimuru.shootingstardemo.client.fx.y;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.client.sounds.SoundBufferLibrary;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceProvider;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={SoundBufferLibrary.class})
abstract class SoundBufferLibraryMixin {
    @Shadow
    @Final
    private ResourceProvider resourceManager;
    @Shadow
    @Final
    private Map<Identifier, CompletableFuture<SoundBuffer>> cache;

    SoundBufferLibraryMixin() {
    }

    @Inject(method={"<init>"}, at={@At(value="TAIL")})
    private void shootingStarDemo$remember(ResourceProvider resourceProvider, CallbackInfo callbackInfo) {
        y.a = (SoundBufferLibrary)this;
    }

    @Inject(method={"getCompleteBuffer"}, at={@At(value="HEAD")}, cancellable=true)
    private void shootingStarDemo$stretched(Identifier identifier2, CallbackInfoReturnable<CompletableFuture<SoundBuffer>> callbackInfoReturnable) {
        if (y.a(identifier2)) {
            callbackInfoReturnable.setReturnValue((Object)this.cache.computeIfAbsent(identifier2, identifier -> CompletableFuture.supplyAsync(() -> y.a(this.resourceManager, identifier), (Executor)Util.nonCriticalIoPool())));
        }
    }
}

