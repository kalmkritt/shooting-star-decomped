/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.resource.GraphicsResourceAllocator
 *  com.mojang.renderpearl.api.buffers.GpuBufferSlice
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.LevelRenderer
 *  net.minecraft.client.renderer.state.level.CameraRenderState
 *  org.joml.Matrix4fc
 *  org.joml.Vector4f
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import cyou.rimuru.shootingstardemo.client.fx.e;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import org.joml.Matrix4fc;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={LevelRenderer.class})
abstract class LevelRendererMixin {
    LevelRendererMixin() {
    }

    @Inject(method={"render"}, at={@At(value="HEAD")})
    private void shootingStarDemo$capture(GraphicsResourceAllocator graphicsResourceAllocator, boolean bl, CameraRenderState cameraRenderState, GpuBufferSlice gpuBufferSlice, Vector4f vector4f, boolean bl2, boolean bl3, CallbackInfo callbackInfo) {
        e.a((Matrix4fc)cameraRenderState.viewRotationMatrix);
    }

    @Inject(method={"render"}, at={@At(value="RETURN")})
    private void shootingStarDemo$render(GraphicsResourceAllocator graphicsResourceAllocator, boolean bl, CameraRenderState cameraRenderState, GpuBufferSlice gpuBufferSlice, Vector4f vector4f, boolean bl2, boolean bl3, CallbackInfo callbackInfo) {
        e.a(Minecraft.getInstance().gameRenderer.mainCamera(), cameraRenderState.cameraEntityPartialTicks);
    }
}

