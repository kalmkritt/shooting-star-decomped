/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.CloudStatus
 *  net.minecraft.client.renderer.CloudRenderer
 *  net.minecraft.client.renderer.CloudRenderer$TextureData
 *  net.minecraft.util.Mth
 *  net.minecraft.world.phys.Vec3
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Coerce
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import cyou.rimuru.shootingstardemo.client.fx.c;
import java.nio.ByteBuffer;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.renderer.CloudRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={CloudRenderer.class})
abstract class CloudRendererMixin {
    @Shadow
    private boolean needsRebuild;
    @Shadow
    private CloudRenderer.TextureData texture;
    @Unique
    private double shootingStarDemo$x0;
    @Unique
    private double shootingStarDemo$z0;
    @Unique
    private long shootingStarDemo$time;

    CloudRendererMixin() {
    }

    @Inject(method={"prepare(ILnet/minecraft/client/CloudStatus;FILnet/minecraft/world/phys/Vec3;JF)V"}, at={@At(value="HEAD")}, require=0)
    private void shootingStarDemo$holes(int n2, CloudStatus cloudStatus, float f2, int n3, Vec3 vec3, long l2, float f3, CallbackInfo callbackInfo) {
        if (c.a(l2)) {
            this.needsRebuild = true;
        }
        if (this.texture == null) {
            return;
        }
        float f4 = (float)(l2 % ((long)this.texture.width() * 400L)) + f3;
        double d2 = vec3.x + (double)(f4 * 0.030000001f);
        double d3 = vec3.z + (double)3.96f;
        double d4 = (double)this.texture.width() * 12.0;
        double d5 = (double)this.texture.height() * 12.0;
        d2 -= (double)Mth.floor((double)(d2 / d4)) * d4;
        d3 -= (double)Mth.floor((double)(d3 / d5)) * d5;
        int n4 = Mth.floor((double)(d2 / 12.0));
        int n5 = Mth.floor((double)(d3 / 12.0));
        this.shootingStarDemo$x0 = vec3.x - (double)((float)(d2 - (double)((float)n4 * 12.0f)));
        this.shootingStarDemo$z0 = vec3.z - (double)((float)(d3 - (double)((float)n5 * 12.0f)));
        this.shootingStarDemo$time = l2;
    }

    @Inject(method={"tryBuildCell"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void shootingStarDemo$punched(@Coerce Object object, ByteBuffer byteBuffer, int n2, int n3, boolean bl, int n4, int n5, int n6, int n7, long[] lArray, CallbackInfo callbackInfo) {
        if (c.b() && c.a(this.shootingStarDemo$x0 + (double)n4 * 12.0 + 6.0, this.shootingStarDemo$z0 + (double)n6 * 12.0 + 6.0, this.shootingStarDemo$time)) {
            callbackInfo.cancel();
        }
    }
}

