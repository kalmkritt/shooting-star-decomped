/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.HumanoidModel
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.player.PlayerModel
 *  net.minecraft.client.renderer.entity.state.AvatarRenderState
 *  net.minecraft.util.Mth
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import cyou.rimuru.shootingstardemo.client.fx.b;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={PlayerModel.class})
abstract class PlayerModelPoseMixin {
    PlayerModelPoseMixin() {
    }

    @Inject(method={"setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V"}, at={@At(value="TAIL")})
    private void shootingStarDemo$castPose(AvatarRenderState avatarRenderState, CallbackInfo callbackInfo) {
        b b2 = (b)avatarRenderState.getData(b.a);
        if (b2 == null || b2.g() <= 0.0f) {
            return;
        }
        HumanoidModel humanoidModel = (HumanoidModel)this;
        float f2 = b2.g();
        PlayerModelPoseMixin.apply(humanoidModel.rightArm, b2.a(), b2.b(), b2.c(), f2);
        PlayerModelPoseMixin.apply(humanoidModel.leftArm, b2.d(), b2.e(), b2.f(), f2);
    }

    private static void apply(ModelPart modelPart, float f2, float f3, float f4, float f5) {
        if (Float.isNaN(f2)) {
            return;
        }
        modelPart.xRot = Mth.lerp((float)f5, (float)modelPart.xRot, (float)f2);
        modelPart.yRot = Mth.lerp((float)f5, (float)modelPart.yRot, (float)f3);
        modelPart.zRot = Mth.lerp((float)f5, (float)modelPart.zRot, (float)f4);
    }
}

