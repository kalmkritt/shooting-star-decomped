/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Camera
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.phys.Vec3
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import cyou.rimuru.shootingstardemo.client.cinematic.a;
import cyou.rimuru.shootingstardemo.client.cinematic.d;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={Camera.class})
abstract class CameraMixin {
    @Shadow
    private boolean detached;
    @Shadow
    private Vec3 position;
    @Shadow
    private float xRot;
    @Shadow
    private float yRot;
    @Shadow
    private Entity entity;

    CameraMixin() {
    }

    @Shadow
    protected abstract void setPosition(Vec3 var1);

    @Shadow
    protected abstract void setRotation(float var1, float var2);

    @Inject(method={"alignWithEntity"}, at={@At(value="TAIL")})
    private void shootingStarDemo$cinematic(float f2, CallbackInfo callbackInfo) {
        a a2 = d.a(this.position, this.yRot, this.xRot, f2);
        if (a2 == null) {
            return;
        }
        if (a2.c().distanceToSqr(this.entity.getEyePosition(f2)) > 0.8) {
            this.detached = true;
        }
        this.setRotation(a2.a(), a2.b());
        this.setPosition(a2.c());
    }

    @Inject(method={"calculateFov"}, at={@At(value="RETURN")}, cancellable=true)
    private void shootingStarDemo$cinematicFov(float f2, CallbackInfoReturnable<Float> callbackInfoReturnable) {
        if (d.i()) {
            callbackInfoReturnable.setReturnValue((Object)Float.valueOf(d.a(((Float)callbackInfoReturnable.getReturnValue()).floatValue())));
        }
    }
}

