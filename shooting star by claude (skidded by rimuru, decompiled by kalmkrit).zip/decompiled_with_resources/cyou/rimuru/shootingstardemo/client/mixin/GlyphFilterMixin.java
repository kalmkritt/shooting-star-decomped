/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.renderpearl.api.textures.FilterMode
 *  com.mojang.renderpearl.api.textures.GpuTextureView
 *  net.minecraft.client.renderer.state.gui.GlyphRenderState
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import cyou.rimuru.shootingstardemo.client.magic.i;
import net.minecraft.client.renderer.state.gui.GlyphRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={GlyphRenderState.class})
abstract class GlyphFilterMixin {
    GlyphFilterMixin() {
    }

    @ModifyArg(method={"textureSetup"}, at={@At(value="INVOKE", target="Lcom/mojang/blaze3d/systems/SamplerCache;getClampToEdge(Lcom/mojang/renderpearl/api/textures/FilterMode;)Lcom/mojang/renderpearl/api/textures/GpuSampler;")})
    private FilterMode shootingStarDemo$smoothWhiteSpace(FilterMode filterMode) {
        GpuTextureView gpuTextureView = ((GlyphRenderState)this).renderable().textureView();
        return gpuTextureView != null && i.a(gpuTextureView.texture()) ? FilterMode.LINEAR : filterMode;
    }
}

