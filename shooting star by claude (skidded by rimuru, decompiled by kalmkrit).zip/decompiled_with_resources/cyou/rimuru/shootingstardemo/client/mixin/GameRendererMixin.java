/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.renderpearl.api.textures.GpuTextureView
 *  net.minecraft.client.renderer.GameRenderer
 *  net.minecraft.client.renderer.state.level.CameraRenderState
 *  net.minecraft.client.renderer.state.level.PlayerRenderState
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import cyou.rimuru.shootingstardemo.client.cinematic.d;
import cyou.rimuru.shootingstardemo.client.fx.e;
import cyou.rimuru.shootingstardemo.client.magic.h;
import cyou.rimuru.shootingstardemo.client.render.k;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GameRenderer.class})
abstract class GameRendererMixin {
    GameRendererMixin() {
    }

    @Inject(method={"bobHurt"}, at={@At(value="HEAD")})
    private void shootingStarDemo$shake(CameraRenderState cameraRenderState, PoseStack poseStack, CallbackInfo callbackInfo) {
        e.a(poseStack, cameraRenderState.cameraEntityPartialTicks);
    }

    @ModifyArg(method={"renderLevel"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/renderer/ProjectionMatrixBuffer;getBuffer(Lorg/joml/Matrix4f;)Lcom/mojang/renderpearl/api/buffers/GpuBufferSlice;")})
    private Matrix4f shootingStarDemo$captureProjection(Matrix4f matrix4f) {
        e.b((Matrix4fc)matrix4f);
        return matrix4f;
    }

    @Inject(method={"renderItemInHand"}, at={@At(value="HEAD")}, cancellable=true)
    private void shootingStarDemo$hideHand(CameraRenderState cameraRenderState, PlayerRenderState playerRenderState, GpuTextureView gpuTextureView, CallbackInfo callbackInfo) {
        if (d.i() || h.c()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"render"}, at={@At(value="RETURN")})
    private void shootingStarDemo$frameMark(CallbackInfo callbackInfo) {
        k.a();
    }
}

