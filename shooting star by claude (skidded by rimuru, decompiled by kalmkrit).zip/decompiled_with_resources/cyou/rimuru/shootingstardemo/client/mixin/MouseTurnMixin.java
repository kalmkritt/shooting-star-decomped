/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.world.entity.Entity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import cyou.rimuru.shootingstardemo.client.magic.h;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={Entity.class})
abstract class MouseTurnMixin {
    @Unique
    private static boolean shootingStarDemo$limiting;

    MouseTurnMixin() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"turn"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void shootingStarDemo$whiteSpaceTurn(double d2, double d3, CallbackInfo callbackInfo) {
        if (shootingStarDemo$limiting || !(this instanceof LocalPlayer) || !h.a()) {
            return;
        }
        double[] dArray = h.a(d2, d3);
        shootingStarDemo$limiting = true;
        try {
            ((Entity)this).turn(dArray[0], dArray[1]);
        }
        finally {
            shootingStarDemo$limiting = false;
        }
        callbackInfo.cancel();
    }
}

