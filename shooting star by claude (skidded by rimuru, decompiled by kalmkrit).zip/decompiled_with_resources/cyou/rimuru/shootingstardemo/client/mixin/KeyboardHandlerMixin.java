/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.KeyboardHandler
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.input.KeyEvent
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import cyou.rimuru.shootingstardemo.client.magic.h;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={KeyboardHandler.class})
abstract class KeyboardHandlerMixin {
    KeyboardHandlerMixin() {
    }

    @Inject(method={"keyPress"}, at={@At(value="HEAD")}, cancellable=true)
    private void shootingStarDemo$whiteSpace(long l2, int n2, KeyEvent keyEvent, CallbackInfo callbackInfo) {
        Minecraft minecraft = Minecraft.getInstance();
        if (n2 == 0 || l2 != minecraft.getWindow().handle() || minecraft.gui.screen() != null || !h.a()) {
            return;
        }
        int n3 = keyEvent.key();
        if (n3 >= 59 && n3 <= 69 || n3 >= 104 && n3 <= 115 || minecraft.options.keyScreenshot.matches(keyEvent) || minecraft.options.keyFullscreen.matches(keyEvent) || minecraft.options.keyDebugModifier.isDown()) {
            return;
        }
        if (n2 == 1) {
            h.a(keyEvent);
        }
        callbackInfo.cancel();
    }
}

