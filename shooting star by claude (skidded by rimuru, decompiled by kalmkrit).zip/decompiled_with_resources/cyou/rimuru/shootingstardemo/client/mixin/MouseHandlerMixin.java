/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.MouseHandler
 *  net.minecraft.client.input.MouseButtonInfo
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package cyou.rimuru.shootingstardemo.client.mixin;

import cyou.rimuru.shootingstardemo.client.magic.h;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={MouseHandler.class})
abstract class MouseHandlerMixin {
    MouseHandlerMixin() {
    }

    @Inject(method={"onButton"}, at={@At(value="HEAD")}, cancellable=true)
    private void shootingStarDemo$whiteSpaceClick(long l2, MouseButtonInfo mouseButtonInfo, int n2, CallbackInfo callbackInfo) {
        Minecraft minecraft = Minecraft.getInstance();
        if (n2 == 0 && l2 == minecraft.getWindow().handle()) {
            h.a(mouseButtonInfo.button());
        }
        if (n2 != 1 || l2 != minecraft.getWindow().handle() || minecraft.gui.screen() != null || minecraft.gui.overlay() != null || !h.a()) {
            return;
        }
        if (!minecraft.mouseHandler.isMouseGrabbed()) {
            minecraft.mouseHandler.grabMouse();
        }
        h.a(mouseButtonInfo);
        callbackInfo.cancel();
    }

    @Inject(method={"onScroll"}, at={@At(value="HEAD")}, cancellable=true)
    private void shootingStarDemo$whiteSpaceScroll(long l2, double d2, double d3, CallbackInfo callbackInfo) {
        Minecraft minecraft = Minecraft.getInstance();
        if (l2 == minecraft.getWindow().handle() && minecraft.gui.screen() == null && h.a()) {
            h.a(d3);
            callbackInfo.cancel();
        }
    }
}

