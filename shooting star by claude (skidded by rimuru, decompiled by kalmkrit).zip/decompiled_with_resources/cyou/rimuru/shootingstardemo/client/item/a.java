/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.DefaultVertexFormat
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.PoseStack$Pose
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  com.mojang.renderpearl.api.pipeline.BlendFunction
 *  com.mojang.renderpearl.api.pipeline.ColorTargetState
 *  com.mojang.renderpearl.api.pipeline.CompareOp
 *  com.mojang.renderpearl.api.pipeline.DepthStencilState
 *  com.mojang.renderpearl.api.pipeline.PrimitiveTopology
 *  com.mojang.renderpearl.api.pipeline.RenderPipeline
 *  com.mojang.renderpearl.api.pipeline.RenderPipeline$Snippet
 *  com.mojang.serialization.MapCodec
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.BindGroupLayouts
 *  net.minecraft.client.renderer.RenderPipelines
 *  net.minecraft.client.renderer.SubmitNodeCollector
 *  net.minecraft.client.renderer.rendertype.RenderSetup
 *  net.minecraft.client.renderer.rendertype.RenderType
 *  net.minecraft.client.renderer.rendertype.RenderTypes
 *  net.minecraft.client.renderer.special.NoDataSpecialModelRenderer
 *  net.minecraft.client.renderer.special.NoDataSpecialModelRenderer$Unbaked
 *  net.minecraft.client.renderer.special.SpecialModelRenderer
 *  net.minecraft.client.renderer.special.SpecialModelRenderer$BakingContext
 *  net.minecraft.resources.Identifier
 *  net.minecraft.util.Mth
 *  net.minecraft.util.Util
 *  net.minecraft.world.item.ItemDisplayContext
 *  org.joml.Matrix3f
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 *  org.joml.Vector3f
 *  org.joml.Vector3fc
 */
package cyou.rimuru.shootingstardemo.client.item;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.mojang.renderpearl.api.pipeline.BlendFunction;
import com.mojang.renderpearl.api.pipeline.ColorTargetState;
import com.mojang.renderpearl.api.pipeline.CompareOp;
import com.mojang.renderpearl.api.pipeline.DepthStencilState;
import com.mojang.renderpearl.api.pipeline.PrimitiveTopology;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import com.mojang.serialization.MapCodec;
import cyou.rimuru.shootingstardemo.client.fx.e;
import cyou.rimuru.shootingstardemo.client.fx.o;
import cyou.rimuru.shootingstardemo.star.k;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.special.NoDataSpecialModelRenderer;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.item.ItemDisplayContext;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public final class a
implements NoDataSpecialModelRenderer {
    public static final Identifier a = Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"stellar_remote");
    public static final MapCodec<a> b = MapCodec.unit((Object)new a());
    private static final Identifier d = Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"textures/item/stellar_remote.png");
    private static final RenderType e = RenderTypes.entityCutout((Identifier)d);
    private static final RenderType f = RenderTypes.entityTranslucent((Identifier)d);
    private static final RenderType g = RenderTypes.entityTranslucentEmissive((Identifier)d);
    private static final RenderPipeline h = RenderPipelines.register((RenderPipeline)RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withBindGroupLayout(BindGroupLayouts.PROJECTION).withBindGroupLayout(BindGroupLayouts.DYNAMIC_TRANSFORMS).withLocation(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"pipeline/remote_glow")).withVertexShader(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"core/armillary_glow")).withFragmentShader(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"core/armillary_glow")).withColorTargetState(new ColorTargetState(BlendFunction.LIGHTNING)).withDepthStencilState(new DepthStencilState(CompareOp.GREATER_THAN_OR_EQUAL, false)).withCull(false).withVertexBinding(0, DefaultVertexFormat.POSITION_TEX_COLOR).withPrimitiveTopology(PrimitiveTopology.QUADS).build());
    private static final RenderType i = RenderType.create((String)"shooting_star_demo_remote_glow", (RenderSetup)RenderSetup.builder((RenderPipeline)h).sortOnUpload().createRenderSetup());
    private static final RenderPipeline j = RenderPipelines.register((RenderPipeline)RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withBindGroupLayout(BindGroupLayouts.PROJECTION).withBindGroupLayout(BindGroupLayouts.DYNAMIC_TRANSFORMS).withLocation(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"pipeline/remote_screen")).withVertexShader(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"core/remote_screen")).withFragmentShader(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"core/remote_screen")).withColorTargetState(new ColorTargetState(BlendFunction.TRANSLUCENT)).withDepthStencilState(DepthStencilState.DEFAULT).withCull(false).withVertexBinding(0, DefaultVertexFormat.POSITION_TEX_COLOR).withPrimitiveTopology(PrimitiveTopology.QUADS).build());
    private static final RenderType k = RenderType.create((String)"shooting_star_demo_remote_screen", (RenderSetup)RenderSetup.builder((RenderPipeline)j).sortOnUpload().createRenderSetup());
    private static final float l = 128.0f;
    private static final float[] m = new float[]{0.0f, 0.0f, 28.0f, 74.0f};
    private static final float[] n = new float[]{28.0f, 0.0f, 28.0f, 74.0f};
    private static final float[] o = new float[]{56.0f, 0.0f, 13.0f, 74.0f};
    private static final float[] p = new float[]{69.0f, 0.0f, 28.0f, 13.0f};
    private static final float[] q = new float[]{97.0f, 0.0f, 10.0f, 40.0f};
    private static final float[] r = new float[]{69.0f, 13.0f, 24.0f, 24.0f};
    private static final float[] s = new float[]{107.0f, 0.0f, 20.0f, 20.0f};
    private static final float[] t = new float[]{107.0f, 20.0f, 16.0f, 16.0f};
    private static final float[] u = new float[]{69.0f, 37.0f, 24.0f, 24.0f};
    private static final float[] v = new float[]{93.0f, 40.0f, 6.0f, 40.0f};
    private static final float[] w = new float[]{48.0f, 74.0f, 18.0f, 34.0f};
    private static final float[] x = new float[]{66.0f, 74.0f, 8.0f, 8.0f};
    private static final float[] y = new float[]{74.0f, 74.0f, 8.0f, 8.0f};
    private static final float[] z = new float[]{82.0f, 74.0f, 24.0f, 6.0f};
    private static final int A = 0xF000F0;
    private static final int B = 0;
    private static final int C = 1;
    private static final int D = 2;
    private static final float E = 1.75f;
    private static final float F = 0.8f;
    private static final float G = 0.2f;
    private static final float H = 9.2f;
    private static final float I = 5.15f;
    private static final float J = 1.12f;
    public static ItemDisplayContext c = ItemDisplayContext.NONE;
    private static long K = Long.MIN_VALUE;
    private static long L;

    public void submit(PoseStack poseStack, SubmitNodeCollector submitNodeCollector, int n2, int n3, boolean bl, int n4) {
        float f2 = cyou.rimuru.shootingstardemo.client.item.a.a();
        float f3 = (float)(Util.getMillis() % 3600000L) / 1000.0f;
        float f4 = f2 < 0.0f ? 0.0f : (1.0f - Mth.clamp((float)((f2 - 486.0f - 10.0f) / 10.0f), (float)0.0f, (float)1.0f)) * cyou.rimuru.shootingstardemo.client.item.a.a(Mth.clamp((float)(f2 / 5.0f), (float)0.0f, (float)1.0f));
        float f5 = f2 >= 7.0f && f2 < 12.0f ? 1.0f : 0.0f;
        boolean bl2 = c.firstPerson();
        poseStack.pushPose();
        poseStack.translate(0.5f, 0.0f, 0.5f);
        poseStack.scale(0.0625f, 0.0625f, 0.0625f);
        submitNodeCollector.submitCustomGeometry(poseStack, e, (pose, vertexConsumer) -> this.a(pose, vertexConsumer, n2, n3));
        submitNodeCollector.submitCustomGeometry(poseStack, g, (pose, vertexConsumer) -> this.a(pose, vertexConsumer, n3, f5, f2));
        submitNodeCollector.submitCustomGeometry(poseStack, k, (pose, vertexConsumer) -> this.a(pose, vertexConsumer, f3, f2));
        poseStack.pushPose();
        poseStack.translate(0.0f, 5.15f, 1.12f);
        poseStack.rotate((Quaternionfc)Axis.XP.rotationDegrees(-118.0f * f4));
        poseStack.translate(0.0f, -5.15f, -1.12f);
        submitNodeCollector.submitCustomGeometry(poseStack, f, (pose, vertexConsumer) -> this.b(pose, vertexConsumer, n2, n3));
        poseStack.popPose();
        submitNodeCollector.order(1).submitCustomGeometry(poseStack, i, (pose, vertexConsumer) -> this.a(pose, vertexConsumer, f3, f2, f4, bl2));
        poseStack.popPose();
    }

    private static float a() {
        float f2;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return -1.0f;
        }
        o o2 = null;
        int n2 = 352;
        for (k k2 : cyou.rimuru.shootingstardemo.star.k.values()) {
            o o3 = cyou.rimuru.shootingstardemo.client.fx.e.a(k2);
            if (o3 == null || o3.m() != minecraft.player.getId() || o2 != null && o3.p() >= o2.p()) continue;
            o2 = o3;
            n2 = switch (k2) {
                case cyou.rimuru.shootingstardemo.star.k.b -> 322;
                case cyou.rimuru.shootingstardemo.star.k.c -> 290;
                case cyou.rimuru.shootingstardemo.star.k.d -> 462;
                default -> 352;
            };
        }
        if (o2 == null) {
            return -1.0f;
        }
        long l2 = Util.getMillis();
        if ((long)o2.p() != K) {
            K = o2.p();
            L = l2;
        }
        float f3 = (f2 = (float)o2.p() + Mth.clamp((float)((float)(l2 - L) / (50.0f / o2.j())), (float)0.0f, (float)Math.max(1.0f, o2.j()))) < 9.0f ? f2 : (f2 < (float)n2 ? 9.0f + (f2 - 9.0f) * 343.0f / (float)(n2 - 9) : 352.0f + (f2 - (float)n2));
        return f3 > 526.0f ? -1.0f : f3;
    }

    private static float a(float f2) {
        return 1.0f - (1.0f - f2) * (1.0f - f2) * (1.0f - f2);
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, int n2, int n3) {
        float f2;
        float f3;
        int n4;
        this.a(pose, vertexConsumer, n2, n3, 1.75f, 0.8f, 0.2f, 0.0f, 9.2f, m, n, o, p);
        this.a(pose, vertexConsumer, n2, n3, 1.5f, 0.62f, 0.18f, 9.2f, 9.599999f, z, z, z, p);
        this.a(pose, vertexConsumer, n2, n3, 1.55f, 0.66f, 0.18f, -0.3f, 0.0f, y, y, y, y);
        this.a(pose, vertexConsumer, n2, n3, 1.73f, 0.7f, -0.52f, 1.88f, 5.5f, 0.52f, q, q, q, y);
        this.a(pose, vertexConsumer, n2, n3, -1.88f, 0.7f, -0.52f, -1.73f, 5.5f, 0.52f, q, q, q, y);
        this.a(pose, vertexConsumer, n2, n3, -1.4f, 5.95f, 0.78000003f, 1.4f, 8.75f, 0.93f, r, y, y, y);
        this.a(pose, vertexConsumer, n2, n3, -1.46f, 8.72f, 0.78000003f, 1.46f, 8.92f, 1.1600001f, z, z, z, z);
        this.a(pose, vertexConsumer, n2, n3, -1.08f, 2.75f, 0.78000003f, 1.08f, 5.15f, 1.12f, s, y, y, y);
        this.a(pose, vertexConsumer, n2, n3, -1.16f, 5.09f, 1.04f, 1.16f, 5.29f, 1.24f, x, x, x, x);
        for (n4 = 0; n4 < 6; ++n4) {
            f3 = (float)(n4 % 3 - 1) * 0.98f;
            f2 = n4 < 3 ? 1.3f : 0.5f;
            float[] fArray = new float[]{(float)n4 * 8.0f, 74.0f, 8.0f, 8.0f};
            this.a(pose, vertexConsumer, n2, n3, f3 - 0.4f, f2, 0.78000003f, f3 + 0.4f, f2 + 0.58f, 0.94f, fArray, y, y, y);
        }
        for (n4 = 0; n4 < 4; ++n4) {
            f3 = (n4 % 2 == 0 ? -1.0f : 1.0f) * 1.4f;
            f2 = n4 < 2 ? 0.25f : 9.0f;
            this.a(pose, vertexConsumer, n2, n3, f3 - 0.08f, f2 - 0.08f, 0.79f, f3 + 0.08f, f2 + 0.08f, 0.84000003f, x, x, x, x);
        }
        this.a(pose, vertexConsumer, n2, n3, -0.85f, 3.2f, -0.96000004f, 0.85f, 8.2f, -0.78000003f, w, w, y, y);
        this.a(pose, vertexConsumer, n2, n3, -0.85f, 8.2f, -0.96000004f, 0.85f, 8.45f, -0.7f, y, y, y, y);
        this.a(pose, vertexConsumer, n2, n3, -1.46f, 9.599999f, -0.26f, -0.94f, 10.3f, 0.26f, y, y, y, y);
        this.a(pose, vertexConsumer, n2, n3, -1.34f, 10.3f, -0.14f, -1.06f, 12.0f, 0.14f, v, v, v, y);
        this.a(pose, vertexConsumer, n2, n3, -1.28f, 12.0f, -0.08f, -1.12f, 13.6f, 0.08f, x, x, x, x);
        this.a(pose, vertexConsumer, n2, n3, -1.36f, 13.6f, -0.16f, -1.04f, 13.92f, 0.16f, y, y, y, y);
        this.a(pose, vertexConsumer, n2, n3, -0.34f, -0.75f, -0.08f, -0.2f, -0.3f, 0.08f, x, x, x, x);
        this.a(pose, vertexConsumer, n2, n3, 0.2f, -0.75f, -0.08f, 0.34f, -0.3f, 0.08f, x, x, x, x);
        this.a(pose, vertexConsumer, n2, n3, -0.34f, -0.89f, -0.08f, 0.34f, -0.75f, 0.08f, x, x, x, x);
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, int n2, float f2, float f3) {
        float f4 = 0.46f - 0.32f * f2;
        int n3 = f3 >= 0.0f && f3 < 486.0f ? -1 : -3092272;
        float f5 = 3.95f;
        this.a(pose, vertexConsumer, 0xF000F0, n2, -0.74f, f5 - 0.5f, 1.12f, 0.74f, f5 + 0.5f, 1.12f + f4, t, t, t, t, n3);
        this.a(pose, vertexConsumer, 0xF000F0, n2, -0.52f, f5 - 0.72f, 1.12f, 0.52f, f5 + 0.72f, 1.12f + f4, t, t, t, t, n3);
        this.a(pose, vertexConsumer, 0xF000F0, n2, -0.6f, f5 - 0.6f, 1.12f, 0.6f, f5 + 0.6f, 1.12f + f4 + 0.06f, t, t, t, t, n3);
    }

    private void b(PoseStack.Pose pose, VertexConsumer vertexConsumer, int n2, int n3) {
        float f2 = 1.12f;
        float f3 = 1.84f;
        float f4 = 2.7f;
        this.a(pose, vertexConsumer, n2, n3, -1.14f, f4, f3 - 0.12f, 1.14f, 5.15f, f3, u, u, u, u);
        this.a(pose, vertexConsumer, n2, n3, -1.14f, f4, f2, -1.0f, 5.15f, f3 - 0.12f, u, u, u, u);
        this.a(pose, vertexConsumer, n2, n3, 1.0f, f4, f2, 1.14f, 5.15f, f3 - 0.12f, u, u, u, u);
        this.a(pose, vertexConsumer, n2, n3, -1.0f, f4, f2, 1.0f, f4 + 0.14f, f3 - 0.12f, u, u, u, u);
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, float f2, float f3) {
        boolean bl = f3 >= 0.0f && f3 < 486.0f;
        float f4 = bl ? Mth.clamp((float)((f3 - 9.0f) / 12.0f), (float)0.0f, (float)1.0f) : 0.0f;
        f4 = f4 * f4 * (3.0f - 2.0f * f4);
        float f5 = bl && f3 >= 9.0f ? (float)(cyou.rimuru.shootingstardemo.client.item.a.a((double)f3) % 1.0) : 0.0f;
        float f6 = bl && f3 >= 352.0f ? Math.max(0.0f, 1.0f - (f3 - 352.0f) / 8.0f) : 0.0f;
        float f7 = bl ? Mth.clamp((float)((f3 - 9.0f) / 343.0f), (float)0.0f, (float)1.0f) : 0.0f;
        float f8 = (float)Math.round(f7 * 20.0f) * 4.0f;
        float f9 = f2 * 0.5f % 1.0f;
        float f10 = -1.12f;
        float f11 = 1.12f;
        float f12 = 6.18f;
        float f13 = 8.52f;
        float f14 = 0.935f;
        vertexConsumer.addVertex(pose, f10, f12, f14).setUv(f8 - 1.0f, -1.0f).setColor(f9, f4, f5, f6);
        vertexConsumer.addVertex(pose, f11, f12, f14).setUv(f8 + 1.0f, -1.0f).setColor(f9, f4, f5, f6);
        vertexConsumer.addVertex(pose, f11, f13, f14).setUv(f8 + 1.0f, 1.0f).setColor(f9, f4, f5, f6);
        vertexConsumer.addVertex(pose, f10, f13, f14).setUv(f8 - 1.0f, 1.0f).setColor(f9, f4, f5, f6);
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, int n2, int n3, float f2, float f3, float f4, float f5, float f6, float[] fArray, float[] fArray2, float[] fArray3, float[] fArray4) {
        int[][] nArrayArray;
        float[] fArray5;
        float[][] fArrayArray = new float[][]{{f2 - f4, f3}, {-f2 + f4, f3}, {-f2, f3 - f4}, {-f2, -f3 + f4}, {-f2 + f4, -f3}, {f2 - f4, -f3}, {f2, -f3 + f4}, {f2, f3 - f4}};
        for (int i2 = 0; i2 < 8; ++i2) {
            float[] object = fArrayArray[i2];
            float[] fArray6 = fArrayArray[(i2 + 1) % 8];
            float f7 = fArray6[1] - object[1];
            float f8 = object[0] - fArray6[0];
            float fArray8 = (float)Math.sqrt(f7 * f7 + f8 * f8);
            f7 /= fArray8;
            float[] fArray7 = (f8 /= fArray8) > 0.9f ? fArray : (fArray5 = f8 < -0.9f ? fArray2 : fArray3);
            if (Math.abs(f7) < 0.9f && Math.abs(f8) < 0.9f) {
                fArray5 = new float[]{fArray3[0], fArray3[1], 1.0f, fArray3[3]};
            }
            this.a(pose, vertexConsumer, n2, n3, -1, (Vector3fc)new Vector3f(f7, 0.0f, f8), fArray5, fArray6[0], f5, fArray6[1], object[0], f5, object[1], object[0], f6, object[1], fArray6[0], f6, fArray6[1]);
        }
        for (int[] nArray : nArrayArray = new int[][]{{0, 1, 2, 7}, {7, 2, 3, 6}, {6, 3, 4, 5}}) {
            float[] fArray8 = fArrayArray[nArray[0]];
            fArray5 = fArrayArray[nArray[1]];
            float[] fArray9 = fArrayArray[nArray[2]];
            float[] fArray10 = fArrayArray[nArray[3]];
            this.a(pose, vertexConsumer, n2, n3, -1, (Vector3fc)new Vector3f(0.0f, 1.0f, 0.0f), fArray4, fArray8[0], f6, fArray8[1], fArray10[0], f6, fArray10[1], fArray9[0], f6, fArray9[1], fArray5[0], f6, fArray5[1]);
            this.a(pose, vertexConsumer, n2, n3, -1, (Vector3fc)new Vector3f(0.0f, -1.0f, 0.0f), fArray4, fArray5[0], f5, fArray5[1], fArray9[0], f5, fArray9[1], fArray10[0], f5, fArray10[1], fArray8[0], f5, fArray8[1]);
        }
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, int n2, int n3, float f2, float f3, float f4, float f5, float f6, float f7, float[] fArray, float[] fArray2, float[] fArray3, float[] fArray4) {
        this.a(pose, vertexConsumer, n2, n3, f2, f3, f4, f5, f6, f7, fArray, fArray2, fArray3, fArray4, -1);
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, int n2, int n3, float f2, float f3, float f4, float f5, float f6, float f7, float[] fArray, float[] fArray2, float[] fArray3, float[] fArray4, int n4) {
        this.a(pose, vertexConsumer, n2, n3, n4, (Vector3fc)new Vector3f(0.0f, 0.0f, 1.0f), fArray, f2, f3, f7, f5, f3, f7, f5, f6, f7, f2, f6, f7);
        this.a(pose, vertexConsumer, n2, n3, n4, (Vector3fc)new Vector3f(0.0f, 0.0f, -1.0f), fArray2, f5, f3, f4, f2, f3, f4, f2, f6, f4, f5, f6, f4);
        this.a(pose, vertexConsumer, n2, n3, n4, (Vector3fc)new Vector3f(1.0f, 0.0f, 0.0f), fArray3, f5, f3, f7, f5, f3, f4, f5, f6, f4, f5, f6, f7);
        this.a(pose, vertexConsumer, n2, n3, n4, (Vector3fc)new Vector3f(-1.0f, 0.0f, 0.0f), fArray3, f2, f3, f4, f2, f3, f7, f2, f6, f7, f2, f6, f4);
        this.a(pose, vertexConsumer, n2, n3, n4, (Vector3fc)new Vector3f(0.0f, 1.0f, 0.0f), fArray4, f2, f6, f7, f5, f6, f7, f5, f6, f4, f2, f6, f4);
        this.a(pose, vertexConsumer, n2, n3, n4, (Vector3fc)new Vector3f(0.0f, -1.0f, 0.0f), fArray4, f2, f3, f4, f5, f3, f4, f5, f3, f7, f2, f3, f7);
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, int n2, int n3, int n4, Vector3fc vector3fc, float[] fArray, float ... fArray2) {
        float[][] fArrayArray = new float[][]{{0.0f, 1.0f}, {1.0f, 1.0f}, {1.0f, 0.0f}, {0.0f, 0.0f}};
        for (int i2 = 0; i2 < 4; ++i2) {
            vertexConsumer.addVertex(pose, fArray2[i2 * 3], fArray2[i2 * 3 + 1], fArray2[i2 * 3 + 2]).setColor(n4).setUv((fArray[0] + fArray[2] * fArrayArray[i2][0]) / 128.0f, (fArray[1] + fArray[3] * fArrayArray[i2][1]) / 128.0f).setOverlay(n3).setLight(n2).setNormal(pose, vector3fc.x(), vector3fc.y(), vector3fc.z());
        }
    }

    private void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, float f2, float f3, float f4, boolean bl) {
        Matrix4f matrix4f = bl ? new Matrix4f((Matrix4fc)pose.pose()) : RenderSystem.getModelViewMatrixCopy().mul((Matrix4fc)pose.pose());
        Matrix3f matrix3f = new Matrix3f((Matrix4fc)matrix4f).invert();
        Vector3f vector3f = matrix3f.transform(new Vector3f(1.0f, 0.0f, 0.0f)).normalize();
        Vector3f vector3f2 = matrix3f.transform(new Vector3f(0.0f, 1.0f, 0.0f)).normalize();
        boolean bl2 = f3 >= 0.0f && f3 < 486.0f;
        Vector3f vector3f3 = new Vector3f(0.0f, 7.35f, 1.0f);
        Vector3f vector3f4 = new Vector3f(1.0f, 0.0f, 0.0f);
        Vector3f vector3f5 = new Vector3f(0.0f, 1.0f, 0.0f);
        float f5 = bl2 && f3 >= 9.0f ? 1.0f : 0.35f;
        float f6 = bl2 && f3 >= 352.0f ? Math.max(0.0f, 1.0f - (f3 - 352.0f) / 8.0f) : 0.0f;
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, (Vector3fc)vector3f3, (Vector3fc)vector3f4, (Vector3fc)vector3f5, 1.9f, 1.7f, 0, 1.0f, 0.12f, 0.16f, 0.22f * f5 + 0.9f * f6);
        Vector3f vector3f6 = new Vector3f(0.0f, 3.95f, 1.6700001f);
        float f7 = 0.75f + 0.25f * Mth.sin((double)(f2 * (bl2 ? 9.0f : 2.0f)));
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, (Vector3fc)vector3f, (Vector3fc)vector3f2, (Vector3fc)vector3f6, 1.4f + 1.2f * f4, 0, 1.0f, 0.1f, 0.14f, (0.12f + 0.4f * f4) * f7);
        float f8 = bl2 ? (Mth.sin((double)(f2 * 18.0f)) > 0.0f ? 1.0f : 0.25f) : (f2 % 1.4f < 0.12f ? 1.0f : 0.15f);
        Vector3f vector3f7 = new Vector3f(-1.2f, 13.76f, 0.0f);
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, (Vector3fc)vector3f, (Vector3fc)vector3f2, (Vector3fc)vector3f7, 0.9f + 0.6f * f8, 0, 1.0f, 0.12f, 0.15f, 0.8f * f8);
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, (Vector3fc)vector3f, (Vector3fc)vector3f2, (Vector3fc)vector3f7, 0.45f, 2, 1.0f, 0.8f, 0.8f, 0.9f * f8);
        float[][] fArrayArray = new float[][]{{0.3f, 1.0f, 0.45f}, {1.0f, 0.12f, 0.15f}, {1.0f, 0.65f, 0.15f}};
        for (int i2 = 0; i2 < 3; ++i2) {
            Vector3f vector3f8 = new Vector3f(-0.5f + (float)i2 * 0.5f, 5.68f, 0.83f);
            float f9 = i2 == 0 ? 1.0f : (i2 == 1 ? (bl2 ? 1.0f : 0.12f) : (bl2 ? (Mth.sin((double)(f2 * 11.0f)) > 0.0f ? 1.0f : 0.2f) : (f2 % 2.0f < 0.1f ? 1.0f : 0.1f)));
            cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, (Vector3fc)vector3f8, (Vector3fc)vector3f4, (Vector3fc)vector3f5, 0.24f, 0.24f, 0, fArrayArray[i2][0], fArrayArray[i2][1], fArrayArray[i2][2], 0.9f * f9);
        }
    }

    private static double a(double d2) {
        int n2 = 29;
        if (d2 < (double)n2) {
            return (d2 - 9.0) / 20.0 * 0.6;
        }
        double d3 = (double)(352 - n2) / 20.0;
        double d4 = Math.min(d2 - (double)n2, (double)(352 - n2)) / 20.0;
        double d5 = d4 / d3;
        return 0.6 * d4 + 3.4 * d3 * d5 * d5 * d5 / 3.0;
    }

    private static void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, Vector3fc vector3fc, Vector3fc vector3fc2, Vector3fc vector3fc3, float f2, int n2, float f3, float f4, float f5, float f6) {
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, vector3fc3, vector3fc, vector3fc2, f2, f2, n2, f3, f4, f5, f6);
    }

    private static void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, Vector3fc vector3fc, Vector3fc vector3fc2, Vector3fc vector3fc3, float f2, float f3, int n2, float f4, float f5, float f6, float f7) {
        if (f7 <= 0.004f) {
            return;
        }
        float f8 = (float)n2 * 4.0f;
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, vector3fc, vector3fc2, vector3fc3, -f2, -f3, f8 - 1.0f, -1.0f, f4, f5, f6, f7);
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, vector3fc, vector3fc2, vector3fc3, f2, -f3, f8 + 1.0f, -1.0f, f4, f5, f6, f7);
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, vector3fc, vector3fc2, vector3fc3, f2, f3, f8 + 1.0f, 1.0f, f4, f5, f6, f7);
        cyou.rimuru.shootingstardemo.client.item.a.a(pose, vertexConsumer, vector3fc, vector3fc2, vector3fc3, -f2, f3, f8 - 1.0f, 1.0f, f4, f5, f6, f7);
    }

    private static void a(PoseStack.Pose pose, VertexConsumer vertexConsumer, Vector3fc vector3fc, Vector3fc vector3fc2, Vector3fc vector3fc3, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        vertexConsumer.addVertex(pose, vector3fc.x() + vector3fc2.x() * f2 + vector3fc3.x() * f3, vector3fc.y() + vector3fc2.y() * f2 + vector3fc3.y() * f3, vector3fc.z() + vector3fc2.z() * f2 + vector3fc3.z() * f3).setUv(f4, f5).setColor(f6, f7, f8, Math.min(1.0f, f9));
    }

    public void getExtents(Consumer<Vector3fc> consumer) {
        for (int i2 = 0; i2 < 8; ++i2) {
            consumer.accept((Vector3fc)new Vector3f((i2 & 1) == 0 ? 0.37f : 0.63f, (i2 & 2) == 0 ? -0.06f : 0.88f, (i2 & 4) == 0 ? 0.43f : 0.62f));
        }
    }

    public record a() implements NoDataSpecialModelRenderer.Unbaked
    {
        public NoDataSpecialModelRenderer a(SpecialModelRenderer.BakingContext bakingContext) {
            return new a();
        }

        public MapCodec<a> type() {
            return b;
        }

        public /* synthetic */ SpecialModelRenderer bake(SpecialModelRenderer.BakingContext bakingContext) {
            return this.a(bakingContext);
        }
    }
}

