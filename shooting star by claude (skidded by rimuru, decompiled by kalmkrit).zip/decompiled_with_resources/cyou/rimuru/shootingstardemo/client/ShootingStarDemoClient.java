/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ClientModInitializer
 *  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
 *  net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents
 *  net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
 *  net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry
 *  net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements
 *  net.fabricmc.fabric.api.client.screen.v1.ScreenEvents
 *  net.fabricmc.fabric.api.event.player.UseEntityCallback
 *  net.minecraft.ChatFormatting
 *  net.minecraft.client.KeyMapping
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.client.gui.screens.TitleScreen
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.renderer.special.SpecialModelRenderers
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload
 *  net.minecraft.resources.Identifier
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.component.SwingAnimation
 */
package cyou.rimuru.shootingstardemo.client;

import cyou.rimuru.shootingstardemo.ShootingStarDemo;
import cyou.rimuru.shootingstardemo.client.cinematic.d;
import cyou.rimuru.shootingstardemo.client.item.a;
import cyou.rimuru.shootingstardemo.client.magic.e;
import cyou.rimuru.shootingstardemo.client.magic.f;
import cyou.rimuru.shootingstardemo.client.magic.g;
import cyou.rimuru.shootingstardemo.client.render.b;
import cyou.rimuru.shootingstardemo.client.render.c;
import cyou.rimuru.shootingstardemo.client.render.h;
import cyou.rimuru.shootingstardemo.client.render.i;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.special.SpecialModelRenderers;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.SwingAnimation;

public final class ShootingStarDemoClient
implements ClientModInitializer {
    public void onInitializeClient() {
        f.a();
        d.a();
        cyou.rimuru.shootingstardemo.client.magic.c.a();
        SpecialModelRenderers.ID_MAPPER.put((Object)a.a, a.b);
        ClientPlayNetworking.registerGlobalReceiver(cyou.rimuru.shootingstardemo.net.d.f, (d2, context) -> context.client().execute(() -> cyou.rimuru.shootingstardemo.client.fx.e.a(d2)));
        ClientPlayNetworking.registerGlobalReceiver(cyou.rimuru.shootingstardemo.net.b.a, (b2, context) -> context.client().execute(() -> cyou.rimuru.shootingstardemo.client.magic.a.a(b2)));
        ClientPlayNetworking.registerGlobalReceiver(cyou.rimuru.shootingstardemo.net.c.a, (c2, context) -> context.client().execute(() -> ShootingStarDemoClient.erase(c2)));
        ClientPlayConnectionEvents.DISCONNECT.register((clientPacketListener, minecraft) -> {
            cyou.rimuru.shootingstardemo.client.fx.e.a();
            cyou.rimuru.shootingstardemo.client.magic.h.e();
        });
        ClientTickEvents.END_CLIENT_TICK.register(ShootingStarDemoClient::tick);
        ScreenEvents.AFTER_INIT.register((minecraft, screen, n2, n3) -> {
            if (screen instanceof TitleScreen && !b.a().a()) {
                minecraft.gui.setScreen((Screen)new c(b.a()));
            } else if (screen instanceof TitleScreen && h.a()) {
                minecraft.gui.setScreen((Screen)new i(screen));
            }
        });
        HudElementRegistry.addLast((Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"skills"), (guiGraphicsExtractor, deltaTracker) -> {
            float f2 = deltaTracker.getGameTimeDeltaPartialTick(true);
            if (d.j()) {
                cyou.rimuru.shootingstardemo.client.fx.e.a(guiGraphicsExtractor, f2);
                d.a(guiGraphicsExtractor, f2);
                return;
            }
            cyou.rimuru.shootingstardemo.client.fx.e.b(guiGraphicsExtractor, f2);
            cyou.rimuru.shootingstardemo.client.fx.a.a(guiGraphicsExtractor, f2);
            e.a(guiGraphicsExtractor, f2);
            d.a(guiGraphicsExtractor, f2);
        });
        HudElementRegistry.addLast((Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"white_space"), (guiGraphicsExtractor, deltaTracker) -> cyou.rimuru.shootingstardemo.client.magic.h.a(guiGraphicsExtractor, deltaTracker.getGameTimeDeltaPartialTick(true)));
        for (Identifier identifier : new Identifier[]{VanillaHudElements.HOTBAR, VanillaHudElements.CROSSHAIR, VanillaHudElements.ARMOR_BAR, VanillaHudElements.HEALTH_BAR, VanillaHudElements.FOOD_BAR, VanillaHudElements.AIR_BAR, VanillaHudElements.MOUNT_HEALTH, VanillaHudElements.INFO_BAR, VanillaHudElements.EXPERIENCE_LEVEL, VanillaHudElements.HELD_ITEM_TOOLTIP, VanillaHudElements.MOB_EFFECTS, VanillaHudElements.CHAT, VanillaHudElements.OVERLAY_MESSAGE, VanillaHudElements.SCOREBOARD, VanillaHudElements.BOSS_BAR}) {
            HudElementRegistry.replaceElement((Identifier)identifier, hudElement -> (guiGraphicsExtractor, deltaTracker) -> {
                if (!d.j()) {
                    hudElement.extractRenderState(guiGraphicsExtractor, deltaTracker);
                }
            });
        }
        cyou.rimuru.shootingstardemo.magic.b.a = ShootingStarDemoClient::onUse;
        cyou.rimuru.shootingstardemo.magic.b.b = f::b;
        cyou.rimuru.shootingstardemo.magic.b.c = () -> f.b(f.a).getString();
        UseEntityCallback.EVENT.register((player, level, interactionHand, entity, entityHitResult) -> {
            if (!level.isClientSide() || player.isSpectator()) {
                return InteractionResult.PASS;
            }
            Item item = player.getItemInHand(interactionHand).getItem();
            if (item instanceof cyou.rimuru.shootingstardemo.magic.b) {
                cyou.rimuru.shootingstardemo.magic.b b2 = (cyou.rimuru.shootingstardemo.magic.b)item;
                ShootingStarDemoClient.onUse(player, b2);
                player.swing(interactionHand, SwingAnimation.DEFAULT, false);
                return InteractionResult.FAIL;
            }
            return InteractionResult.PASS;
        });
        ShootingStarDemo.LOGGER.a("The Stellar Remote answers to its wielder.", new Object[0]);
    }

    private static void tick(Minecraft minecraft) {
        String string;
        cyou.rimuru.shootingstardemo.client.magic.a.b();
        cyou.rimuru.shootingstardemo.client.magic.h.b(minecraft);
        cyou.rimuru.shootingstardemo.client.a.a(minecraft);
        boolean bl = minecraft.isPaused();
        if (!bl) {
            d.h();
        }
        while (f.b.consumeClick()) {
            string = d.f();
            if (string == null || minecraft.player == null) continue;
            minecraft.player.sendOverlayMessage((Component)Component.literal((String)string).withStyle(ChatFormatting.GOLD));
        }
        if (!bl) {
            cyou.rimuru.shootingstardemo.client.fx.e.a(minecraft);
        }
        string = minecraft.player;
        while (f.a.consumeClick()) {
            if (string == null || minecraft.gui.screen() != null) continue;
            ShootingStarDemoClient.openMenu(minecraft, (Player)string);
        }
        for (cyou.rimuru.shootingstardemo.magic.e e2 : cyou.rimuru.shootingstardemo.magic.e.a()) {
            for (cyou.rimuru.shootingstardemo.magic.d d2 : e2.c) {
                KeyMapping keyMapping = f.a(d2);
                while (keyMapping.consumeClick()) {
                    if (minecraft.gui.screen() != null || !cyou.rimuru.shootingstardemo.magic.b.a((Player)string, e2)) continue;
                    cyou.rimuru.shootingstardemo.client.magic.a.a(d2);
                }
            }
        }
    }

    private static void openMenu(Minecraft minecraft, Player player) {
        cyou.rimuru.shootingstardemo.client.magic.h.a(minecraft);
    }

    private static void onUse(Player player, cyou.rimuru.shootingstardemo.magic.b b2) {
        cyou.rimuru.shootingstardemo.magic.d d2 = cyou.rimuru.shootingstardemo.client.magic.a.a(b2.d);
        if (player.isShiftKeyDown()) {
            cyou.rimuru.shootingstardemo.client.magic.a.a(cyou.rimuru.shootingstardemo.client.magic.a.b(b2.d));
            return;
        }
        int n2 = cyou.rimuru.shootingstardemo.client.magic.a.b(d2);
        if (n2 > 0) {
            player.sendOverlayMessage((Component)Component.literal((String)(d2.c() + " is recharging \u2014 " + (n2 + 19) / 20 + "s")).withStyle(ChatFormatting.DARK_PURPLE));
            return;
        }
        cyou.rimuru.shootingstardemo.magic.f f2 = g.a(d2);
        ClientPlayNetworking.send((CustomPacketPayload)new cyou.rimuru.shootingstardemo.net.a(cyou.rimuru.shootingstardemo.magic.e.a(d2), f2.b(), f2.c(), f2.d(), d.c()));
    }

    private static void erase(cyou.rimuru.shootingstardemo.net.c c2) {
        ClientLevel clientLevel = Minecraft.getInstance().level;
        if (clientLevel == null) {
            return;
        }
        for (int n2 : c2.a()) {
            Entity entity = clientLevel.getEntity(n2);
            if (entity == null) continue;
            cyou.rimuru.shootingstardemo.star.d.a(entity);
        }
    }
}

