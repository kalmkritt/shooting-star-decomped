/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package cyou.rimuru.shootingstardemo.client.fx;

import net.minecraft.client.Minecraft;

final class i {
    private final int[] a;
    private final float b;
    private long c = -1L;
    private long d;
    private long e;
    private int f;
    private int g;

    i(int[] nArray, float f2) {
        this.a = nArray;
        this.b = f2;
    }

    void a() {
        this.e = this.c = System.nanoTime();
        this.f = 1;
    }

    int a(float f2) {
        if (this.c < 0L || this.f >= this.a.length) {
            return -1;
        }
        long l2 = System.nanoTime();
        if (Minecraft.getInstance().isPaused()) {
            this.d += l2 - this.e;
        }
        this.e = l2;
        double d2 = 1.0E9 / (20.0 * (double)this.b);
        double d3 = (double)(l2 - this.c - this.d) / d2;
        if (d3 - (double)f2 > 20.0 * (double)this.b) {
            this.d += (long)((d3 - (double)f2) * d2);
            d3 = f2;
        }
        int n2 = -1;
        while (this.f < this.a.length && d3 >= (double)this.a[this.f]) {
            ++this.f;
        }
        if (n2 >= 0) {
            this.g = Math.round(f2) - this.a[n2];
        }
        return n2;
    }

    int b() {
        return this.g;
    }
}

