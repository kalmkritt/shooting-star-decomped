/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.resources.sounds.SoundInstance
 *  net.minecraft.client.resources.sounds.SoundInstance$Attenuation
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.BlockPos$MutableBlockPos
 *  net.minecraft.core.particles.BlockParticleOption
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.util.Mth
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.levelgen.Heightmap$Types
 *  net.minecraft.world.phys.Vec3
 */
package cyou.rimuru.shootingstardemo.client.fx;

import cyou.rimuru.shootingstardemo.client.cinematic.l;
import cyou.rimuru.shootingstardemo.client.fx.a;
import cyou.rimuru.shootingstardemo.client.fx.b;
import cyou.rimuru.shootingstardemo.client.fx.d;
import cyou.rimuru.shootingstardemo.client.fx.e;
import cyou.rimuru.shootingstardemo.client.fx.i;
import cyou.rimuru.shootingstardemo.client.fx.j;
import cyou.rimuru.shootingstardemo.client.fx.k;
import cyou.rimuru.shootingstardemo.client.fx.o;
import cyou.rimuru.shootingstardemo.client.fx.r;
import cyou.rimuru.shootingstardemo.client.fx.t;
import cyou.rimuru.shootingstardemo.client.fx.u;
import cyou.rimuru.shootingstardemo.client.fx.w;
import cyou.rimuru.shootingstardemo.client.fx.x;
import cyou.rimuru.shootingstardemo.client.fx.y;
import cyou.rimuru.shootingstardemo.client.render.f;
import cyou.rimuru.shootingstardemo.registry.g;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

public final class v
extends o {
    static final int a = 7;
    static final int b = 9;
    static final int c = 29;
    static final int d = 438;
    static final int e = 462;
    static final int f = 562;
    static final int g = 592;
    static final int h = 8;
    static final int i = 290;
    static final int j = 398;
    static final int k = 426;
    static final int l = 8;
    private static final int[] E = new int[]{33, 35};
    private static final float F = 0.083333336f;
    private static final int[] G = new int[]{30, 35, 34, 30, 27, 32};
    private static final int[] H = new int[]{33, 27, 35, 31};
    private static final int[] I = new int[]{35, 33, 27, 34, 30, 29, 32, 31, 28, 35};
    private static final int[] J = new int[]{0, 55, 148, 207, 288, 333, 353, 397, 423, 456, 470, 491, 508, 527, 554, 586};
    private static final int K = 3;
    private static final double L = 1400.0;
    private static final double M = 2800.0;
    private static final StringBuilder N = new StringBuilder();
    static final int[] x = new int[]{0xFF222C, 16744464, 16769566, 2681940, 1869055, 5517567, 12205311};
    final double y;
    final int z;
    final int A;
    final int B;
    private final cyou.rimuru.shootingstardemo.client.cinematic.i O;
    public final boolean C;
    private k P;
    private final i Q;
    private final int R;
    private final int S;
    private final int T;
    private final int U;
    private final int V;
    private final int[] W;
    private final int[] X;
    private final int[] Y;
    private final boolean[] Z;
    private final float[][] aa;
    private final int[][] ab;
    private boolean ac;
    private final l ad;
    private final List<int[]>[] ae;
    int D;
    private final Long2IntOpenHashMap af;
    private int ag;

    public int b() {
        return this.D;
    }

    v(cyou.rimuru.shootingstardemo.net.d d2) {
        super(d2);
        this.Q = new i(J, this.v);
        this.W = new int[64];
        this.X = cyou.rimuru.shootingstardemo.star.l.k();
        this.Y = new int[64];
        this.Z = new boolean[64];
        this.aa = new float[64][];
        this.ab = new int[64][];
        this.ae = new List[64];
        this.af = new Long2IntOpenHashMap();
        Minecraft minecraft = Minecraft.getInstance();
        this.y = cyou.rimuru.shootingstardemo.star.l.a(cyou.rimuru.shootingstardemo.star.k.d.j().a(d2.n()));
        this.z = cyou.rimuru.shootingstardemo.star.l.b(this.y);
        this.A = this.z / 8;
        this.B = cyou.rimuru.shootingstardemo.star.l.c(this.y);
        this.O = super.e();
        this.C = minecraft.player != null && minecraft.player.getId() == d2.c();
        this.R = cyou.rimuru.shootingstardemo.star.l.a(this.p.x, this.z);
        this.S = cyou.rimuru.shootingstardemo.star.l.a(this.p.z, this.z);
        this.T = Mth.floor((double)this.p.y);
        this.V = minecraft.level != null ? minecraft.level.getMinY() : -64;
        int n2 = minecraft.level != null ? minecraft.level.getMaxY() : 319;
        this.U = cyou.rimuru.shootingstardemo.star.l.a(this.T, this.y, this.V);
        this.ag = cyou.rimuru.shootingstardemo.star.l.a(this.U + this.B, cyou.rimuru.shootingstardemo.star.l.f(this.y), Integer.MAX_VALUE, n2);
        Arrays.fill(this.Y, this.T);
        this.af.defaultReturnValue(Integer.MAX_VALUE);
        for (int i2 = 0; i2 < this.W.length; ++i2) {
            this.W[i2] = cyou.rimuru.shootingstardemo.star.l.a(this.U, i2 % 8, i2 / 8, this.y, this.V);
        }
        this.ad = new l(this);
    }

    public static void a(cyou.rimuru.shootingstardemo.star.k k2, cyou.rimuru.shootingstardemo.net.d d2) {
        v v2 = new v(d2);
        cyou.rimuru.shootingstardemo.client.fx.y.a("tess_", v2.v);
        N.setLength(0);
        cyou.rimuru.shootingstardemo.client.fx.e.a(v2);
        if (cyou.rimuru.shootingstardemo.client.cinematic.d.a(v2.C, v2.t)) {
            cyou.rimuru.shootingstardemo.client.cinematic.d.a(cyou.rimuru.shootingstardemo.client.cinematic.k.a(v2.e(), v2).a(v2.v));
        } else if (!v2.C) {
            cyou.rimuru.shootingstardemo.client.fx.a.a(k2, false, v2.l());
        }
    }

    @Override
    protected int d() {
        return 1262;
    }

    @Override
    public double a() {
        return Math.max(3000.0, (double)this.z + 1000.0);
    }

    public double c() {
        return this.y;
    }

    @Override
    public cyou.rimuru.shootingstardemo.client.cinematic.i e() {
        return this.O;
    }

    boolean f() {
        return cyou.rimuru.shootingstardemo.client.cinematic.d.a(this.O) > 0.5f;
    }

    float a(float f2) {
        return cyou.rimuru.shootingstardemo.client.cinematic.d.a(this.O, f2);
    }

    public Vec3 g() {
        return this.p;
    }

    public Vec3 i() {
        return new Vec3((double)this.R + (double)this.z * 0.5, (double)this.T, (double)this.S + (double)this.z * 0.5);
    }

    public Vec3 s() {
        return new Vec3((double)this.R + (double)this.z * 0.5 + 0.5, (double)this.ag + 0.5, (double)this.S + (double)this.z * 0.5 + 0.5);
    }

    public Vec3 a(int n2) {
        double d2 = (double)(this.R + n2 % 8 * this.A) + (double)this.A * 0.5;
        double d3 = (double)(this.S + n2 / 8 * this.A) + (double)this.A * 0.5;
        float[] fArray = this.aa[n2];
        return fArray == null ? new Vec3(d2, (double)this.Y[n2], d3) : new Vec3(d2, (double)fArray[0] + (double)fArray[1] * 0.5, d3);
    }

    public int t() {
        return this.U;
    }

    public int c(int n2) {
        return this.W[n2];
    }

    public int a(double d2, double d3) {
        int n2 = Mth.floor((double)((d2 - (double)this.R) / (double)this.A));
        int n3 = Mth.floor((double)((d3 - (double)this.S) / (double)this.A));
        return n2 < 0 || n3 < 0 || n2 >= 8 || n3 >= 8 ? this.U : this.W[cyou.rimuru.shootingstardemo.client.fx.v.a(n2, n3)];
    }

    public int d(int n2) {
        return this.T - this.W[cyou.rimuru.shootingstardemo.client.fx.v.a(3 - n2, 3)];
    }

    public static int a(int n2, int n3) {
        return n3 * 8 + n2;
    }

    private void g(float f2) {
        int n2 = this.Q.a(f2);
        if (n2 >= 0) {
            this.a(cyou.rimuru.shootingstardemo.registry.g.aa[n2], this.f() ? 0.0 : cyou.rimuru.shootingstardemo.client.fx.e.c().distanceTo(this.a(cyou.rimuru.shootingstardemo.client.fx.e.c())));
        }
    }

    private void a(SoundEvent soundEvent, double d2) {
        float f2 = (float)Mth.clamp((double)((2800.0 - d2) / 1400.0), (double)0.0, (double)1.0);
        N.append(N.isEmpty() ? "" : " ").append(this.w).append(':').append(soundEvent.location().getPath()).append(String.format(Locale.ROOT, "@%.2f~%+d", Float.valueOf(f2), this.Q.b()));
        if (f2 < 0.01f) {
            if (this.P != null) {
                this.P.a(3);
                this.P = null;
            }
            return;
        }
        boolean bl = this.P != null && !this.P.isStopped() && Minecraft.getInstance().getSoundManager().isActive((SoundInstance)this.P);
        k k2 = new k(this.v, soundEvent.location(), f2, bl ? 3 : 0, SoundInstance.Attenuation.NONE, 0.0, 0.0, 0.0, true);
        if (this.P != null) {
            this.P.a(3);
        }
        Minecraft.getInstance().getSoundManager().play((SoundInstance)k2);
        this.P = k2;
    }

    public static String u() {
        return N.toString();
    }

    @Override
    protected void h() {
        if (this.P != null) {
            Minecraft.getInstance().getSoundManager().stop((SoundInstance)this.P);
            this.P = null;
        }
    }

    Vec3 a(Vec3 vec3) {
        double d2 = Mth.clamp((double)vec3.x, (double)this.R, (double)(this.R + this.z));
        double d3 = Mth.clamp((double)vec3.z, (double)this.S, (double)(this.S + this.z));
        return new Vec3(d2, Mth.clamp((double)vec3.y, (double)this.T, (double)this.ag), d3);
    }

    private void a(ClientLevel clientLevel, int n2) {
        for (int i2 = 0; i2 < this.Y.length; ++i2) {
            if (n2 >= this.X[i2] - 30) continue;
            int n3 = this.R + i2 % 8 * this.A;
            int n4 = this.S + i2 / 8 * this.A;
            int n5 = Integer.MIN_VALUE;
            int n6 = Math.max(4, this.A / 16);
            for (int i3 = n3; i3 < n3 + this.A; i3 += n6) {
                for (int i4 = n4; i4 < n4 + this.A; i4 += n6) {
                    int n7;
                    int n8 = clientLevel.getHeight(Heightmap.Types.MOTION_BLOCKING, i3, i4);
                    if (n8 >= (n7 = this.af.get(cyou.rimuru.shootingstardemo.client.fx.v.c(i3, i4)))) {
                        n8 = this.a(clientLevel, i3, i4, n7);
                    }
                    if (n8 <= clientLevel.getMinY() + 1) continue;
                    n5 = Math.max(n5, n8 + 1);
                }
            }
            if (n5 == Integer.MIN_VALUE) continue;
            this.Y[i2] = Math.max(n5, this.U);
            this.Z[i2] = true;
        }
    }

    private int[] b(int n2, int n3) {
        int n4 = n2 % 8;
        int n5 = n2 / 8;
        int n6 = Math.min(this.Y[n2] - this.U, n3 - this.U);
        if (n6 <= 1 || !this.Z[n2]) {
            return null;
        }
        int n7 = cyou.rimuru.shootingstardemo.star.l.a(this.q, n4, n5, n6, this.A, this.y, this.U, n3);
        int n8 = n7 == 3 ? this.A : n6;
        int[] nArray = cyou.rimuru.shootingstardemo.star.l.a(this.q, n4, n5, this.y, this.U, n8, n3);
        return new int[]{nArray[0], nArray[1], n7 == 3 ? Math.min(n6, this.A) : this.A, n8};
    }

    private List<int[]> a(int n2, int[] nArray, int n3) {
        int n4 = n2 % 8;
        int n5 = n2 / 8;
        return cyou.rimuru.shootingstardemo.star.l.a(this.q, n4, n5, this.A, nArray[3], nArray[1], this.R + n4 * this.A, this.S + n5 * this.A, this.U + this.B, n3);
    }

    public void a(Consumer<double[]> consumer) {
        double d2;
        ClientLevel clientLevel = Minecraft.getInstance().level;
        if (clientLevel == null || !this.ac) {
            return;
        }
        int n2 = clientLevel.getMaxY();
        for (int i2 = 0; i2 < 64; ++i2) {
            Object object;
            Object object2;
            d2 = this.R + i2 % 8 * this.A;
            double d3 = this.S + i2 / 8 * this.A;
            float[] fArray = this.aa[i2];
            if (fArray != null) {
                consumer.accept(new double[]{d2, fArray[0], d3, d2 + (double)this.A, fArray[0] + fArray[1], d3 + (double)this.A, this.X[i2]});
                if (this.ae[i2] == null) continue;
                object2 = this.ae[i2].iterator();
                while (object2.hasNext()) {
                    object = (int[])object2.next();
                    consumer.accept(cyou.rimuru.shootingstardemo.client.fx.v.a((int[])object, this.X[i2]));
                }
                continue;
            }
            if (this.X[i2] < this.w || (object2 = this.ab[i2]) == null) continue;
            consumer.accept(new double[]{d2, object2[0], d3, d2 + (double)this.A, object2[0] + object2[1], d3 + (double)this.A, this.X[i2]});
            object = this.a(i2, (int[])object2, n2).iterator();
            while (object.hasNext()) {
                int[] nArray = (int[])object.next();
                consumer.accept(cyou.rimuru.shootingstardemo.client.fx.v.a(nArray, this.X[i2]));
            }
        }
        Vec3 vec3 = this.s();
        d2 = (double)cyou.rimuru.shootingstardemo.star.l.f(this.y) + 1.0;
        consumer.accept(new double[]{vec3.x - d2, vec3.y - d2, vec3.z - d2, vec3.x + d2, vec3.y + d2, vec3.z + d2, 562.0});
    }

    private static double[] a(int[] nArray, int n2) {
        int n3 = 16;
        return new double[]{nArray[3], nArray[4], nArray[5], nArray[3] + n3, nArray[4] + n3, nArray[5] + n3, n2};
    }

    private void c(ClientLevel clientLevel) {
        int n2 = Integer.MAX_VALUE;
        for (int i2 = 0; i2 < this.ab.length; ++i2) {
            this.ab[i2] = this.b(i2, clientLevel.getMaxY());
            if (this.ab[i2] == null || cyou.rimuru.shootingstardemo.star.l.a(i2 % 8, i2 / 8) != 0) continue;
            n2 = Math.min(n2, this.ab[i2][0]);
        }
        this.ag = cyou.rimuru.shootingstardemo.star.l.a(this.U + this.B, cyou.rimuru.shootingstardemo.star.l.f(this.y), n2, clientLevel.getMaxY());
        this.ac = true;
    }

    public boolean v() {
        return this.ac;
    }

    public double w() {
        if (!this.ac) {
            return Double.NaN;
        }
        double d2 = Double.POSITIVE_INFINITY;
        for (int i2 = 0; i2 < this.ab.length; ++i2) {
            float[] fArray = this.aa[i2];
            double d3 = fArray != null ? (double)fArray[0] : (this.ab[i2] != null ? (double)this.ab[i2][0] : Double.POSITIVE_INFINITY);
            d2 = Math.min(d2, d3);
        }
        return Double.isInfinite(d2) ? Double.NaN : d2;
    }

    public boolean e(int n2) {
        return this.aa[n2] != null;
    }

    public int x() {
        return this.A;
    }

    public int f(int n2) {
        return this.X[n2];
    }

    public int b(double d2, double d3) {
        int n2 = Mth.floor((double)((d2 - (double)this.R) / (double)this.A));
        int n3 = Mth.floor((double)((d3 - (double)this.S) / (double)this.A));
        return n2 < 0 || n3 < 0 || n2 >= 8 || n3 >= 8 ? -1 : cyou.rimuru.shootingstardemo.client.fx.v.a(n2, n3);
    }

    public l y() {
        return this.ad;
    }

    private void b(ClientLevel clientLevel, int n2) {
        int[] nArray = this.b(n2, clientLevel.getMaxY());
        if (nArray == null) {
            return;
        }
        this.aa[n2] = new float[]{nArray[0], nArray[1], nArray[2]};
        List<int[]> list = this.a(n2, nArray, clientLevel.getMaxY());
        if (!list.isEmpty()) {
            this.ae[n2] = list;
            this.D += list.size();
            for (int[] nArray2 : list) {
                for (int i2 = nArray2[3]; i2 < nArray2[3] + 16; ++i2) {
                    for (int i3 = nArray2[5]; i3 < nArray2[5] + 16; ++i3) {
                        long l2 = cyou.rimuru.shootingstardemo.client.fx.v.c(i2, i3);
                        this.af.put(l2, Math.min(this.af.get(l2), nArray2[4]));
                    }
                }
            }
        }
    }

    private int a(ClientLevel clientLevel, int n2, int n3, int n4) {
        BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
        for (int i2 = n4 - 1; i2 > this.U; --i2) {
            if (clientLevel.getBlockState((BlockPos)mutableBlockPos.set(n2, i2, n3)).isAir()) continue;
            return i2;
        }
        return this.U - 1;
    }

    private static long c(int n2, int n3) {
        return (long)n2 << 32 | (long)n3 & 0xFFFFFFFFL;
    }

    @Override
    protected void a(Minecraft minecraft, ClientLevel clientLevel, int n2) {
        double d2;
        double d3;
        int n3;
        if (n2 % 10 == 0 || n2 == 461) {
            this.a(clientLevel, n2);
        }
        if (n2 == 461) {
            this.c(clientLevel);
        }
        Vec3 vec3 = this.a(cyou.rimuru.shootingstardemo.client.fx.e.c());
        if (n2 == 0 && (this.C || this.t)) {
            cyou.rimuru.shootingstardemo.client.fx.r.ab.values().forEach(cyou.rimuru.shootingstardemo.client.render.a::a);
        }
        if (n2 == J[0]) {
            this.a(cyou.rimuru.shootingstardemo.registry.g.aa[0], this.f() ? 0.0 : cyou.rimuru.shootingstardemo.client.fx.e.c().distanceTo(vec3));
            this.Q.a();
        }
        this.g(n2);
        if (n2 == 9) {
            for (n3 = 0; n3 < 280; ++n3) {
                double d4 = this.u.nextDouble() * (double)this.z;
                int n4 = n3 % 4;
                double d5 = n4 == 0 ? (double)this.R + d4 : (n4 == 1 ? (double)(this.R + this.z) : (d3 = n4 == 2 ? (double)this.R + d4 : (double)this.R));
                d2 = n4 == 0 ? (double)this.S : (n4 == 1 ? (double)this.S + d4 : (n4 == 2 ? (double)(this.S + this.z) : (double)this.S + d4));
                cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(x[(int)((d3 - (double)this.R + d2 - (double)this.S) * 7.0 / (double)(2 * this.z + 1))], 1.4f), this.a(clientLevel, d3, d2).add(0.0, 0.5, 0.0), 0.0, 0.2 + this.u.nextDouble() * 0.6, 0.0);
            }
        }
        if (n2 == 426) {
            cyou.rimuru.shootingstardemo.client.fx.e.a(this.i(), 1.6f, 1600.0);
            Vec3 vec32 = this.i();
            for (int i2 = 0; i2 < 500; ++i2) {
                double d6 = this.u.nextDouble() * Math.PI * 2.0;
                d3 = 2.0 + this.u.nextDouble() * 5.0;
                d2 = (double)this.z * 0.5 * this.u.nextDouble();
                Vec3 vec33 = this.a(clientLevel, vec32.x + Math.cos(d6) * d2, vec32.z + Math.sin(d6) * d2);
                cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(i2 % 5 == 0 ? 0xFFFFFF : x[i2 % 7], 1.6f + this.u.nextFloat() * 2.0f), vec33.add(0.0, 0.5, 0.0), Math.cos(d6) * d3, 0.2 + this.u.nextDouble() * 0.8, Math.sin(d6) * d3);
            }
        }
        if (n2 >= 438 && n2 < 462) {
            this.c(clientLevel, n2);
        }
        if (n2 == 462) {
            cyou.rimuru.shootingstardemo.client.fx.e.a(this.i(), 1.4f, 1200.0);
        }
        for (n3 = 0; n3 < 4; ++n3) {
            if (n2 != 474 + n3 * 20) continue;
            cyou.rimuru.shootingstardemo.client.fx.e.a(this.i(), 1.0f + 0.25f * (float)n3, 1200.0);
        }
        for (n3 = 0; n3 < this.X.length; ++n3) {
            if (n2 == this.X[n3]) {
                this.b(clientLevel, n3);
                if (this.aa[n3] != null) {
                    this.e(clientLevel, n3);
                }
                if (this.ae[n3] != null) {
                    this.f(clientLevel, n3);
                }
            }
            if (this.ae[n3] != null && n2 > this.X[n3] && n2 < this.X[n3] + 40 && n2 % 3 == 0) {
                this.g(clientLevel, n3);
            }
            if (this.aa[n3] == null || n2 <= this.X[n3] || n2 >= this.X[n3] + 120 || n2 % 2 != 0) continue;
            this.a(clientLevel, n3, n2 - this.X[n3]);
        }
        if (n2 >= 462 && n2 < 622) {
            this.d(clientLevel, n2);
        }
        if (n2 == 562) {
            cyou.rimuru.shootingstardemo.client.fx.e.a(this.s(), 1.9f, 1600.0);
            Vec3 vec34 = this.s();
            for (int i3 = 0; i3 < 700; ++i3) {
                Vec3 vec35 = new Vec3(this.d(1.0), this.d(1.0), this.d(1.0)).normalize();
                double d7 = 1.5 + this.u.nextDouble() * 4.0;
                cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(i3 % 5 == 0 ? 0xFFFFFF : x[i3 % 7], 2.0f + this.u.nextFloat() * 2.5f), vec34.add(vec35.scale(this.u.nextDouble() * 6.0)), vec35.x * d7, vec35.y * d7, vec35.z * d7);
            }
        }
        if (n2 > 562 && n2 < 1162 && n2 % 3 == 0) {
            Vec3 vec36 = this.s();
            cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(x[this.u.nextInt(7)], 0.8f), vec36.add(this.d(9.0), this.d(9.0), this.d(9.0)), this.d(0.02), this.d(0.02), this.d(0.02));
        }
    }

    private Vec3 a(ClientLevel clientLevel, double d2, double d3) {
        int n2 = clientLevel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor((double)d2), Mth.floor((double)d3));
        return new Vec3(d2, n2 <= clientLevel.getMinY() ? (double)this.T : (double)n2, d3);
    }

    private void c(ClientLevel clientLevel, int n2) {
        double d2 = (double)(n2 - 438) / 20.0 * 215.0 * this.y;
        for (int i2 = 0; i2 < 40; ++i2) {
            boolean bl = this.u.nextBoolean();
            int n3 = this.u.nextInt(9);
            double d3 = d2 * (this.u.nextBoolean() ? 1.0 : -1.0);
            double d4 = (double)(n3 * this.A) - (double)this.z * 0.5;
            double d5 = Math.signum(d3) * Math.max(Math.abs(d3) - Math.abs(d4), 0.0);
            double d6 = (double)this.R + (double)this.z * 0.5 + (bl ? d5 : d4);
            double d7 = (double)this.S + (double)this.z * 0.5 + (bl ? d4 : d5);
            if (d6 < (double)this.R || d7 < (double)this.S || d6 > (double)(this.R + this.z) || d7 > (double)(this.S + this.z) || Math.abs(d5) < 1.0) continue;
            Vec3 vec3 = this.a(clientLevel, d6, d7);
            int n4 = (int)((d6 - (double)this.R + d7 - (double)this.S) * 7.0 / (double)(2 * this.z + 1));
            cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(i2 % 3 == 0 ? 0xFFFFFF : x[Mth.clamp((int)n4, (int)0, (int)6)], 1.2f + this.u.nextFloat()), vec3.add(this.d(0.6), 0.3, this.d(0.6)), this.d(0.3), 0.3 + this.u.nextDouble() * 0.9, this.d(0.3));
        }
    }

    private void d(ClientLevel clientLevel, int n2) {
        int n3 = n2 < 474 ? 30 : 60;
        for (int i2 = 0; i2 < n3; ++i2) {
            double d2 = (double)this.R + this.u.nextDouble() * (double)this.z;
            double d3 = (double)this.S + this.u.nextDouble() * (double)this.z;
            double d4 = (double)this.U + this.u.nextDouble() * 60.0;
            int n4 = Mth.clamp((int)((int)((d2 - (double)this.R + d3 - (double)this.S) * 7.0 / (double)(2 * this.z + 1))), (int)0, (int)6);
            cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(i2 % 6 == 0 ? 0xFFFFFF : x[n4], 0.9f + this.u.nextFloat() * 1.2f), new Vec3(d2, d4, d3), this.d(0.02), 0.4 + this.u.nextDouble() * 1.2, this.d(0.02));
        }
    }

    private void e(ClientLevel clientLevel, int n2) {
        double d2;
        double d3;
        int n3;
        float[] fArray = this.aa[n2];
        double d4 = this.R + n2 % 8 * this.A;
        double d5 = this.S + n2 / 8 * this.A;
        int n4 = Mth.clamp((int)((n2 % 8 + n2 / 8) * 7 / 15), (int)0, (int)6);
        for (n3 = 0; n3 < 90; ++n3) {
            d3 = d4 + this.u.nextDouble() * (double)this.A;
            d2 = d5 + this.u.nextDouble() * (double)this.A;
            cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(n3 % 4 == 0 ? 0xFFFFFF : x[n4], 1.6f + this.u.nextFloat() * 1.6f), new Vec3(d3, (double)this.W[n2] + 1.0 + this.u.nextDouble() * 4.0, d2), this.d(0.2), 1.0 + this.u.nextDouble() * 3.0, this.d(0.2));
        }
        for (n3 = 0; n3 < 120; ++n3) {
            d3 = d4 + this.u.nextDouble() * (double)this.A;
            d2 = d5 + this.u.nextDouble() * (double)this.A;
            double d6 = (double)this.W[n2] + this.u.nextDouble() * (double)Math.max(this.U - this.W[n2] + this.B, 1);
            cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)new BlockParticleOption(ParticleTypes.BLOCK, this.b(d6)), new Vec3(d3, d6, d2), this.d(0.4), -0.4 - this.u.nextDouble() * 1.2, this.d(0.4));
        }
        for (n3 = 0; n3 < 60; ++n3) {
            d3 = d4 + this.u.nextDouble() * (double)this.A;
            BlockState blockState = clientLevel.getBlockState(BlockPos.containing((double)d3, (double)((double)fArray[0] + 0.5), (double)(d2 = d5 + this.u.nextDouble() * (double)this.A)));
            if (blockState.isAir()) continue;
            cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)new BlockParticleOption(ParticleTypes.BLOCK, blockState), new Vec3(d3, (double)fArray[0] - 0.2, d2), this.d(0.1), -0.2, this.d(0.1));
        }
    }

    private void f(ClientLevel clientLevel, int n2) {
        int n3 = 16;
        Vec3 vec3 = this.a(n2).add(0.0, (double)this.aa[n2][1] * 0.5, 0.0);
        cyou.rimuru.shootingstardemo.client.fx.e.a(vec3, 0.6f, 900.0);
        for (int[] nArray : this.ae[n2]) {
            int n4;
            int n5 = Math.floorMod(nArray[7] + n2 % 8 + n2 / 8, 7);
            for (n4 = 0; n4 < 18; ++n4) {
                double d2 = this.u.nextDouble() * (double)n3;
                int n6 = this.u.nextInt(12);
                double d3 = (n6 & 1) == 0 ? 0.0 : (double)n3;
                double d4 = (n6 & 2) == 0 ? 0.0 : (double)n3;
                Vec3 vec32 = switch (n6 / 4) {
                    case 0 -> new Vec3((double)nArray[3] + d2, (double)nArray[4] + d3, (double)nArray[5] + d4);
                    case 1 -> new Vec3((double)nArray[3] + d3, (double)nArray[4] + d2, (double)nArray[5] + d4);
                    default -> new Vec3((double)nArray[3] + d3, (double)nArray[4] + d4, (double)nArray[5] + d2);
                };
                cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(n4 % 3 == 0 ? 0xFFFFFF : x[n5], 1.4f + this.u.nextFloat() * 1.6f), vec32, this.d(0.15), this.d(0.15), this.d(0.15));
            }
            for (n4 = 0; n4 < 10; ++n4) {
                Vec3 vec33 = new Vec3((double)nArray[3] + this.u.nextDouble() * (double)n3, (double)nArray[4] - 0.2, (double)nArray[5] + this.u.nextDouble() * (double)n3);
                cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)new BlockParticleOption(ParticleTypes.BLOCK, this.b((double)nArray[4] - 40.0)), vec33, this.d(0.05), -0.3, this.d(0.05));
            }
        }
    }

    private void g(ClientLevel clientLevel, int n2) {
        int n3 = 16;
        for (int[] nArray : this.ae[n2]) {
            if (this.u.nextInt(3) != 0) continue;
            int n4 = this.u.nextInt(7);
            for (int i2 = 0; i2 < 4; ++i2) {
                Vec3 vec3 = new Vec3((double)nArray[3] + (this.u.nextBoolean() ? 0.0 : (double)n3), (double)nArray[4] + this.u.nextDouble() * (double)n3, (double)nArray[5] + (this.u.nextBoolean() ? 0.0 : (double)n3));
                cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)cyou.rimuru.shootingstardemo.client.fx.v.a(x[n4], 2.2f), vec3, 0.0, 0.0, 0.0);
            }
        }
    }

    private BlockState b(double d2) {
        return (d2 > (double)(this.T - 5) ? Blocks.DIRT : (d2 > 0.0 ? (this.u.nextInt(5) == 0 ? Blocks.ANDESITE : Blocks.STONE) : (this.u.nextInt(6) == 0 ? Blocks.TUFF : Blocks.DEEPSLATE))).defaultBlockState();
    }

    private void a(ClientLevel clientLevel, int n2, int n3) {
        float[] fArray = this.aa[n2];
        double d2 = this.R + n2 % 8 * this.A;
        double d3 = this.S + n2 / 8 * this.A;
        int n4 = Math.max(1, 8 - n3 / 16);
        for (int i2 = 0; i2 < n4; ++i2) {
            double d4;
            double d5 = d2 + this.u.nextDouble() * (double)this.A;
            BlockState blockState = clientLevel.getBlockState(BlockPos.containing((double)d5, (double)((double)fArray[0] + 0.5), (double)(d4 = d3 + this.u.nextDouble() * (double)this.A)));
            if (blockState.isAir()) continue;
            cyou.rimuru.shootingstardemo.client.fx.v.a(clientLevel, (ParticleOptions)new BlockParticleOption(ParticleTypes.FALLING_DUST, blockState), new Vec3(d5, (double)fArray[0] - 0.1, d4), 0.0, -0.05, 0.0);
        }
    }

    @Override
    public void a(d d2, List<cyou.rimuru.shootingstardemo.client.render.e> list) {
        float f2;
        float f3 = this.c(d2);
        this.g(f3);
        float f4 = this.a(d2.b());
        float f5 = cyou.rimuru.shootingstardemo.client.cinematic.d.a(this.O);
        boolean bl = !Float.isNaN(f4) && f5 > 0.001f;
        float f6 = f2 = bl ? cyou.rimuru.shootingstardemo.client.fx.x.h(f4) * f5 : 0.0f;
        if (f2 < 0.999f) {
            this.b(d2, list, f3);
            this.a(d2, list, f3);
        }
        if (f2 > 0.001f) {
            float f7 = this.r;
            list.add(new cyou.rimuru.shootingstardemo.client.render.e("tess_space", j2 -> {
                cyou.rimuru.shootingstardemo.client.fx.r.ab.forEach(j2::a);
                cyou.rimuru.shootingstardemo.client.fx.x.a(f4, f2, f7, cyou.rimuru.shootingstardemo.client.fx.v.a(j2));
            }));
        }
    }

    private static BiConsumer<String, float[]> a(cyou.rimuru.shootingstardemo.client.render.j j2) {
        return (string, fArray) -> {
            switch (((float[])fArray).length) {
                case 1: {
                    j2.b((String)string, fArray[0]);
                    break;
                }
                case 2: {
                    j2.a((String)string, fArray[0], fArray[1]);
                    break;
                }
                case 3: {
                    j2.a((String)string, fArray[0], fArray[1], fArray[2]);
                    break;
                }
                case 4: {
                    j2.a((String)string, fArray[0], fArray[1], fArray[2], fArray[3]);
                    break;
                }
                default: {
                    j2.a((String)string, (float[])fArray);
                }
            }
        };
    }

    static float b(float f2) {
        f2 = Mth.clamp((float)f2, (float)0.0f, (float)1.0f);
        return f2 * f2 * (3.0f - 2.0f * f2);
    }

    static double[] e(float f2) {
        double d2 = (double)f2 / 20.0;
        double d3 = 1.0 - (double)cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 562.0f) / 20.0f);
        return new double[]{d2 * 0.9 * d3, d2 * 0.55 * d3, d2 * 0.3 * d3, d2 * 0.18 * d3};
    }

    double f(float f2) {
        return Mth.lerp((double)cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 562.0f) / 24.0f), (double)30.0, (double)8.125) * cyou.rimuru.shootingstardemo.star.l.e(this.y);
    }

    private void a(d d2, List<cyou.rimuru.shootingstardemo.client.render.e> list, float f2) {
        if (f2 < 280.0f || f2 > 466.0f) {
            return;
        }
        double[] dArray = cyou.rimuru.shootingstardemo.client.fx.x.a(f2, this.y);
        Vec3 vec3 = this.i();
        Vec3 vec32 = d2.a(new Vec3(vec3.x, (double)this.T + dArray[0], vec3.z));
        Vec3 vec33 = d2.a(new Vec3(vec3.x, (double)this.T + dArray[3], vec3.z));
        float f3 = (float)dArray[1];
        float f4 = (float)dArray[2];
        float f5 = (float)dArray[4];
        float f6 = cyou.rimuru.shootingstardemo.client.fx.v.a(f2, 284.0f, 312.0f, 436.0f, 466.0f);
        float f7 = cyou.rimuru.shootingstardemo.client.fx.v.a(f2, 280.0f, 284.0f, 286.0f, 298.0f);
        float f8 = f2 / 20.0f;
        float[] fArray = new float[192];
        cyou.rimuru.shootingstardemo.client.fx.u.a(f2, fArray);
        list.add(new cyou.rimuru.shootingstardemo.client.render.e("tess_sky", j2 -> {
            j2.a("MilkyTop", cyou.rimuru.shootingstardemo.client.fx.r.ab.get("MilkyTop"));
            j2.a("S0", f8, f6, f4, f7);
            j2.a("MouthC", (float)vec3.x, (float)vec3.y, (float)vec3.z, f5);
            j2.a("EngC", (float)vec32.x, (float)vec32.y, (float)vec32.z, f3);
            j2.a("EngX", 1.0f, 0.0f, 0.0f);
            j2.a("EngY", 0.0f, 1.0f, 0.0f);
            j2.a("EngZ", 0.0f, 0.0f, 1.0f);
            j2.a("KeyDir", -0.42f, 0.82f, 0.39f);
            j2.a("KeyCol", 2.2f, 2.09f, 1.94f);
            j2.a("Eng", fArray);
        }));
    }

    private void b(d d2, List<cyou.rimuru.shootingstardemo.client.render.e> list, float f2) {
        Object object;
        if (f2 < 8.0f || f2 > 1262.0f) {
            return;
        }
        Vec3 vec3 = this.s();
        double[] dArray = cyou.rimuru.shootingstardemo.client.fx.v.e(f2);
        double d3 = this.f(f2);
        float f3 = cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 426.0f) / 6.0f);
        float[] fArray = new float[64];
        for (int i2 = 0; i2 < 16; ++i2) {
            object = cyou.rimuru.shootingstardemo.client.fx.x.a(i2, dArray);
            Vec3 vec32 = d2.a(vec3.add(object[0] * d3 * (double)f3, object[1] * d3 * (double)f3, object[2] * d3 * (double)f3));
            fArray[i2 * 4] = (float)vec32.x;
            fArray[i2 * 4 + 1] = (float)vec32.y;
            fArray[i2 * 4 + 2] = (float)vec32.z;
            fArray[i2 * 4 + 3] = (float)object[3];
        }
        float[] fArray2 = new float[256];
        object = d2.c();
        for (int i3 = 0; i3 < 64; ++i3) {
            float[] fArray3 = this.aa[i3];
            boolean bl = fArray3 != null && f2 >= (float)this.X[i3];
            fArray2[i3 * 4] = bl ? (f2 - (float)this.X[i3]) / 20.0f : -1.0f;
            fArray2[i3 * 4 + 1] = bl ? (float)((double)fArray3[0] - object.y) : 0.0f;
            fArray2[i3 * 4 + 2] = bl ? fArray3[1] : 0.0f;
            fArray2[i3 * 4 + 3] = bl ? fArray3[2] : (float)this.A;
        }
        Vec3 vec33 = d2.a(new Vec3((double)this.R, (double)this.T, (double)this.S));
        float f4 = cyou.rimuru.shootingstardemo.client.fx.v.a(f2, 9.0f, 10.5f, 962.0f, 1162.0f);
        float f5 = cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 426.0f) / 8.0f);
        float f6 = cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 426.0f + 1.0f) / 2.0f);
        float f7 = f2 >= 426.0f ? (f2 - 426.0f) / 20.0f : -1.0f;
        float f8 = f2 >= 438.0f ? (f2 - 438.0f) / 20.0f : -1.0f;
        float f9 = f2 >= 462.0f ? (f2 - 462.0f) / 20.0f : -1.0f;
        float f10 = f2 >= 562.0f ? (f2 - 562.0f) / 20.0f : -1.0f;
        float f11 = cyou.rimuru.shootingstardemo.client.fx.v.a(f2, 428.0f, 448.0f, 562.0f, 582.0f);
        float f12 = cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 562.0f) / 24.0f);
        float f13 = f2 < 562.0f ? 1.0f : Mth.lerp((float)cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 562.0f) / 100.0f), (float)1.0f, (float)0.4f) * (1.0f - cyou.rimuru.shootingstardemo.client.fx.v.b((f2 - 562.0f - 300.0f) / 300.0f));
        float f14 = (float)((double)this.U - object.y);
        float f15 = (float)(vec3.y - object.y);
        float f16 = f2 / 20.0f;
        float f17 = this.r;
        float f18 = (float)cyou.rimuru.shootingstardemo.client.fx.v.a(f2);
        float f19 = cyou.rimuru.shootingstardemo.client.fx.v.a(f2, 422.0f, 452.0f, 722.0f, 882.0f);
        float f20 = (float)this.y;
        float f21 = Math.round(20.0 * this.y);
        float f22 = (float)((double)(this.V + 4) - object.y);
        list.add(new cyou.rimuru.shootingstardemo.client.render.e("tess_world", j2 -> {
            j2.a("Pts", fArray);
            j2.a("Cubes", fArray2);
            j2.a("Grid", vec33);
            j2.a("P0", f16, f17, f4, f5);
            j2.a("P1", f8, f9, f10, f18);
            j2.a("P2", f14, f11, f12, f13);
            j2.a("P3", f15, this.z, f19, f20);
            j2.a("P4", f6, f7, f21, f22);
        }));
    }

    static double a(double d2) {
        if (d2 < 29.0) {
            return 0.0;
        }
        double d3 = 13.05;
        double d4 = Math.min(d2 - 29.0, 261.0) / 20.0;
        double d5 = d4 / d3;
        return 0.6 * d4 + 3.4 * d3 * d5 * d5 * d5 / 3.0;
    }

    @Override
    public void a(d d2, f f2) {
        boolean bl;
        float f3 = this.c(d2);
        float f4 = this.a(d2.b());
        float f5 = cyou.rimuru.shootingstardemo.client.cinematic.d.a(this.O);
        boolean bl2 = bl = !Float.isNaN(f4) && f5 > 0.001f;
        if (bl) {
            this.b(f2, f4, f5);
        }
        if (bl && cyou.rimuru.shootingstardemo.client.fx.x.h(f4) > 0.5f) {
            return;
        }
        Vec3 vec3 = d2.c();
        float f6 = bl ? 1.0f : (float)Mth.clamp((double)(1.0 - vec3.distanceTo(this.a(vec3)) / 1200.0), (double)0.2, (double)1.0);
        float f7 = (f3 - 9.0f) / 20.0f;
        if (f7 >= 0.0f && f7 < 1.0f) {
            f2.a(0xE8F8FF, (float)Math.exp((double)(-f7) * 6.0) * 0.2f * f6);
            f2.b = Math.max(f2.b, (float)Math.exp((double)(-f7) * 4.0) * 0.35f * f6);
        }
        float f8 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 280.0f, 286.0f, 292.0f, 312.0f);
        f2.b = Math.max(f2.b, f8 * 0.7f * f6);
        f2.a = Math.max(f2.a, f8 * 0.25f * f6);
        float f9 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 288.0f, 308.0f, 394.0f, 398.0f);
        f2.a = Math.max(f2.a, f9 * 0.12f * f6);
        float f10 = Mth.clamp((float)((f3 - 398.0f) / 28.0f), (float)0.0f, (float)1.0f);
        if (f3 >= 398.0f && f3 < 426.0f) {
            f2.d = Math.max(f2.d, f10 * f10 * 0.8f * f6);
            f2.b = Math.max(f2.b, f10 * 1.2f * f6);
            f2.a = Math.max(f2.a, (0.2f + f10 * f10 * 0.9f) * f6);
        }
        cyou.rimuru.shootingstardemo.client.fx.v.a(f2, cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 423.0f, 424.0f, 425.0f, 426.0f) * 0.6f, 0.0f);
        float f11 = (f3 - 426.0f) / 20.0f;
        if (f11 >= 0.0f && f11 < 2.5f) {
            if (f11 < 0.05f) {
                f2.a(0xFFFFFF, 5.0f * f6);
            } else if (f11 - 0.05f < (float)E.length * 0.083333336f) {
                cyou.rimuru.shootingstardemo.client.fx.v.a(f2, f11 - 0.05f, this.i().add(0.0, 40.0, 0.0), f6, 0.083333336f, E);
                f2.y = f2.y > 0.0f ? Math.min(f2.y, 12.0f) : 12.0f;
            }
            f2.a(x[(int)(f11 * 9.0f) % 7], (float)Math.exp((double)(-f11) * 5.0) * 0.7f * f6);
            f2.a = Math.max(f2.a, cyou.rimuru.shootingstardemo.client.fx.v.a(f11, 0.0f, 0.02f, 0.6f, 2.0f) * 1.5f * f6);
            f2.m = Math.max(f2.m, 0.8f * cyou.rimuru.shootingstardemo.client.fx.v.a(f11, 0.0f, 0.1f, 0.8f, 2.5f));
        }
        float f12 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 438.0f, 442.0f, 460.0f, 462.0f);
        f2.a = Math.max(f2.a, f12 * (0.2f + 0.4f * (f3 - 438.0f) / 24.0f) * f6);
        f2.b = Math.max(f2.b, f12 * 0.5f * f6);
        f2.d = Math.max(f2.d, f12 * f12 * 0.25f * f6);
        cyou.rimuru.shootingstardemo.client.fx.v.a(f2, cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 457.0f, 459.0f, 461.0f, 462.0f) * 0.6f, 0.0f);
        cyou.rimuru.shootingstardemo.client.fx.v.a(f2, (f3 - 462.0f) / 20.0f, G, 0, this.i().add(0.0, 10.0, 0.0), f6, 1.0f);
        for (int i2 = 0; i2 < 4; ++i2) {
            cyou.rimuru.shootingstardemo.client.fx.v.a(f2, (f3 - 474.0f - (float)(i2 * 20)) / 20.0f, H, i2, this.i().add(0.0, 60.0, 0.0), f6, 0.7f * (0.9f + 0.1f * (float)i2));
        }
        float f13 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 474.0f, 480.0f, 552.0f, 562.0f);
        f2.a = Math.max(f2.a, f13 * 0.2f * f6);
        f2.m = Math.max(f2.m, f13 * 0.35f);
        cyou.rimuru.shootingstardemo.client.fx.v.a(f2, cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 554.0f, 557.0f, 561.0f, 562.0f) * 0.7f, 0.0f);
        float f14 = (f3 - 562.0f) / 20.0f;
        if (f14 >= 0.0f && f14 < 8.0f) {
            int n2;
            if (f14 < 0.06f) {
                f2.a(0xFFFFFF, 6.5f);
            } else if (f14 - 0.06f < (float)I.length * 0.083333336f) {
                cyou.rimuru.shootingstardemo.client.fx.v.a(f2, f14 - 0.06f, this.s(), 1.0f, 0.083333336f, I);
                n2 = (int)((f14 - 0.06f) / 0.083333336f);
                f2.y = f2.y > 0.0f ? Math.min(f2.y, 12.0f) : 12.0f;
                f2.d = Math.max(f2.d, n2 % 2 == 0 ? 1.0f : 0.3f);
                f2.b = Math.max(f2.b, n2 % 2 == 0 ? 0.5f : 1.8f);
            }
            n2 = x[(int)(f14 * 5.0f) % 7];
            f2.a(n2, (float)Math.exp((double)(-f14) * 2.5) * 0.9f);
            f2.a = Math.max(f2.a, cyou.rimuru.shootingstardemo.client.fx.v.a(f14, 0.0f, 0.02f, 1.0f, 1.8f) * 1.9f);
            f2.m = Math.max(f2.m, 1.1f * cyou.rimuru.shootingstardemo.client.fx.v.a(f14, 0.0f, 0.1f, 3.0f, 8.0f));
            f2.n = Math.max(f2.n, 1.0f + 1.2f * cyou.rimuru.shootingstardemo.client.fx.v.a(f14, 0.0f, 0.1f, 2.0f, 6.0f));
            f2.v = Math.max(f2.v, 0.2f * cyou.rimuru.shootingstardemo.client.fx.v.a(f14, 0.5f, 1.0f, 3.0f, 6.0f));
        }
    }

    private static void a(f f2, float f3, int[] nArray, int n2, Vec3 vec3, float f4, float f5) {
        if (f3 < 0.0f || f3 >= 2.5f) {
            return;
        }
        if (f3 < 0.05f) {
            f2.a(0xFFFFFF, 4.5f * f4 * f5);
        } else if (f3 - 0.05f < (float)nArray.length * 0.083333336f) {
            int n3;
            int[] nArray2 = new int[nArray.length];
            for (n3 = 0; n3 < nArray2.length; ++n3) {
                nArray2[n3] = nArray[(n3 + n2) % nArray.length];
            }
            cyou.rimuru.shootingstardemo.client.fx.v.a(f2, f3 - 0.05f, vec3, f4, 0.083333336f, nArray2);
            n3 = (int)((f3 - 0.05f) / 0.083333336f);
            f2.y = f2.y > 0.0f ? Math.min(f2.y, 12.0f) : 12.0f;
            f2.d = Math.max(f2.d, (n3 % 2 == 0 ? 0.9f : 0.25f) * f4);
        }
        f2.a(x[(int)(f3 * 9.0f + (float)(n2 * 2)) % 7], (float)Math.exp((double)(-f3) * 5.0) * 0.8f * f4);
        f2.a = Math.max(f2.a, cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 0.0f, 0.02f, 0.5f, 2.0f) * 1.2f * f4 * f5);
        f2.b = Math.max(f2.b, cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 0.0f, 0.02f, 0.4f, 1.5f) * 1.2f * f4);
        f2.m = Math.max(f2.m, 0.75f * cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 0.0f, 0.1f, 1.0f, 2.5f));
    }

    private void b(f f2, float f3, float f4) {
        float f5 = cyou.rimuru.shootingstardemo.client.fx.x.h(f3) * f4;
        f2.x = Math.max(f2.x, f5);
        if (f5 > 0.001f) {
            f2.m = Math.max(f2.m, 0.6f);
        }
        float f6 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 62.0f, 72.0f, 108.0f, 118.0f);
        f2.d = Math.max(f2.d, f6 * 0.25f);
        float f7 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 118.0f, 121.0f, 124.0f, 130.0f);
        f2.b = Math.max(f2.b, f7 * 1.6f);
        f2.a = Math.max(f2.a, f7 * 0.25f);
        f2.a(15788287, f7 * 0.15f);
        float f8 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 150.0f, 154.0f, 160.0f, 180.0f);
        f2.a = Math.max(f2.a, f8 * 0.2f);
        float f9 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 210.0f, 230.0f, 256.0f, 262.0f);
        f2.d = Math.max(f2.d, f9 * 0.18f);
        f2.a = Math.max(f2.a, f9 * 0.15f);
        float f10 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 248.0f, 249.0f, 250.0f, 256.0f);
        f2.b = Math.max(f2.b, f10 * 1.2f);
        f2.a(0xFFFFFF, f10 * 0.3f);
        float f11 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 262.0f, 270.0f, 288.0f, 290.0f);
        f2.d = Math.max(f2.d, f11 * 0.7f);
        f2.a = Math.max(f2.a, f11 * 0.35f);
        float f12 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 288.0f, 290.0f, 291.0f, 296.0f);
        f2.b = Math.max(f2.b, f12 * 0.8f);
        float f13 = Mth.clamp((float)((f3 - 336.0f) / 22.0f), (float)0.0f, (float)1.0f);
        if (f3 >= 336.0f && f3 < 358.0f) {
            f2.d = Math.max(f2.d, f13 * f13 * 0.6f);
        }
        float f14 = cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 357.0f, 358.0f, 358.6f, 362.0f);
        f2.a(0xFFFFFF, f14 * 1.2f);
    }

    @Override
    b c(float f2) {
        float f3 = (float)this.w + f2;
        float[][] fArrayArray = new float[][]{{0.0f, -0.35f}, {4.0f, -1.4f}, {9.0f, -1.4f}, {16.0f, -2.7f}, {40.0f, -2.7f}, {60.0f, -1.3f}, {622.0f, -1.3f}, {652.0f, -0.35f}};
        float f4 = fArrayArray[fArrayArray.length - 1][1];
        for (int i2 = 0; i2 < fArrayArray.length - 1; ++i2) {
            if (!(f3 >= fArrayArray[i2][0]) || !(f3 < fArrayArray[i2 + 1][0])) continue;
            f4 = Mth.lerp((float)cyou.rimuru.shootingstardemo.client.fx.v.b((f3 - fArrayArray[i2][0]) / (fArrayArray[i2 + 1][0] - fArrayArray[i2][0])), (float)fArrayArray[i2][1], (float)fArrayArray[i2 + 1][1]);
            break;
        }
        return cyou.rimuru.shootingstardemo.client.fx.b.a(f4, -0.12f, 0.0f).a(cyou.rimuru.shootingstardemo.client.fx.v.a(f3, 0.0f, 3.0f, 648.0f, 656.0f));
    }

    @Override
    boolean b(Vec3 vec3) {
        return (this.w >= 457 && this.w < 462 || this.w >= 554 && this.w < 562) && vec3.distanceTo(this.a(vec3)) < 1400.0;
    }

    @Override
    public void a(GuiGraphicsExtractor guiGraphicsExtractor, d d2) {
        String string;
        String string2;
        float f2 = this.c(d2);
        Minecraft minecraft = d2.a();
        if (minecraft.player == null || f2 < 9.0f || f2 >= 602.0f) {
            return;
        }
        Vec3 vec3 = minecraft.player.position();
        if (vec3.distanceTo(this.a(vec3)) > 300.0) {
            return;
        }
        float f3 = (float)cyou.rimuru.shootingstardemo.client.fx.j.c(guiGraphicsExtractor) / 2.0f;
        t.d d3 = cyou.rimuru.shootingstardemo.client.fx.t.a(f2 * 0.03f, 1.6f, 0.2f, 1.0f);
        t.d d4 = t.d.a(-1326254598);
        float f4 = Mth.clamp((float)((f2 - 9.0f) / 8.0f), (float)0.0f, (float)1.0f) * (1.0f - Mth.clamp((float)((f2 - 562.0f - 30.0f) / 10.0f), (float)0.0f, (float)1.0f));
        if (f2 < 462.0f) {
            string2 = "DIMENSIONAL SHEAR INBOUND";
            string = String.format(Locale.ROOT, "T\u2212%05.2f   64 CELLS", Float.valueOf((462.0f - f2) / 20.0f / this.v));
        } else {
            int n2 = 0;
            for (int i2 = 0; i2 < this.X.length; ++i2) {
                n2 += f2 >= (float)this.X[i2] ? 1 : 0;
            }
            string2 = f2 < 474.0f ? "SEVERED" : (f2 < 562.0f ? "ASCENSION" : "FOLDED");
            string = f2 < 562.0f ? String.format(Locale.ROOT, "%02d / %02d CELLS", n2, 64) : "W-AXIS LOCKED";
        }
        float f5 = cyou.rimuru.shootingstardemo.client.fx.t.a(guiGraphicsExtractor, t.a.b, string2, 1.1f, 2.6f);
        cyou.rimuru.shootingstardemo.client.fx.t.a(guiGraphicsExtractor, f3, 40.0f, f5 * 0.5f + 70.0f, 24.0f, f4 * 0.45f);
        cyou.rimuru.shootingstardemo.client.fx.t.a(guiGraphicsExtractor, t.a.b, string2, f3, 34.0f, 0.5f, 1.1f, 2.6f, d3, f4, 1.0f);
        cyou.rimuru.shootingstardemo.client.fx.t.a(guiGraphicsExtractor, t.a.c, string, f3, 50.0f, 0.5f, 0.85f, 0.4f, d4, f4, 1.0f);
    }

    public void b(GuiGraphicsExtractor guiGraphicsExtractor, d d2) {
        float f2 = this.a(d2.b());
        if (Float.isNaN(f2)) {
            return;
        }
        cyou.rimuru.shootingstardemo.client.fx.w.a(guiGraphicsExtractor, d2, this, f2, cyou.rimuru.shootingstardemo.client.cinematic.d.a(this.O));
    }
}

