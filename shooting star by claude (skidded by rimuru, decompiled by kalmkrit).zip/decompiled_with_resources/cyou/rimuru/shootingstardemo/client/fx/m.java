/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  net.minecraft.util.Mth
 *  net.minecraft.world.phys.Vec3
 */
package cyou.rimuru.shootingstardemo.client.fx;

import cyou.rimuru.shootingstardemo.client.fx.d;
import cyou.rimuru.shootingstardemo.client.fx.e;
import cyou.rimuru.shootingstardemo.client.fx.j;
import cyou.rimuru.shootingstardemo.client.fx.l;
import cyou.rimuru.shootingstardemo.client.fx.n;
import cyou.rimuru.shootingstardemo.client.fx.q;
import cyou.rimuru.shootingstardemo.client.fx.r;
import cyou.rimuru.shootingstardemo.star.c;
import cyou.rimuru.shootingstardemo.star.h;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

final class m {
    private static final int a = 12101887;
    private static final int b = 15262463;
    private static final int c = 8381183;
    private static final int d = 0xFFFFFF;

    private m() {
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, d d2, l l2, float f2, float f3) {
        Minecraft minecraft = d2.a();
        Font font = minecraft.font;
        int n2 = j.c(guiGraphicsExtractor);
        int n3 = j.d(guiGraphicsExtractor);
        float f4 = Mth.clamp((float)(f3 * 1.6f - 0.3f), (float)0.0f, (float)1.0f);
        if (f4 <= 0.01f) {
            return;
        }
        int n4 = (int)(f4 * 255.0f);
        boolean bl = (int)(f2 * 3.0f) % 13 == 0;
        int n5 = n4 << 24 | 0xB8A8FF;
        int n6 = (int)((float)n4 * 0.55f) << 24 | 0xE8E2FF;
        int n7 = n4 << 24 | 0xFFFFFF;
        int n8 = 12;
        q.a(guiGraphicsExtractor, n8, n8, 22, 1, 1, n5);
        q.a(guiGraphicsExtractor, n2 - n8, n8, 22, -1, 1, n5);
        q.a(guiGraphicsExtractor, n8, n3 - n8, 22, 1, -1, n5);
        q.a(guiGraphicsExtractor, n2 - n8, n3 - n8, 22, -1, -1, n5);
        q.a(guiGraphicsExtractor, font, "UPLINK // SS-04 > SEVEN STARS", n8 + 6, n8 + 6, bl ? n6 : n5, 1.0f);
        q.a(guiGraphicsExtractor, font, String.format(Locale.ROOT, "T+%05.2f", Float.valueOf(f2 / 20.0f)), n8 + 6, n8 + 17, n6, 1.0f);
        int n9 = 0;
        for (int i2 = 0; i2 < 7; ++i2) {
            n9 += f2 >= (float)h.c(i2) ? 1 : 0;
        }
        String string = f2 < 290.0f ? String.format(Locale.ROOT, "FIRST IMPACT T-%05.2f", Float.valueOf((290.0f - f2) / 20.0f / l2.j())) : (n9 < 7 ? String.format(Locale.ROOT, "IMPACTS %d / 7", n9) : (f2 < 440.0f ? "LINKING" : "URSA MAJOR BURNED"));
        q.b(guiGraphicsExtractor, font, string, n2 - n8 - 6, n8 + 6, n5, 1.0f);
        Vec3 vec3 = l2.f();
        q.b(guiGraphicsExtractor, font, String.format(Locale.ROOT, "FIGURE %d / %d / %d", Mth.floor((double)vec3.x), Mth.floor((double)vec3.y), Mth.floor((double)vec3.z)), n2 - n8 - 6, n3 - n8 - 14, n6, 1.0f);
        if (f2 < 62.0f || f2 >= 272.0f) {
            m.a(guiGraphicsExtractor, font, l2, f2, n2, n3, n4, n5, n6, n7);
            return;
        }
        m.b(guiGraphicsExtractor, font, l2, f2, n2, n3, n4, n5, n6, n7);
    }

    private static void a(GuiGraphicsExtractor guiGraphicsExtractor, Font font, l l2, float f2, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8;
        if (f2 >= 9.0f && f2 < 290.0f) {
            int n9;
            for (n9 = 0; n9 < 7; ++n9) {
                float f3 = l.b(f2, n9);
                Vec3 vec3 = l2.a(n9).add(0.0, cyou.rimuru.shootingstardemo.star.c.b(l2.b()), 0.0);
                float[] fArray = e.a(f3 > 0.01f ? vec3 : l2.a(n9).add(0.0, 1.0, 0.0), guiGraphicsExtractor);
                if (fArray == null) continue;
                int n10 = (int)Mth.lerp((float)f3, (float)24.0f, (float)8.0f);
                int n11 = f3 > 0.99f ? n5 : n6;
                q.a(guiGraphicsExtractor, (int)fArray[0], (int)fArray[1], n10, n11);
                if (f3 > 0.01f) {
                    float f4 = 24 + n9 * 4;
                    float f5 = n9 < 6 ? 4.0f : 14.0f;
                    int n12 = (int)((float)n4 * m.a(f2, f4, f4 + 1.0f, f4 + f5, f4 + f5 + 2.0f));
                    if (n12 <= 4) continue;
                    q.a(guiGraphicsExtractor, font, String.format(Locale.ROOT, "%s %s \u00b7 %.0f LY", cyou.rimuru.shootingstardemo.star.c.b[n9], cyou.rimuru.shootingstardemo.star.c.c[n9], cyou.rimuru.shootingstardemo.star.c.e[n9]), (int)fArray[0] + n10 + 4, (int)fArray[1] - 4, n12 << 24 | 0xB8A8FF, 1.0f);
                    continue;
                }
                q.a(guiGraphicsExtractor, font, "NODE " + (n9 + 1), (int)fArray[0] + n10 + 4, (int)fArray[1] - 4, n11, 1.0f);
            }
            if (f2 >= 24.0f) {
                n9 = 0;
                for (int i2 = 0; i2 < 7; ++i2) {
                    n9 += l.b(f2, i2) > 0.99f ? 1 : 0;
                }
                q.d(guiGraphicsExtractor, font, n9 < 7 ? String.format(Locale.ROOT, "STELLAR LOCK %d / 7", n9) : "URSA MAJOR \u00b7 ARRAY LINKED", n2 / 2, 30, n5, 1.5f);
            }
            return;
        }
        for (n8 = 0; n8 < 7; ++n8) {
            float f6 = f2 - (float)h.c(n8);
            if (!(f6 >= 0.0f) || !(f6 < 14.0f)) continue;
            int n13 = (int)((float)n4 * Mth.clamp((float)(1.0f - (f6 - 10.0f) / 4.0f), (float)0.0f, (float)1.0f));
            int n14 = f6 < 5.0f ? (int)(Math.sin((double)f2 * 91.0) * 5.0) : 0;
            q.c(guiGraphicsExtractor, font, "IMPACT " + (n8 + 1) + " \u00b7 " + cyou.rimuru.shootingstardemo.star.c.b[n8], n2 / 2 + n14, n3 / 2 - 80, n13 << 24 | 0xB8A8FF, 3.0f);
            q.c(guiGraphicsExtractor, font, String.format(Locale.ROOT, "%s URSAE MAJORIS \u00b7 %.0f LY \u00b7 CRATER \u00d8%d", cyou.rimuru.shootingstardemo.star.c.c[n8], cyou.rimuru.shootingstardemo.star.c.e[n8], (int)(cyou.rimuru.shootingstardemo.star.c.a(n8, l2.b()) * 2.0)), n2 / 2, n3 / 2 - 46, n13 << 24 | 0xE8E2FF, 1.25f);
        }
        if (f2 >= 290.0f && f2 < 398.0f) {
            for (n8 = 0; n8 < 7; ++n8) {
                boolean bl = f2 >= (float)h.c(n8);
                guiGraphicsExtractor.fill(n2 / 2 - 70 + n8 * 20, n3 - 40, n2 / 2 - 58 + n8 * 20, n3 - 36, bl ? n5 : n6);
            }
        }
        if (f2 >= 398.0f && f2 < 440.0f) {
            n8 = Mth.clamp((int)((int)((f2 - 398.0f) / 5.0f) + 1), (int)0, (int)7);
            q.d(guiGraphicsExtractor, font, String.format(Locale.ROOT, "LINK %d / 7", n8), n2 / 2, 30, n7, 2.0f);
        }
        if (f2 >= 470.0f) {
            n8 = (int)((float)n4 * Mth.clamp((float)((f2 - 440.0f - 30.0f) / 10.0f), (float)0.0f, (float)1.0f));
            q.d(guiGraphicsExtractor, font, "CONSTELLATION BURNED", n2 / 2, n3 - 64, n8 << 24 | 0xB8A8FF, 2.0f);
            q.c(guiGraphicsExtractor, font, String.format(Locale.ROOT, "URSA MAJOR \u00b7 7 STARS \u00b7 7 LINES \u00b7 %.0f BLOCKS", cyou.rimuru.shootingstardemo.star.c.a(l2.b())), n2 / 2, n3 - 40, n8 << 24 | 0xE8E2FF, 1.25f);
        }
    }

    private static int[] a(n.a a2, r.c c2, int n2, int n3) {
        double d2 = c2.c(a2.c());
        if (d2 <= 1.0E-18) {
            return null;
        }
        double d3 = Math.tan(Math.toRadians(a2.f()) * 0.5);
        double d4 = c2.c(a2.e()) / (d2 * d3);
        double d5 = c2.c(a2.d()) / (d2 * d3);
        if (Math.abs(d4) > 1.9 || Math.abs(d5) > 1.05) {
            return null;
        }
        return new int[]{(int)((double)n2 / 2.0 + d4 * (double)n3 / 2.0), (int)((double)n3 / 2.0 - d5 * (double)n3 / 2.0)};
    }

    private static void b(GuiGraphicsExtractor guiGraphicsExtractor, Font font, l l2, float f2, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8;
        int n9;
        Object object;
        n.a a2 = n.a(f2, l2.g());
        float f3 = m.a(f2, 132.0f, 135.0f, 148.0f, 152.0f);
        float f4 = 1.0f - f3;
        for (n.b b2 : f4 > 0.02f ? n.b(f2, l2.g()) : List.of()) {
            object = m.a(a2, b2.c(), n2, n3);
            if (object == null) continue;
            n9 = m.a(b2.a().equals("SOL") ? n4 << 24 | 0x7FE2FF : n5, f4);
            q.a(guiGraphicsExtractor, object[0], object[1], 7, n9);
            q.a(guiGraphicsExtractor, font, b2.a(), object[0] + 11, object[1] - 9, n9, 1.0f);
            q.a(guiGraphicsExtractor, font, b2.b(), object[0] + 11, object[1] + 1, m.a(n6, f4), 1.0f);
        }
        double d2 = n.c(f2, l2.g());
        object = d2 > 9.4607E12 ? String.format(Locale.ROOT, "RANGE %,.1f LY", d2 / 9.4607E12) : String.format(Locale.ROOT, "RANGE %,.0f KM", d2);
        q.a(guiGraphicsExtractor, font, (String)object, 18, n3 - 24, n6, 1.0f);
        if (f2 >= 96.0f && f2 < 130.0f) {
            n9 = (int)(f2 / 2.0f) % 2 == 0 ? 1 : 0;
            q.d(guiGraphicsExtractor, font, "PARALLAX \u00b7 THE FIGURE ONLY HOLDS FROM SOL", n2 / 2, 30, n9 != 0 ? n5 : n6, 1.5f);
        }
        if (f3 > 0.01f) {
            n9 = (int)((float)n4 * f3);
            n8 = f2 < 138.0f ? (int)(Math.sin((double)f2 * 91.0) * 6.0) : 0;
            q.c(guiGraphicsExtractor, font, "THE SHOOTING STAR", n2 / 2 + n8, n3 / 2 - 96, n9 << 24 | 0xB8A8FF, 4.0f);
            q.c(guiGraphicsExtractor, font, "SS-04 SEVEN STARS \u00b7 STELLAR ARRAY \u00b7 URSA MAJOR \u00b7 79-123 LY", n2 / 2, n3 / 2 - 54, n9 << 24 | 0xE8E2FF, 1.25f);
        }
        if (f2 >= 150.0f && f2 < 192.0f || f2 >= 208.0f && f2 < 236.0f) {
            n9 = n2 - 170;
            n8 = n3 / 2 - 50;
            q.a(guiGraphicsExtractor, font, "ARRAYS", n9, n8 - 14, n6, 1.0f);
            for (int i2 = 0; i2 < 7; ++i2) {
                boolean bl;
                boolean bl2 = n.a(f2, i2) > 0.5f;
                boolean bl3 = bl = n.b(f2, i2) >= 0.0f;
                int n10 = bl ? n7 : (bl2 ? n4 << 24 | 0x7FE2FF : n6);
                q.a(guiGraphicsExtractor, font, cyou.rimuru.shootingstardemo.star.c.b[i2], n9, n8 + i2 * 11, n10, 1.0f);
                q.b(guiGraphicsExtractor, font, bl ? "FIRED" : (bl2 ? "ONLINE" : "\u00b7 \u00b7 \u00b7"), n9 + 150, n8 + i2 * 11, n10, 1.0f);
            }
        }
        if (f2 >= 208.0f && f2 < 236.0f) {
            n9 = Mth.clamp((int)((int)((f2 - 208.0f) / 4.0f) + 1), (int)1, (int)7);
            q.d(guiGraphicsExtractor, font, String.format(Locale.ROOT, "FIRE %d / 7", n9), n2 / 2, 30, n7, 2.0f);
        }
        if (f2 >= 192.0f && f2 < 208.0f) {
            q.d(guiGraphicsExtractor, font, "URSA MAJOR \u00b7 7 ARMED \u00b7 SOL-3", n2 / 2, 30, n5, 1.5f);
        }
    }

    private static int a(int n2, float f2) {
        return (int)((float)(n2 >>> 24) * f2) << 24 | n2 & 0xFFFFFF;
    }

    private static float a(float f2, float f3, float f4, float f5, float f6) {
        return Mth.clamp((float)((f2 - f3) / (f4 - f3)), (float)0.0f, (float)1.0f) * (1.0f - Mth.clamp((float)((f2 - f5) / (f6 - f5)), (float)0.0f, (float)1.0f));
    }
}

