/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey
 */
package cyou.rimuru.shootingstardemo.client.fx;

import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey;

public final class b
extends Record {
    private final float c;
    private final float d;
    private final float e;
    private final float f;
    private final float g;
    private final float h;
    private final float i;
    public static final RenderStateDataKey<b> a = RenderStateDataKey.create(() -> "shooting_star_demo:caster_pose");
    public static final float b = Float.NaN;

    public b(float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        this.c = f2;
        this.d = f3;
        this.e = f4;
        this.f = f5;
        this.g = f6;
        this.h = f7;
        this.i = f8;
    }

    public b a(float f2) {
        return new b(this.c, this.d, this.e, this.f, this.g, this.h, f2);
    }

    public static b a(float f2, float f3, float f4) {
        return new b(f2, f3, f4, Float.NaN, Float.NaN, Float.NaN, 1.0f);
    }

    public static b b(float f2, float f3, float f4) {
        return new b(f2, f3, f4, f2, -f3, -f4, 1.0f);
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{b.class, "rightX;rightY;rightZ;leftX;leftY;leftZ;weight", "c", "d", "e", "f", "g", "h", "i"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{b.class, "rightX;rightY;rightZ;leftX;leftY;leftZ;weight", "c", "d", "e", "f", "g", "h", "i"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{b.class, "rightX;rightY;rightZ;leftX;leftY;leftZ;weight", "c", "d", "e", "f", "g", "h", "i"}, this, object);
    }

    public float a() {
        return this.c;
    }

    public float b() {
        return this.d;
    }

    public float c() {
        return this.e;
    }

    public float d() {
        return this.f;
    }

    public float e() {
        return this.g;
    }

    public float f() {
        return this.h;
    }

    public float g() {
        return this.i;
    }
}

