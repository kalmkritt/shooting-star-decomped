/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.world.phys.Vec3
 */
package cyou.rimuru.shootingstardemo.client.fx;

import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

public record d(Minecraft a, float b, Vec3 c) {
    public Vec3 a(Vec3 vec3) {
        return vec3.subtract(this.c);
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{d.class, "minecraft;partial;camera", "a", "b", "c"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{d.class, "minecraft;partial;camera", "a", "b", "c"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{d.class, "minecraft;partial;camera", "a", "b", "c"}, this, object);
    }
}

