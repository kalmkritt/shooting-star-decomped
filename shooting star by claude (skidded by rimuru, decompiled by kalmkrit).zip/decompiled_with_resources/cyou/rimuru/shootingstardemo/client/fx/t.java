/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.renderpearl.api.pipeline.RenderPipeline
 *  com.mojang.renderpearl.api.textures.FilterMode
 *  com.mojang.renderpearl.api.textures.GpuSampler
 *  com.mojang.renderpearl.api.textures.GpuTextureView
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.Font$GlyphVisitor
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  net.minecraft.client.gui.font.TextRenderable
 *  net.minecraft.client.gui.font.TextRenderable$Styled
 *  net.minecraft.client.gui.navigation.ScreenRectangle
 *  net.minecraft.client.gui.render.TextureSetup
 *  net.minecraft.client.renderer.RenderPipelines
 *  net.minecraft.client.renderer.state.gui.GuiElementRenderState
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.FontDescription
 *  net.minecraft.network.chat.FontDescription$Resource
 *  net.minecraft.network.chat.FormattedText
 *  net.minecraft.network.chat.MutableComponent
 *  net.minecraft.network.chat.Style
 *  net.minecraft.resources.Identifier
 *  net.minecraft.util.ARGB
 *  net.minecraft.util.Mth
 *  org.joml.Matrix3x2f
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix3x2fc
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 */
package cyou.rimuru.shootingstardemo.client.fx;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import cyou.rimuru.shootingstardemo.client.fx.v;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.font.TextRenderable;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

final class t {
    private static final int[] a = new int[]{10, 15, 20, 30, 40, 60};
    private static final float b = 7.0f;
    private static final int c = 0xF000F0;

    private t() {
    }

    static int a(float f2, float f3) {
        int n2 = v.x.length;
        float f4 = f2 - (float)Math.floor(f2 / (float)n2) * (float)n2;
        int n3 = (int)f4;
        float f5 = f4 - (float)n3;
        f5 = f5 * f5 * (3.0f - 2.0f * f5);
        int n4 = v.x[n3 % n2];
        int n5 = v.x[(n3 + 1) % n2];
        float f6 = t.a(n4 >> 16) + (t.a(n5 >> 16) - t.a(n4 >> 16)) * f5;
        float f7 = t.a(n4 >> 8) + (t.a(n5 >> 8) - t.a(n4 >> 8)) * f5;
        float f8 = t.a(n4) + (t.a(n5) - t.a(n4)) * f5;
        f6 += (1.0f - f6) * f3;
        f7 += (1.0f - f7) * f3;
        f8 += (1.0f - f8) * f3;
        return 0xFF000000 | t.a(f6) << 16 | t.a(f7) << 8 | t.a(f8);
    }

    static d a(float f2, float f3, float f4, float f7) {
        int n2 = Mth.clamp((int)((int)(f7 * 255.0f)), (int)0, (int)255) << 24;
        return (f5, f6) -> n2 | t.a(f2 + f5 * f3 + f6 * 0.35f, f4) & 0xFFFFFF;
    }

    private static float a(int n2) {
        float f2 = (float)(n2 & 0xFF) / 255.0f;
        return f2 * f2;
    }

    private static int a(float f2) {
        return Mth.clamp((int)((int)(Math.sqrt(Mth.clamp((float)f2, (float)0.0f, (float)1.0f)) * 255.0 + 0.5)), (int)0, (int)255);
    }

    private static float a(GuiGraphicsExtractor guiGraphicsExtractor) {
        Matrix3x2f matrix3x2f = new Matrix3x2f((Matrix3x2fc)guiGraphicsExtractor.pose());
        return (float)Math.sqrt(Math.abs(matrix3x2f.m00() * matrix3x2f.m11() - matrix3x2f.m01() * matrix3x2f.m10())) * (float)Minecraft.getInstance().getWindow().getGuiScale();
    }

    private static int b(float f2) {
        int n2 = 0;
        for (int i2 = 1; i2 < a.length; ++i2) {
            if (!(Math.abs((float)a[i2] / 10.0f - f2) < Math.abs((float)a[n2] / 10.0f - f2))) continue;
            n2 = i2;
        }
        return n2;
    }

    private static c a(a a2, int n2, String string, float f2) {
        Font font = Minecraft.getInstance().font;
        Style style = a2.f[n2];
        final ArrayList<TextRenderable> arrayList = new ArrayList<TextRenderable>();
        Font.GlyphVisitor glyphVisitor = new Font.GlyphVisitor(){

            public void acceptGlyph(TextRenderable.Styled styled) {
                arrayList.add(styled);
            }
        };
        float f3 = 0.0f;
        int[] nArray = string.codePoints().toArray();
        for (int i2 = 0; i2 < nArray.length; ++i2) {
            MutableComponent mutableComponent = Component.literal((String)Character.toString(nArray[i2])).withStyle(style);
            font.prepareText(mutableComponent.getVisualOrderText(), f3, 0.0f, -1, false, false, 0).visit(glyphVisitor);
            f3 += font.getSplitter().stringWidth((FormattedText)mutableComponent) + (i2 < nArray.length - 1 ? f2 : 0.0f);
        }
        return new c(arrayList, f3);
    }

    static float a(GuiGraphicsExtractor guiGraphicsExtractor, a a2, String string, float f2, float f3) {
        return t.a((a)a2, (int)t.b((float)(t.a((GuiGraphicsExtractor)guiGraphicsExtractor) * f2)), (String)string, (float)f3).b * f2;
    }

    static float a(GuiGraphicsExtractor guiGraphicsExtractor, a a2, String string, float f2, float f3, float f4, float f5, float f6, d d2, float f7, float f8) {
        if (f7 <= 0.004f || string.isEmpty()) {
            return 0.0f;
        }
        c c2 = t.a(a2, t.b(t.a(guiGraphicsExtractor) * f5), string, f6);
        float f9 = c2.b * f5;
        Matrix3x2f matrix3x2f = new Matrix3x2f((Matrix3x2fc)guiGraphicsExtractor.pose()).translate(f2 - f9 * f4, f3 - 7.0f * f5).scale(f5);
        float f10 = 7.0f - a2.d;
        if (f8 > 0.0f) {
            d d3 = d.a(-16777216);
            t.a(guiGraphicsExtractor, matrix3x2f, c2, d3, 0.9f / f5, f10, a2.d, f7 * Math.min(f8, 1.0f) * 0.28f);
            if (f8 > 1.0f) {
                t.a(guiGraphicsExtractor, matrix3x2f, c2, d3, 2.4f / f5, f10, a2.d, f7 * (f8 - 1.0f) * 0.16f);
            }
        }
        for (TextRenderable textRenderable : c2.a) {
            guiGraphicsExtractor.guiRenderState.addGlyphToCurrentLayer((GuiElementRenderState)new b((Matrix3x2fc)matrix3x2f, textRenderable, d2, c2.b, f10, a2.d, f7));
        }
        return f9;
    }

    private static void a(GuiGraphicsExtractor guiGraphicsExtractor, Matrix3x2f matrix3x2f, c c2, d d2, float f2, float f3, float f4, float f5) {
        for (int i2 = 0; i2 < 8; ++i2) {
            double d3 = (double)i2 * Math.PI / 4.0;
            Matrix3x2f matrix3x2f2 = new Matrix3x2f((Matrix3x2fc)matrix3x2f).translate((float)Math.cos(d3) * f2, (float)Math.sin(d3) * f2);
            for (TextRenderable textRenderable : c2.a) {
                guiGraphicsExtractor.guiRenderState.addGlyphToCurrentLayer((GuiElementRenderState)new b((Matrix3x2fc)matrix3x2f2, textRenderable, d2, c2.b, f3, f4, f5));
            }
        }
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2, float f3, float f4, float f5, d d2, float f6) {
        int n2 = Math.max(1, Math.min(32, (int)(Math.abs(f3 - f2) / 12.0f)));
        Matrix3x2f matrix3x2f = new Matrix3x2f((Matrix3x2fc)guiGraphicsExtractor.pose());
        for (int i2 = 0; i2 < n2; ++i2) {
            float f7 = (float)i2 / (float)n2;
            float f8 = (float)(i2 + 1) / (float)n2;
            int n3 = t.a(d2.at(f7, 0.5f), f6);
            int n4 = t.a(d2.at(f8, 0.5f), f6);
            guiGraphicsExtractor.guiRenderState.addGlyphToCurrentLayer((GuiElementRenderState)new g((Matrix3x2fc)matrix3x2f, f2 + (f3 - f2) * f7, f4, f2 + (f3 - f2) * f8, f4 + f5, n3, n3, n4, n4));
        }
    }

    private static int a(int n2, float f2) {
        return Mth.clamp((int)((int)((float)(n2 >>> 24) * f2)), (int)0, (int)255) << 24 | n2 & 0xFFFFFF;
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2, float f3, float f4, float f5, float f6, int n2) {
        for (int i2 = 0; i2 < 4; ++i2) {
            float f7 = (i2 & 1) == 0 ? -1.0f : 1.0f;
            float f8 = (i2 & 2) == 0 ? -1.0f : 1.0f;
            float f9 = f2 + f7 * f4;
            float f10 = f3 + f8 * f4;
            t.a(guiGraphicsExtractor, f9 - (f7 > 0.0f ? f5 : 0.0f), f10 - (f8 > 0.0f ? f6 : 0.0f), f5, f6, n2);
            t.a(guiGraphicsExtractor, f9 - (f7 > 0.0f ? f6 : 0.0f), f10 - (f8 > 0.0f ? f5 : 0.0f), f6, f5, n2);
        }
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2, float f3, float f4, float f5, float f6) {
        int n2 = 24;
        int n3 = 6;
        Matrix3x2f matrix3x2f = new Matrix3x2f((Matrix3x2fc)guiGraphicsExtractor.pose());
        for (int i2 = 0; i2 < n2; ++i2) {
            float f7 = 2.0f * (float)i2 / (float)n2 - 1.0f;
            float f8 = 2.0f * (float)(i2 + 1) / (float)n2 - 1.0f;
            for (int i3 = 0; i3 < n3; ++i3) {
                float f9 = 2.0f * (float)i3 / (float)n3 - 1.0f;
                float f10 = 2.0f * (float)(i3 + 1) / (float)n3 - 1.0f;
                guiGraphicsExtractor.guiRenderState.addGlyphToCurrentLayer((GuiElementRenderState)new g((Matrix3x2fc)matrix3x2f, f2 + f7 * f4, f3 + f9 * f5, f2 + f8 * f4, f3 + f10 * f5, t.a(f7, f9, f6), t.a(f7, f10, f6), t.a(f8, f9, f6), t.a(f8, f10, f6)));
            }
        }
    }

    private static int a(float f2, float f3, float f4) {
        float f5 = 1.0f - f2 * f2;
        float f6 = 1.0f - f3 * f3;
        return Mth.clamp((int)((int)(f4 * f5 * (2.0f - f5) * f6 * (2.0f - f6) * 255.0f)), (int)0, (int)255) << 24;
    }

    static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2, float f3, float f4, float f5, int n2) {
        Matrix3x2fStack matrix3x2fStack = guiGraphicsExtractor.pose();
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.translate(f2, f3);
        matrix3x2fStack.scale(f4 / 8.0f, f5 / 8.0f);
        guiGraphicsExtractor.fill(0, 0, 8, 8, n2);
        matrix3x2fStack.popMatrix();
    }

    static interface d {
        public int at(float var1, float var2);

        public static d a(int n2) {
            return (f2, f3) -> n2;
        }
    }

    static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a("display", 16.0f);
        public static final /* enum */ a b = new a("label", 9.5f);
        public static final /* enum */ a c = new a("mono", 9.5f);
        private final FontDescription[] e = new FontDescription[a.length];
        private final Style[] f = new Style[a.length];
        final float d;
        private static final /* synthetic */ a[] g;

        public static a[] values() {
            return (a[])g.clone();
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }

        private a(String string2, float f2) {
            for (int i2 = 0; i2 < a.length; ++i2) {
                this.e[i2] = new FontDescription.Resource(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)("tess_" + string2 + "_" + a[i2])));
                this.f[i2] = Style.EMPTY.withFont(this.e[i2]);
            }
            this.d = f2 * 0.7f;
        }

        private static /* synthetic */ a[] a() {
            return new a[]{a, b, c};
        }

        static {
            g = cyou.rimuru.shootingstardemo.client.fx.t$a.a();
        }
    }

    private record c(List<TextRenderable> a, float b) {
        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{c.class, "glyphs;width", "a", "b"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{c.class, "glyphs;width", "a", "b"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{c.class, "glyphs;width", "a", "b"}, this, object);
        }
    }

    private record b(Matrix3x2fc a, TextRenderable b, d c, float d, float e, float f, float g) implements GuiElementRenderState
    {
        public void buildVertices(VertexConsumer vertexConsumer) {
            this.b.render((Matrix4fc)new Matrix4f().mul(this.a), (VertexConsumer)new e(vertexConsumer, this), 0xF000F0, true);
        }

        public RenderPipeline pipeline() {
            return this.b.guiPipeline();
        }

        public TextureSetup textureSetup() {
            return TextureSetup.singleTextureWithLightmap((GpuTextureView)this.b.textureView(), (GpuSampler)RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
        }

        public ScreenRectangle scissorArea() {
            return null;
        }

        public ScreenRectangle bounds() {
            return null;
        }

        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{b.class, "pose;glyph;paint;width;capTop;cap;alpha", "a", "b", "c", "d", "e", "f", "g"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{b.class, "pose;glyph;paint;width;capTop;cap;alpha", "a", "b", "c", "d", "e", "f", "g"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{b.class, "pose;glyph;paint;width;capTop;cap;alpha", "a", "b", "c", "d", "e", "f", "g"}, this, object);
        }
    }

    private record g(Matrix3x2fc a, float b, float c, float d, float e, int f, int g, int h, int i) implements GuiElementRenderState
    {
        public void buildVertices(VertexConsumer vertexConsumer) {
            vertexConsumer.addVertexWith2DPose(this.a, this.b, this.c).setColor(this.f);
            vertexConsumer.addVertexWith2DPose(this.a, this.b, this.e).setColor(this.g);
            vertexConsumer.addVertexWith2DPose(this.a, this.d, this.e).setColor(this.i);
            vertexConsumer.addVertexWith2DPose(this.a, this.d, this.c).setColor(this.h);
        }

        public RenderPipeline pipeline() {
            return RenderPipelines.GUI;
        }

        public TextureSetup textureSetup() {
            return TextureSetup.noTexture();
        }

        public ScreenRectangle scissorArea() {
            return null;
        }

        public ScreenRectangle bounds() {
            int n2 = Mth.floor((float)Math.min(this.b, this.d));
            int n3 = Mth.floor((float)Math.min(this.c, this.e));
            return new ScreenRectangle(n2, n3, Mth.ceil((float)Math.max(this.b, this.d)) - n2, Mth.ceil((float)Math.max(this.c, this.e)) - n3).transformMaxBounds(this.a);
        }

        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{g.class, "pose;x0;y0;x1;y1;c00;c01;c10;c11", "a", "b", "c", "d", "e", "f", "g", "h", "i"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{g.class, "pose;x0;y0;x1;y1;c00;c01;c10;c11", "a", "b", "c", "d", "e", "f", "g", "h", "i"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{g.class, "pose;x0;y0;x1;y1;c00;c01;c10;c11", "a", "b", "c", "d", "e", "f", "g", "h", "i"}, this, object);
        }
    }

    private record f(Matrix3x2fc a, GpuTextureView b, float c, float d, float e, float f, float g, float h, float i, float j, int k, int l, int m, int n) implements GuiElementRenderState
    {
        public void buildVertices(VertexConsumer vertexConsumer) {
            vertexConsumer.addVertexWith2DPose(this.a, this.c, this.d).setUv(this.g, this.h).setColor(this.k);
            vertexConsumer.addVertexWith2DPose(this.a, this.c, this.f).setUv(this.g, this.j).setColor(this.l);
            vertexConsumer.addVertexWith2DPose(this.a, this.e, this.f).setUv(this.i, this.j).setColor(this.n);
            vertexConsumer.addVertexWith2DPose(this.a, this.e, this.d).setUv(this.i, this.h).setColor(this.m);
        }

        public RenderPipeline pipeline() {
            return RenderPipelines.GUI_TEXTURED;
        }

        public TextureSetup textureSetup() {
            return TextureSetup.singleTexture((GpuTextureView)this.b, (GpuSampler)RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
        }

        public ScreenRectangle scissorArea() {
            return null;
        }

        public ScreenRectangle bounds() {
            int n2 = Mth.floor((float)Math.min(this.c, this.e));
            int n3 = Mth.floor((float)Math.min(this.d, this.f));
            return new ScreenRectangle(n2, n3, Mth.ceil((float)Math.max(this.c, this.e)) - n2, Mth.ceil((float)Math.max(this.d, this.f)) - n3).transformMaxBounds(this.a);
        }

        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{f.class, "pose;view;x0;y0;x1;y1;u0;v0;u1;v1;c00;c01;c10;c11", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{f.class, "pose;view;x0;y0;x1;y1;u0;v0;u1;v1;c00;c01;c10;c11", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{f.class, "pose;view;x0;y0;x1;y1;u0;v0;u1;v1;c00;c01;c10;c11", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n"}, this, object);
        }
    }

    static final class h {
        static final float a = 11.78f;
        static final float b = 0.2f;
        static final float c = 0.7f;
        private static final int[] e = new int[]{16, 24, 40, 60, 90, 135, 200};
        private static final int f = 24;
        static final float d = 0.6f;

        private h() {
        }

        static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2, float f3, float f4, float f5, d d2, float f6, float f7) {
            if (f6 <= 0.004f) {
                return;
            }
            float f8 = f4 * t.a(guiGraphicsExtractor);
            int n2 = 0;
            for (int i2 = 1; i2 < e.length; ++i2) {
                if (!(Math.abs((float)e[i2] - f8) < Math.abs((float)e[n2] - f8))) continue;
                n2 = i2;
            }
            Identifier identifier = Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)("textures/gui/tess_title_" + e[n2] + ".png"));
            GpuTextureView gpuTextureView = Minecraft.getInstance().getTextureManager().getTexture(identifier).getTextureView();
            float f9 = f2 - 6.0899997f * f4;
            float f10 = f3 - 0.2f * f4;
            float f11 = 12.179999f * f4;
            float f12 = 1.4f * f4;
            float f13 = 0.64285713f;
            Matrix3x2f matrix3x2f = new Matrix3x2f((Matrix3x2fc)guiGraphicsExtractor.pose());
            if (f7 > 0.0f) {
                d d3 = cyou.rimuru.shootingstardemo.client.fx.t$d.a(-16777216);
                float f14 = 1.1f;
                for (int i3 = 0; i3 < 8; ++i3) {
                    double d4 = (double)i3 * Math.PI / 4.0;
                    float f15 = (float)Math.cos(d4) * f14;
                    float f16 = (float)Math.sin(d4) * f14;
                    h.a(guiGraphicsExtractor, gpuTextureView, matrix3x2f, f9 + f15, f10 + f16, f11, f12, f13, f5, d3, f6 * f7 * 0.2f);
                }
            }
            h.a(guiGraphicsExtractor, gpuTextureView, matrix3x2f, f9, f10, f11, f12, f13, f5, d2, f6);
        }

        private static void a(GuiGraphicsExtractor guiGraphicsExtractor, GpuTextureView gpuTextureView, Matrix3x2f matrix3x2f, float f2, float f3, float f4, float f5, float f6, float f7, d d2, float f8) {
            h.b(guiGraphicsExtractor, gpuTextureView, matrix3x2f, f2 + f7 * 0.5f, f3, f4, f5, 0.0f, f6, d2, f8);
            h.b(guiGraphicsExtractor, gpuTextureView, matrix3x2f, f2 - f7 * 0.5f, f3, f4, f5, f6, 1.0f, d2, f8);
        }

        private static void b(GuiGraphicsExtractor guiGraphicsExtractor, GpuTextureView gpuTextureView, Matrix3x2f matrix3x2f, float f2, float f3, float f4, float f5, float f6, float f7, d d2, float f8) {
            float f9 = 0.016420363f;
            for (int i2 = 0; i2 < 24; ++i2) {
                float f10 = (float)i2 / 24.0f;
                float f11 = (float)(i2 + 1) / 24.0f;
                guiGraphicsExtractor.guiRenderState.addGlyphToCurrentLayer((GuiElementRenderState)new f((Matrix3x2fc)matrix3x2f, gpuTextureView, f2 + f4 * f10, f3 + f5 * f6, f2 + f4 * f11, f3 + f5 * f7, f10, f6, f11, f7, h.a(d2, (f10 - f9) / (1.0f - 2.0f * f9), f6, f8), h.a(d2, (f10 - f9) / (1.0f - 2.0f * f9), f7, f8), h.a(d2, (f11 - f9) / (1.0f - 2.0f * f9), f6, f8), h.a(d2, (f11 - f9) / (1.0f - 2.0f * f9), f7, f8)));
            }
        }

        private static int a(d d2, float f2, float f3, float f4) {
            int n2 = d2.at(Mth.clamp((float)f2, (float)0.0f, (float)1.0f), Mth.clamp((float)f3, (float)0.0f, (float)1.0f));
            return Mth.clamp((int)((int)((float)(n2 >>> 24) * f4)), (int)0, (int)255) << 24 | n2 & 0xFFFFFF;
        }

        static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2, float f3, float f4, d d2, float f5, float f6) {
            float f7 = f3 + f4 * 0.5f;
            if (f5 > 0.004f) {
                t.a(guiGraphicsExtractor, f2, f7, 7.29f * f4, f4 * 1.5f, f5);
            }
            if (f6 <= 0.004f) {
                return;
            }
            GpuTextureView gpuTextureView = Minecraft.getInstance().getTextureManager().getTexture(Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"textures/gui/tess_title_glow.png")).getTextureView();
            float f8 = f2 - 6.49f * f4;
            float f9 = 12.98f * f4;
            float f10 = f3 - 0.6f * f4;
            float f11 = 2.2f * f4;
            Matrix3x2f matrix3x2f = new Matrix3x2f((Matrix3x2fc)guiGraphicsExtractor.pose());
            float f12 = 0.046224967f;
            for (int i2 = 0; i2 < 24; ++i2) {
                float f13 = (float)i2 / 24.0f;
                float f14 = (float)(i2 + 1) / 24.0f;
                int n2 = h.a(d2, (f13 - f12) / (1.0f - 2.0f * f12), 0.5f, f6);
                int n3 = h.a(d2, (f14 - f12) / (1.0f - 2.0f * f12), 0.5f, f6);
                guiGraphicsExtractor.guiRenderState.addGlyphToCurrentLayer((GuiElementRenderState)new f((Matrix3x2fc)matrix3x2f, gpuTextureView, f8 + f9 * f13, f10, f8 + f9 * f14, f10 + f11, f13, 0.0f, f14, 1.0f, n2, n2, n3, n3));
            }
        }
    }

    private static final class e
    implements VertexConsumer {
        private final VertexConsumer a;
        private final b b;
        private float c;
        private float d;

        e(VertexConsumer vertexConsumer, b b2) {
            this.a = vertexConsumer;
            this.b = b2;
        }

        public VertexConsumer addVertex(Matrix4fc matrix4fc, float f2, float f3, float f4) {
            this.c = f2;
            this.d = f3;
            this.a.addVertex(matrix4fc, f2, f3, f4);
            return this;
        }

        public VertexConsumer addVertex(float f2, float f3, float f4) {
            this.c = f2;
            this.d = f3;
            this.a.addVertex(f2, f3, f4);
            return this;
        }

        public VertexConsumer setColor(int n2) {
            float f2 = Mth.clamp((float)(this.c / Math.max(this.b.d, 0.001f)), (float)0.0f, (float)1.0f);
            float f3 = Mth.clamp((float)((this.d - this.b.e) / this.b.f), (float)0.0f, (float)1.0f);
            int n3 = this.b.c.at(f2, f3);
            int n4 = Mth.clamp((int)((int)((float)((n3 >>> 24) * (n2 >>> 24)) / 255.0f * this.b.g)), (int)0, (int)255);
            this.a.setColor(n4 << 24 | n3 & 0xFFFFFF);
            return this;
        }

        public VertexConsumer setColor(int n2, int n3, int n4, int n5) {
            return this.setColor(ARGB.color((int)n5, (int)n2, (int)n3, (int)n4));
        }

        public VertexConsumer setUv(float f2, float f3) {
            this.a.setUv(f2, f3);
            return this;
        }

        public VertexConsumer setUv1(int n2, int n3) {
            this.a.setUv1(n2, n3);
            return this;
        }

        public VertexConsumer setUv2(int n2, int n3) {
            this.a.setUv2(n2, n3);
            return this;
        }

        public VertexConsumer setUv3(float f2, float f3) {
            this.a.setUv3(f2, f3);
            return this;
        }

        public VertexConsumer setNormal(float f2, float f3, float f4) {
            this.a.setNormal(f2, f3, f4);
            return this;
        }

        public VertexConsumer setLineWidth(float f2) {
            this.a.setLineWidth(f2);
            return this;
        }
    }
}

