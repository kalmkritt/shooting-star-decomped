/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.Camera
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.sounds.SoundManager
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.util.Mth
 *  net.minecraft.world.phys.Vec3
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 *  org.joml.Vector4f
 */
package cyou.rimuru.shootingstardemo.client.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import cyou.rimuru.shootingstardemo.client.fx.b;
import cyou.rimuru.shootingstardemo.client.fx.c;
import cyou.rimuru.shootingstardemo.client.fx.d;
import cyou.rimuru.shootingstardemo.client.fx.f;
import cyou.rimuru.shootingstardemo.client.fx.j;
import cyou.rimuru.shootingstardemo.client.fx.l;
import cyou.rimuru.shootingstardemo.client.fx.o;
import cyou.rimuru.shootingstardemo.client.fx.p;
import cyou.rimuru.shootingstardemo.client.fx.v;
import cyou.rimuru.shootingstardemo.star.k;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.joml.Vector4f;

public final class e {
    private static final int a = 24;
    private static final List<o> b = new ArrayList<o>();
    private static final List<a> c = new ArrayList<a>();
    private static final cyou.rimuru.shootingstardemo.client.render.d d = new cyou.rimuru.shootingstardemo.client.render.d();
    private static final cyou.rimuru.shootingstardemo.client.render.f e = new cyou.rimuru.shootingstardemo.client.render.f();
    private static final Matrix4f f = new Matrix4f();
    private static final Matrix4f g = new Matrix4f();
    private static final Matrix4f h = new Matrix4f();
    private static Vec3 i = Vec3.ZERO;
    private static float j;
    private static float k;
    private static boolean l;

    private e() {
    }

    public static void a(cyou.rimuru.shootingstardemo.net.d d2) {
        cyou.rimuru.shootingstardemo.magic.d d3 = cyou.rimuru.shootingstardemo.magic.e.a(d2.b());
        if (d3 instanceof k) {
            k k2 = (k)d3;
            if (k2 == cyou.rimuru.shootingstardemo.star.k.b) {
                cyou.rimuru.shootingstardemo.client.fx.f.a(k2, d2);
            } else if (k2 == cyou.rimuru.shootingstardemo.star.k.c) {
                cyou.rimuru.shootingstardemo.client.fx.l.a(k2, d2);
            } else if (k2 == cyou.rimuru.shootingstardemo.star.k.d) {
                v.a(k2, d2);
            } else {
                p.a(k2, d2);
            }
        }
    }

    public static void a(o o2) {
        while (b.size() >= 24) {
            o o3 = b.removeFirst();
            o3.h();
        }
        b.add(o2);
    }

    public static void a(Minecraft minecraft) {
        ClientLevel clientLevel = minecraft.level;
        if (clientLevel == null) {
            cyou.rimuru.shootingstardemo.client.fx.e.a();
            return;
        }
        Iterator<o> iterator = b.iterator();
        while (iterator.hasNext()) {
            o o2 = iterator.next();
            o2.a(minecraft, clientLevel);
            if (!o2.k()) continue;
            iterator.remove();
            o2.h();
        }
        c.removeIf(a2 -> {
            a2.d[0] = a2.d[0] + 1;
            return a2.d[0] > 45;
        });
        boolean bl = false;
        for (o o3 : b) {
            bl |= o3.b(i);
        }
        cyou.rimuru.shootingstardemo.client.fx.e.a(bl);
        j = Math.max(0.0f, j - 0.035f);
        cyou.rimuru.shootingstardemo.client.fx.a.a();
    }

    public static void a() {
        cyou.rimuru.shootingstardemo.client.cinematic.d.g();
        for (o o2 : List.copyOf(b)) {
            o2.h();
        }
        b.clear();
        c.clear();
        cyou.rimuru.shootingstardemo.client.fx.c.a();
        cyou.rimuru.shootingstardemo.client.fx.e.a(false);
        j = 0.0f;
        k = 0.0f;
    }

    private static void a(boolean bl) {
        if (bl == l) {
            return;
        }
        l = bl;
        SoundManager soundManager = Minecraft.getInstance().getSoundManager();
        if (bl) {
            soundManager.pauseAllExcept(new SoundSource[]{SoundSource.PLAYERS, SoundSource.MASTER, SoundSource.UI});
        } else {
            soundManager.resume();
        }
    }

    public static b a(int n2, float f2) {
        for (int i2 = b.size() - 1; i2 >= 0; --i2) {
            b b2;
            o o2 = b.get(i2);
            if (o2.m() != n2 || (b2 = o2.c(f2)) == null) continue;
            return b2;
        }
        return null;
    }

    public static boolean b() {
        return !b.isEmpty();
    }

    public static o a(cyou.rimuru.shootingstardemo.magic.d d2) {
        for (int i2 = b.size() - 1; i2 >= 0; --i2) {
            if (cyou.rimuru.shootingstardemo.client.fx.e.b.get((int)i2).m != d2) continue;
            return b.get(i2);
        }
        return null;
    }

    public static void a(Vec3 vec3, float f2, double d2) {
        double d3 = i.distanceTo(vec3);
        float f3 = (float)Mth.clamp((double)(1.0 - d3 / d2), (double)0.0, (double)1.0);
        j = Math.min(1.0f, j + f2 * f3);
    }

    public static void a(String string, Vec3 vec3, int n2) {
        c.add(new a(string, vec3, n2, new int[1]));
    }

    public static void a(Matrix4fc matrix4fc) {
        f.set(matrix4fc);
    }

    public static void b(Matrix4fc matrix4fc) {
        g.set(matrix4fc);
    }

    public static void a(Camera camera, float f2) {
        Minecraft minecraft = Minecraft.getInstance();
        i = camera.position();
        h.set((Matrix4fc)g).mul((Matrix4fc)f);
        if (b.isEmpty() && j <= 0.0f && !cyou.rimuru.shootingstardemo.client.cinematic.d.i()) {
            k = 0.0f;
            return;
        }
        d d2 = new d(minecraft, f2, i);
        ArrayList<cyou.rimuru.shootingstardemo.client.render.e> arrayList = new ArrayList<cyou.rimuru.shootingstardemo.client.render.e>();
        e.a();
        for (o o2 : b) {
            if (o2.l().distanceTo(i) > o2.a()) continue;
            o2.a(d2, arrayList);
            o2.a(d2, e);
        }
        k = cyou.rimuru.shootingstardemo.client.fx.e.e.a;
        cyou.rimuru.shootingstardemo.client.fx.e.e.a = Math.min(1.0f, cyou.rimuru.shootingstardemo.client.fx.e.e.a * 0.4f + j * j * 0.35f);
        if (arrayList.isEmpty() && e.b()) {
            return;
        }
        float f3 = ((float)(minecraft.level == null ? 0L : minecraft.level.getGameTime() % 24000L) + f2) / 20.0f;
        d.a(arrayList, e, g, f, f3);
    }

    public static void a(PoseStack poseStack, float f2) {
        float f3;
        float f4 = cyou.rimuru.shootingstardemo.client.cinematic.d.k();
        if (Math.abs(f4) > 0.001f) {
            poseStack.rotate((Quaternionfc)Axis.ZP.rotationDegrees(f4));
        }
        if ((f3 = j * j + k * 0.25f) <= 1.0E-4f) {
            return;
        }
        float f5 = (float)(System.nanoTime() % 100000000000L) / 1.0E9f;
        float f6 = (float)(Math.sin((double)f5 * 37.0) * 0.6 + Math.sin((double)f5 * 61.0) * 0.4) * 2.6f * f3;
        float f7 = (float)(Math.sin((double)f5 * 43.0 + 1.3) * 0.6 + Math.sin((double)f5 * 71.0) * 0.4) * 2.2f * f3;
        float f8 = (float)Math.sin((double)f5 * 29.0 + 0.7) * 3.0f * f3;
        poseStack.rotate((Quaternionfc)Axis.ZP.rotationDegrees(f8));
        poseStack.rotate((Quaternionfc)Axis.XP.rotationDegrees(f7));
        poseStack.rotate((Quaternionfc)Axis.YP.rotationDegrees(f6));
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor, float f2) {
        Minecraft minecraft = Minecraft.getInstance();
        d d2 = new d(minecraft, f2, i);
        cyou.rimuru.shootingstardemo.client.fx.j.a(guiGraphicsExtractor);
        for (o o2 : b) {
            if (o2 instanceof p) {
                p p2 = (p)o2;
                p2.b(guiGraphicsExtractor, d2);
                continue;
            }
            if (o2 instanceof f) {
                f f3 = (f)o2;
                f3.b(guiGraphicsExtractor, d2);
                continue;
            }
            if (o2 instanceof l) {
                l l2 = (l)o2;
                l2.b(guiGraphicsExtractor, d2);
                continue;
            }
            if (!(o2 instanceof v)) continue;
            v v2 = (v)o2;
            v2.b(guiGraphicsExtractor, d2);
        }
        cyou.rimuru.shootingstardemo.client.fx.j.b(guiGraphicsExtractor);
    }

    public static void b(GuiGraphicsExtractor guiGraphicsExtractor, float f2) {
        Minecraft minecraft = Minecraft.getInstance();
        d d2 = new d(minecraft, f2, i);
        cyou.rimuru.shootingstardemo.client.fx.j.a(guiGraphicsExtractor);
        for (o object : b) {
            object.a(guiGraphicsExtractor, d2);
        }
        cyou.rimuru.shootingstardemo.client.fx.j.b(guiGraphicsExtractor);
        for (a a2 : c) {
            int n2;
            float[] fArray = cyou.rimuru.shootingstardemo.client.fx.e.a(a2.b.add(0.0, (double)a2.d[0] * 0.03, 0.0), guiGraphicsExtractor);
            if (fArray == null || (n2 = (int)(255.0 * Mth.clamp((double)(1.0 - (double)(a2.d[0] - 25) / 20.0), (double)0.0, (double)1.0))) < 8) continue;
            int n3 = minecraft.font.width(a2.a);
            guiGraphicsExtractor.text(minecraft.font, a2.a, (int)fArray[0] - n3 / 2, (int)fArray[1], n2 << 24 | a2.c & 0xFFFFFF, true);
        }
    }

    public static float[] a(Vec3 vec3, GuiGraphicsExtractor guiGraphicsExtractor) {
        Vec3 vec32 = vec3.subtract(i);
        Vector4f vector4f = h.transform(new Vector4f((float)vec32.x, (float)vec32.y, (float)vec32.z, 1.0f));
        if (vector4f.w <= 0.05f) {
            return null;
        }
        float f2 = (vector4f.x / vector4f.w * 0.5f + 0.5f) * (float)cyou.rimuru.shootingstardemo.client.fx.j.c(guiGraphicsExtractor);
        float f3 = (1.0f - (vector4f.y / vector4f.w * 0.5f + 0.5f)) * (float)cyou.rimuru.shootingstardemo.client.fx.j.d(guiGraphicsExtractor);
        return new float[]{f2, f3};
    }

    public static float[] a(Vec3 vec3) {
        Vec3 vec32 = vec3.subtract(i);
        Vector4f vector4f = h.transform(new Vector4f((float)vec32.x, (float)vec32.y, (float)vec32.z, 1.0f));
        if (vector4f.w <= 0.05f) {
            return new float[]{0.5f, 0.5f};
        }
        return new float[]{Mth.clamp((float)(vector4f.x / vector4f.w * 0.5f + 0.5f), (float)0.0f, (float)1.0f), Mth.clamp((float)(vector4f.y / vector4f.w * 0.5f + 0.5f), (float)0.0f, (float)1.0f)};
    }

    public static Vec3 c() {
        return i;
    }

    public static boolean a(String string) {
        return d.a(string);
    }

    public static void d() {
        d.a();
    }

    private record a(String a, Vec3 b, int c, int[] d) {
        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{a.class, "text;at;color;age", "a", "b", "c", "d"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{a.class, "text;at;color;age", "a", "b", "c", "d"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{a.class, "text;at;color;age", "a", "b", "c", "d"}, this, object);
        }
    }
}

