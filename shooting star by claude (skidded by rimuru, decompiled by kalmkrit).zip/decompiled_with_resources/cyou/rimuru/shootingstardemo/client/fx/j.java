/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiGraphicsExtractor
 *  org.joml.Matrix3x2fStack
 */
package cyou.rimuru.shootingstardemo.client.fx;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Matrix3x2fStack;

public final class j {
    static final float a = 710.0f;
    private static float b = 1.0f;
    private static int c;

    private j() {
    }

    public static void a(GuiGraphicsExtractor guiGraphicsExtractor) {
        if (c++ == 0) {
            b = (float)guiGraphicsExtractor.guiHeight() / 710.0f;
        }
        Matrix3x2fStack matrix3x2fStack = guiGraphicsExtractor.pose();
        matrix3x2fStack.pushMatrix();
        matrix3x2fStack.scale(b, b);
    }

    public static void b(GuiGraphicsExtractor guiGraphicsExtractor) {
        guiGraphicsExtractor.pose().popMatrix();
        if (--c == 0) {
            b = 1.0f;
        }
    }

    public static int c(GuiGraphicsExtractor guiGraphicsExtractor) {
        return (int)Math.ceil((float)guiGraphicsExtractor.guiWidth() / b);
    }

    public static int d(GuiGraphicsExtractor guiGraphicsExtractor) {
        return (int)Math.ceil((float)guiGraphicsExtractor.guiHeight() / b);
    }
}

