/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.resources.sounds.SimpleSoundInstance
 *  net.minecraft.client.resources.sounds.Sound
 *  net.minecraft.client.resources.sounds.SoundInstance$Attenuation
 *  net.minecraft.client.sounds.SoundManager
 *  net.minecraft.client.sounds.WeighedSoundEvents
 *  net.minecraft.resources.Identifier
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.util.RandomSource
 */
package cyou.rimuru.shootingstardemo.client.fx;

import cyou.rimuru.shootingstardemo.client.fx.y;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

public class s
extends SimpleSoundInstance {
    private final float a;

    public s(float f2, Identifier identifier, SoundSource soundSource, float f3, float f4, RandomSource randomSource, boolean bl, int n2, SoundInstance.Attenuation attenuation, double d2, double d3, double d4, boolean bl2) {
        super(identifier, soundSource, f3, f4, randomSource, bl, n2, attenuation, d2, d3, d4, bl2);
        this.a = f2;
    }

    public WeighedSoundEvents getOrResolve(SoundManager soundManager) {
        WeighedSoundEvents weighedSoundEvents = super.getOrResolve(soundManager);
        if (y.a(this.a) && this.sound != null && this.sound != SoundManager.EMPTY_SOUND && this.sound != SoundManager.INTENTIONALLY_EMPTY_SOUND && !this.sound.shouldStream() && !this.sound.getLocation().getPath().startsWith("stretch/")) {
            this.sound = new Sound(y.a(this.sound.getLocation(), this.a), this.sound.getVolume(), this.sound.getPitch(), this.sound.getWeight(), this.sound.getType(), false, false, this.sound.getAttenuationDistance());
        }
        return weighedSoundEvents;
    }
}

