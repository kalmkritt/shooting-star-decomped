/*
 * Decompiled with CFR 0.152.
 */
package cyou.rimuru.shootingstardemo.client.render;

import cyou.rimuru.shootingstardemo.client.render.j;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import java.util.function.Consumer;

public record e(String a, Consumer<j> b) {
    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{e.class, "program;setup", "a", "b"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{e.class, "program;setup", "a", "b"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{e.class, "program;setup", "a", "b"}, this, object);
    }
}

