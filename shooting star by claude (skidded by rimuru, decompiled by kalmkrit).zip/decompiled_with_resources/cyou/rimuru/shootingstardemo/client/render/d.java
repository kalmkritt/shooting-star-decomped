/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.pipeline.RenderTarget
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.renderpearl.backend.opengl.GlTexture
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.Mth
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL13
 *  org.lwjgl.opengl.GL15
 *  org.lwjgl.opengl.GL20
 *  org.lwjgl.opengl.GL30
 *  org.lwjgl.opengl.GL33
 */
package cyou.rimuru.shootingstardemo.client.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.backend.opengl.GlTexture;
import cyou.rimuru.shootingstardemo.ShootingStarDemo;
import cyou.rimuru.shootingstardemo.client.render.e;
import cyou.rimuru.shootingstardemo.client.render.f;
import cyou.rimuru.shootingstardemo.client.render.g;
import cyou.rimuru.shootingstardemo.client.render.j;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;

public final class d {
    private final Map<String, g> a = new HashMap<String, g>();
    private final Set<String> b = new HashSet<String>();
    private static final int c = 5;
    private static final double d = 2300000.0;
    private final int[] e = new int[2];
    private final int[] f = new int[2];
    private final int[] g = new int[5];
    private final int[] h = new int[5];
    private final int[] i = new int[5];
    private final int[] j = new int[5];
    private final int[][] k = new int[5][2];
    private final FloatBuffer l = BufferUtils.createFloatBuffer((int)16);
    private final a m = new a(this);
    private static final int n = 64;
    private static final long o = 33000000L;
    private final int[] p = new int[64];
    private final long[] q = new long[64];
    private int r;
    private int s;
    private int t;
    private int u;
    private int v;
    private long w;
    private int x;
    private int y;
    private int z;
    private int A;
    private int B;
    private int C;
    private int D;
    private int E;
    private int F;
    private int G;
    private int H;
    private int I;
    private int J;
    private int K;
    private int L;
    private int M;
    private boolean N;
    private float O;
    private boolean P;
    private int Q;
    private final int[] R = new int[2];
    private final int[] S = new int[2];
    private double T = 1.0;
    private double U = 1.0;
    private double V;
    private long W;
    private int X;
    private int Y;
    private boolean Z;
    private int aa;
    private int ab;
    private boolean ac;
    private long ad;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a(List<e> list, f f2, Matrix4f matrix4f, Matrix4f matrix4f2, float f3) {
        GlTexture glTexture;
        Object object;
        RenderTarget renderTarget;
        block26: {
            block25: {
                Minecraft minecraft = Minecraft.getInstance();
                renderTarget = minecraft.gameRenderer.mainRenderTarget();
                object = renderTarget.getColorTexture();
                if (!(object instanceof GlTexture)) break block25;
                glTexture = (GlTexture)object;
                object = renderTarget.getDepthTexture();
                if (object instanceof GlTexture) break block26;
            }
            return;
        }
        GlTexture glTexture2 = (GlTexture)object;
        RenderSystem.assertOnRenderThread();
        this.O = f3;
        object = cyou.rimuru.shootingstardemo.client.render.d$b.a();
        try {
            int n2;
            boolean bl;
            double d2;
            boolean bl2;
            long l2 = System.nanoTime();
            boolean bl3 = bl2 = f2.y > 0.5f && this.ac && this.E == renderTarget.width && this.F == renderTarget.height;
            if (bl2 && l2 - this.ad < (long)(1.0E9 / (double)f2.y)) {
                GL30.glBindFramebuffer((int)36009, (int)this.y);
                GL30.glFramebufferTexture2D((int)36009, (int)36064, (int)3553, (int)glTexture.glId(), (int)0);
                GL30.glBindFramebuffer((int)36008, (int)this.aa);
                GL30.glBlitFramebuffer((int)0, (int)0, (int)this.E, (int)this.F, (int)0, (int)0, (int)this.E, (int)this.F, (int)16384, (int)9728);
                return;
            }
            if (f2.y <= 0.5f) {
                this.a(!list.isEmpty());
            }
            if ((d2 = Math.ceil(this.T * 16.0) / 16.0) != this.U) {
                this.U = d2;
                ShootingStarDemo.LOGGER.a("Spell FX budget {}%", Math.round(d2 * 100.0));
            }
            double d3 = 2300000.0 * d2;
            double d4 = Math.min(1.0, Math.sqrt(d3 / Math.max(1.0, (double)renderTarget.width * (double)renderTarget.height)));
            this.a(renderTarget.width, renderTarget.height, Math.max(2, (int)((double)renderTarget.width * d4)), Math.max(2, (int)((double)renderTarget.height * d4)), glTexture.glId(), glTexture2.glId());
            boolean bl4 = this.G != this.E || this.H != this.F;
            this.b(glTexture2.glId());
            if (!this.P) {
                this.P = true;
                this.a(glTexture.glId(), glTexture2.glId());
            }
            this.b(!list.isEmpty());
            GL11.glViewport((int)0, (int)0, (int)this.G, (int)this.H);
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
            GL11.glDisable((int)3042);
            GL11.glDisable((int)2884);
            GL11.glDisable((int)3089);
            GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
            GL33.glBindSampler((int)0, (int)0);
            GL33.glBindSampler((int)1, (int)0);
            GL33.glBindSampler((int)2, (int)0);
            GL33.glBindSampler((int)3, (int)0);
            GL33.glBindSampler((int)4, (int)0);
            GL33.glBindSampler((int)5, (int)0);
            GL30.glBindVertexArray((int)this.D);
            Matrix4f matrix4f3 = new Matrix4f((Matrix4fc)matrix4f).invert();
            Matrix4f matrix4f4 = new Matrix4f((Matrix4fc)matrix4f2).invert();
            Matrix4f matrix4f5 = new Matrix4f((Matrix4fc)matrix4f).mul((Matrix4fc)matrix4f2);
            int n3 = this.A;
            int n4 = 0;
            boolean bl5 = bl = f2.s > 0.5f && this.N;
            if (bl) {
                n3 = this.M;
                list = List.of();
            }
            for (e object22 : list) {
                g g2 = this.b(object22.a());
                if (g2 == null) continue;
                GL30.glBindFramebuffer((int)36009, (int)this.e[n4]);
                this.a(g2, n3, matrix4f3, matrix4f4, matrix4f5);
                object22.b().accept(this.m);
                GL11.glDrawArrays((int)4, (int)0, (int)3);
                n3 = this.f[n4];
                n4 ^= 1;
            }
            if (f2.s > 0.5f && !this.N) {
                boolean bl6 = n3 == this.A;
                GL30.glBindFramebuffer((int)36008, (int)(bl6 ? this.z : this.e[n4 ^ 1]));
                GL30.glBindFramebuffer((int)36009, (int)this.L);
                GL30.glBlitFramebuffer((int)0, (int)0, (int)(bl6 ? this.E : this.G), (int)(bl6 ? this.F : this.H), (int)0, (int)0, (int)this.G, (int)this.H, (int)16384, (int)9729);
                this.N = true;
            } else if (f2.s <= 0.5f && f2.t <= 0.001f) {
                this.N = false;
            }
            int n5 = n2 = f2.m > 0.001f && !bl ? this.a(n3, f2, matrix4f3, matrix4f4, matrix4f5) : 0;
            if (bl4) {
                GL30.glBindFramebuffer((int)36008, (int)this.z);
                GL30.glBindFramebuffer((int)36009, (int)this.I);
                GL30.glBlitFramebuffer((int)0, (int)0, (int)this.E, (int)this.F, (int)0, (int)0, (int)this.G, (int)this.H, (int)16384, (int)9729);
            }
            g g3 = this.b("composite");
            GL30.glBindFramebuffer((int)36009, (int)this.y);
            GL11.glViewport((int)0, (int)0, (int)this.E, (int)this.F);
            if (g3 != null) {
                this.a(g3, n3, matrix4f3, matrix4f4, matrix4f5);
                this.a(n2);
                this.a(1, this.A, "SceneSampler");
                this.a(3, this.J, "SceneLowSampler");
                this.a(4, n2 != 0 ? this.h[4] : 0, "ExposureSampler");
                this.a(5, this.M, "HoldSampler");
                this.m.b("AutoExposure", n2 != 0 ? 1.0f : 0.0f);
                this.m.b("Upscaled", bl4 && !bl ? 1.0f - Math.min(1.0f, f2.x) : 0.0f);
                this.m.a("Grade", f2.u, f2.v, this.N && !bl ? f2.t : 0.0f, f2.w);
                this.m.a("OutSize", this.E, this.F);
                this.m.b("Bloom", n2 != 0 ? f2.m : 0.0f);
                this.m.a("Impact", f2.o, f2.p, f2.q, f2.r);
                this.m.b("Shake", f2.a);
                this.m.b("Aberration", f2.b);
                this.m.b("Desaturate", f2.c);
                this.m.b("ZoomBlur", f2.d);
                this.m.a("Flash", f2.e, f2.f, f2.g, f2.h);
                this.m.a("Vignette", f2.i, f2.j, f2.k, f2.l);
                GL11.glDrawArrays((int)4, (int)0, (int)3);
            } else if (n3 != this.A) {
                GL30.glBindFramebuffer((int)36008, (int)this.e[n4 ^ 1]);
                GL30.glBlitFramebuffer((int)0, (int)0, (int)this.G, (int)this.H, (int)0, (int)0, (int)this.E, (int)this.F, (int)16384, (int)9729);
            }
            this.c(!list.isEmpty());
            this.a(f2, l2, matrix4f3, matrix4f4, matrix4f5);
            if (f2.y > 0.5f) {
                GL30.glBindFramebuffer((int)36008, (int)this.y);
                GL30.glBindFramebuffer((int)36009, (int)this.aa);
                GL30.glBlitFramebuffer((int)0, (int)0, (int)this.E, (int)this.F, (int)0, (int)0, (int)this.E, (int)this.F, (int)16384, (int)9728);
                this.ac = true;
                this.ad = l2;
            } else {
                this.ac = false;
            }
        }
        catch (RuntimeException runtimeException) {
            ShootingStarDemo.LOGGER.c("The Shooting Star post-processing failed", runtimeException);
            cyou.rimuru.shootingstardemo.client.a.a("the effects renderer", String.valueOf(runtimeException));
        }
        finally {
            ((b)object).b();
        }
    }

    private void a(f f2, long l2, Matrix4f matrix4f, Matrix4f matrix4f2, Matrix4f matrix4f3) {
        if (f2.z < 0.5f) {
            if (this.r != 0 && ++this.x > 600) {
                this.b();
            }
            return;
        }
        this.x = 0;
        int n2 = Math.max(2, this.E / 4);
        int n3 = Math.max(2, this.F / 4);
        if (this.r == 0 || this.s != n2 || this.t != n3) {
            this.b();
            this.r = GL30.glGenFramebuffers();
            for (int i2 = 0; i2 < 64; ++i2) {
                this.p[i2] = GL11.glGenTextures();
                cyou.rimuru.shootingstardemo.client.render.d.b(this.p[i2], n2, n3);
            }
            this.s = n2;
            this.t = n3;
            this.u = 0;
            this.v = 0;
        }
        if (f2.A >= 0.0f && this.v > 0) {
            g g2 = this.b("ton_rewind");
            if (g2 != null) {
                int n4 = this.a(f2.A);
                GL30.glBindFramebuffer((int)36009, (int)this.y);
                GL11.glViewport((int)0, (int)0, (int)this.E, (int)this.F);
                this.a(g2, this.p[n4], matrix4f, matrix4f2, matrix4f3);
                this.m.a("R0", this.O, f2.B, f2.A, 0.0f);
                this.m.a("OutSize", this.E, this.F);
                GL11.glDrawArrays((int)4, (int)0, (int)3);
            }
            return;
        }
        if (l2 - this.w < 33000000L) {
            return;
        }
        this.w = l2;
        GL30.glBindFramebuffer((int)36008, (int)this.y);
        GL30.glBindFramebuffer((int)36009, (int)this.r);
        GL30.glFramebufferTexture2D((int)36009, (int)36064, (int)3553, (int)this.p[this.u], (int)0);
        GL30.glBlitFramebuffer((int)0, (int)0, (int)this.E, (int)this.F, (int)0, (int)0, (int)this.s, (int)this.t, (int)16384, (int)9729);
        this.q[this.u] = l2;
        this.u = (this.u + 1) % 64;
        this.v = Math.min(this.v + 1, 64);
    }

    private int a(float f2) {
        int n2;
        int n3 = (this.u - 1 + 64) % 64;
        long l2 = this.q[n3] - (long)((double)f2 * 1.0E9);
        int n4 = n3;
        for (int i2 = 0; i2 < this.v && this.q[n2 = (n3 - i2 + 64) % 64] >= l2; ++i2) {
            n4 = n2;
        }
        return n4;
    }

    private void b() {
        if (this.r != 0) {
            GL30.glDeleteFramebuffers((int)this.r);
            for (int i2 = 0; i2 < 64; ++i2) {
                GL11.glDeleteTextures((int)this.p[i2]);
                this.p[i2] = 0;
            }
            this.r = 0;
            this.v = 0;
        }
    }

    private void a(boolean bl) {
        if (!bl) {
            this.T = Math.min(1.0, this.T * 1.05);
            return;
        }
        if (this.V > 0.0) {
            double d2 = Mth.clamp((double)(this.T * 16.0 / this.V), (double)0.25, (double)1.0);
            this.T = Mth.clamp((double)(d2 < this.T ? d2 : this.T + (d2 - this.T) * 0.33), (double)0.25, (double)1.0);
            if (++this.Y % 6 == 0) {
                ShootingStarDemo.LOGGER.a("Spell FX gpu {} ms at {}% budget", (double)Math.round(this.V * 10.0) / 10.0, Math.round(this.T * 100.0));
            }
            this.V = 0.0;
        }
    }

    private void b(boolean bl) {
        boolean bl2 = this.Z = bl && ++this.X % 8 == 0;
        if (this.Z) {
            GL11.glFinish();
            this.W = System.nanoTime();
        }
    }

    private void c(boolean bl) {
        if (this.Z) {
            GL11.glFinish();
            this.V = (double)(System.nanoTime() - this.W) / 1000000.0;
            this.Z = false;
        }
    }

    private int a(int n2, f f2, Matrix4f matrix4f, Matrix4f matrix4f2, Matrix4f matrix4f3) {
        int n3;
        g g2 = this.b("bloom_down");
        g g3 = this.b("bloom_up");
        if (g2 == null || g3 == null) {
            return 0;
        }
        int n4 = n2;
        int n5 = this.G;
        int n6 = this.H;
        for (n3 = 0; n3 < 5; ++n3) {
            GL30.glBindFramebuffer((int)36009, (int)this.g[n3]);
            GL11.glViewport((int)0, (int)0, (int)this.k[n3][0], (int)this.k[n3][1]);
            this.a(g2, n4, matrix4f, matrix4f2, matrix4f3);
            this.a(this.A);
            this.m.a("TexelSize", 1.0f / (float)n5, 1.0f / (float)n6);
            this.m.b("Prefilter", n3 == 0 ? 1.0f : 0.0f);
            this.m.b("Synthetic", f2.x);
            this.m.b("MaskAlpha", n2 != this.A ? 1.0f : 0.0f);
            GL11.glDrawArrays((int)4, (int)0, (int)3);
            n4 = this.h[n3];
            n5 = this.k[n3][0];
            n6 = this.k[n3][1];
        }
        for (n3 = 3; n3 >= 0; --n3) {
            GL30.glBindFramebuffer((int)36009, (int)this.i[n3]);
            GL11.glViewport((int)0, (int)0, (int)this.k[n3][0], (int)this.k[n3][1]);
            this.a(g3, n4, matrix4f, matrix4f2, matrix4f3);
            this.a(this.h[n3]);
            this.m.a("TexelSize", 1.0f / (float)n5, 1.0f / (float)n6);
            this.m.b("Radius", Math.max(1.0f, f2.n));
            GL11.glDrawArrays((int)4, (int)0, (int)3);
            n4 = this.j[n3];
            n5 = this.k[n3][0];
            n6 = this.k[n3][1];
        }
        return n4;
    }

    private void a(int n2, int n3, String string) {
        GL13.glActiveTexture((int)(33984 + n2));
        GL11.glBindTexture((int)3553, (int)n3);
        GL13.glActiveTexture((int)33984);
        int n4 = this.m.b.a(string);
        if (n4 >= 0) {
            GL20.glUniform1i((int)n4, (int)n2);
        }
    }

    private void a(int n2) {
        GL13.glActiveTexture((int)33986);
        GL11.glBindTexture((int)3553, (int)n2);
        GL13.glActiveTexture((int)33984);
        int n3 = this.m.b.a("AuxSampler");
        if (n3 >= 0) {
            GL20.glUniform1i((int)n3, (int)2);
        }
    }

    private void a(int n2, int n3) {
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)4);
        GL30.glBindFramebuffer((int)36008, (int)this.y);
        GL11.glReadPixels((int)(this.E / 2), (int)(this.F / 3), (int)1, (int)1, (int)6402, (int)5126, (FloatBuffer)floatBuffer);
        float f2 = floatBuffer.get(0);
        GL30.glBindFramebuffer((int)36008, (int)this.z);
        floatBuffer.clear();
        GL11.glReadPixels((int)(this.E / 2), (int)(this.F / 3), (int)1, (int)1, (int)6402, (int)5126, (FloatBuffer)floatBuffer);
        float f3 = floatBuffer.get(0);
        floatBuffer.clear();
        GL11.glReadPixels((int)(this.E / 2), (int)(this.F / 3), (int)1, (int)1, (int)6408, (int)5126, (FloatBuffer)floatBuffer);
        int n4 = GL11.glGetError();
        ShootingStarDemo.LOGGER.a("Spell FX diagnostic: {}x{} fx {}x{} depthFormat=0x{} mainDepth={} snapshotDepth={} snapshotColor=[{}, {}, {}] glError=0x{}", this.E, this.F, this.G, this.H, Integer.toHexString(this.K), Float.valueOf(f2), Float.valueOf(f3), Float.valueOf(floatBuffer.get(0)), Float.valueOf(floatBuffer.get(1)), Float.valueOf(floatBuffer.get(2)), Integer.toHexString(n4));
        if (Math.abs(f2 - f3) > 0.001f) {
            cyou.rimuru.shootingstardemo.client.a.a("the depth copy", "main " + f2 + ", copy " + f3 + ", glError 0x" + Integer.toHexString(n4));
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean a(String string) {
        b b2 = cyou.rimuru.shootingstardemo.client.render.d$b.a();
        try {
            g g2 = this.b(string);
            if (g2 == null) {
                boolean bl = false;
                return bl;
            }
            if (this.Q == 0) {
                this.Q = GL30.glGenVertexArrays();
                for (int i2 = 0; i2 < 2; ++i2) {
                    this.R[i2] = GL30.glGenFramebuffers();
                    this.S[i2] = GL11.glGenTextures();
                    if (i2 == 0) {
                        cyou.rimuru.shootingstardemo.client.render.d.a(this.S[i2], 1, 1);
                    } else {
                        cyou.rimuru.shootingstardemo.client.render.d.b(this.S[i2], 1, 1);
                    }
                    cyou.rimuru.shootingstardemo.client.render.d.b(this.R[i2], this.S[i2]);
                }
            }
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
            GL11.glDisable((int)3042);
            GL11.glDisable((int)2884);
            GL11.glDisable((int)3089);
            GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
            GL11.glViewport((int)0, (int)0, (int)1, (int)1);
            GL30.glBindVertexArray((int)this.Q);
            GL20.glUseProgram((int)g2.b);
            for (int n2 : this.R) {
                GL30.glBindFramebuffer((int)36009, (int)n2);
                GL11.glDrawArrays((int)4, (int)0, (int)3);
            }
            GL11.glFinish();
            boolean bl = true;
            return bl;
        }
        finally {
            b2.b();
        }
    }

    public void a() {
        this.a.values().forEach(g::a);
        this.a.clear();
        this.b.clear();
    }

    private g b(String string) {
        g g2 = this.a.get(string);
        if (g2 != null || this.b.contains(string)) {
            return g2;
        }
        try {
            g2 = cyou.rimuru.shootingstardemo.client.render.g.a(string, cyou.rimuru.shootingstardemo.client.render.g.b(string));
            this.a.put(string, g2);
            ShootingStarDemo.LOGGER.a("Compiled spell shader {}", string);
        }
        catch (Exception exception) {
            this.b.add(string);
            ShootingStarDemo.LOGGER.c("Could not build spell shader {}: {}", string, exception.getMessage());
            cyou.rimuru.shootingstardemo.client.a.a("effect " + string, String.valueOf(exception.getMessage()));
        }
        return g2;
    }

    private void a(g g2, int n2, Matrix4f matrix4f, Matrix4f matrix4f2, Matrix4f matrix4f3) {
        GL20.glUseProgram((int)g2.b);
        this.m.b = g2;
        this.m.c = 6;
        GL13.glActiveTexture((int)33984);
        GL11.glBindTexture((int)3553, (int)n2);
        GL13.glActiveTexture((int)33985);
        GL11.glBindTexture((int)3553, (int)this.B);
        GL13.glActiveTexture((int)33984);
        cyou.rimuru.shootingstardemo.client.render.d.c(g2.a("DiffuseSampler"), 0);
        cyou.rimuru.shootingstardemo.client.render.d.c(g2.a("DepthSampler"), 1);
        this.a(g2.a("InvProj"), matrix4f);
        this.a(g2.a("InvView"), matrix4f2);
        this.a(g2.a("ViewProj"), matrix4f3);
        this.m.a("OutSize", this.G, this.H);
        this.m.b("GTime", this.O);
        this.m.b("DepthZeroToOne", RenderSystem.getDevice().getDeviceInfo().isZZeroToOne() ? 1.0f : 0.0f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a(int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = GL11.glGetInteger((int)35055);
        GL15.glBindBuffer((int)35052, (int)0);
        try {
            int n9;
            if (this.D == 0) {
                this.D = GL30.glGenVertexArrays();
                for (n9 = 0; n9 < 2; ++n9) {
                    this.e[n9] = GL30.glGenFramebuffers();
                    this.f[n9] = GL11.glGenTextures();
                }
                this.y = GL30.glGenFramebuffers();
                this.z = GL30.glGenFramebuffers();
                this.A = GL11.glGenTextures();
                this.B = GL11.glGenTextures();
                this.C = GL33.glGenSamplers();
                GL33.glSamplerParameteri((int)this.C, (int)10241, (int)9728);
                GL33.glSamplerParameteri((int)this.C, (int)10240, (int)9728);
                GL33.glSamplerParameteri((int)this.C, (int)10242, (int)33071);
                GL33.glSamplerParameteri((int)this.C, (int)10243, (int)33071);
                GL33.glSamplerParameteri((int)this.C, (int)34892, (int)0);
                this.I = GL30.glGenFramebuffers();
                this.J = GL11.glGenTextures();
                this.L = GL30.glGenFramebuffers();
                this.M = GL11.glGenTextures();
                for (n9 = 0; n9 < 5; ++n9) {
                    this.g[n9] = GL30.glGenFramebuffers();
                    this.h[n9] = GL11.glGenTextures();
                    this.i[n9] = GL30.glGenFramebuffers();
                    this.j[n9] = GL11.glGenTextures();
                }
            }
            GL11.glBindTexture((int)3553, (int)n7);
            n9 = GL11.glGetTexLevelParameteri((int)3553, (int)0, (int)4099);
            if (n2 != this.E || n3 != this.F || n9 != this.K || n4 != this.G || n5 != this.H) {
                this.E = n2;
                this.F = n3;
                this.G = n4;
                this.H = n5;
                this.K = n9;
                this.c();
            }
            GL30.glBindFramebuffer((int)36160, (int)this.y);
            GL30.glFramebufferTexture2D((int)36160, (int)36064, (int)3553, (int)n6, (int)0);
            cyou.rimuru.shootingstardemo.client.render.d.a(n7, cyou.rimuru.shootingstardemo.client.render.d.d(this.K));
            GL11.glDrawBuffer((int)36064);
            GL11.glReadBuffer((int)36064);
            cyou.rimuru.shootingstardemo.client.render.d.c("main");
        }
        finally {
            GL15.glBindBuffer((int)35052, (int)n8);
        }
    }

    private void c() {
        int n2;
        int n3;
        for (n3 = 0; n3 < 2; ++n3) {
            cyou.rimuru.shootingstardemo.client.render.d.b(this.f[n3], this.G, this.H);
            GL30.glBindFramebuffer((int)36160, (int)this.e[n3]);
            GL30.glFramebufferTexture2D((int)36160, (int)36064, (int)3553, (int)this.f[n3], (int)0);
            GL11.glDrawBuffer((int)36064);
            cyou.rimuru.shootingstardemo.client.render.d.c("ping-pong");
        }
        for (n3 = 0; n3 < 5; ++n3) {
            n2 = Math.max(1, this.G >> n3 + 1);
            int n4 = Math.max(1, this.H >> n3 + 1);
            this.k[n3][0] = n2;
            this.k[n3][1] = n4;
            cyou.rimuru.shootingstardemo.client.render.d.a(this.h[n3], n2, n4);
            cyou.rimuru.shootingstardemo.client.render.d.b(this.g[n3], this.h[n3]);
            cyou.rimuru.shootingstardemo.client.render.d.a(this.j[n3], n2, n4);
            cyou.rimuru.shootingstardemo.client.render.d.b(this.i[n3], this.j[n3]);
        }
        cyou.rimuru.shootingstardemo.client.render.d.b(this.J, this.G, this.H);
        cyou.rimuru.shootingstardemo.client.render.d.b(this.I, this.J);
        cyou.rimuru.shootingstardemo.client.render.d.b(this.M, this.G, this.H);
        cyou.rimuru.shootingstardemo.client.render.d.b(this.L, this.M);
        if (this.aa == 0) {
            this.aa = GL30.glGenFramebuffers();
            this.ab = GL11.glGenTextures();
        }
        cyou.rimuru.shootingstardemo.client.render.d.b(this.ab, this.E, this.F);
        cyou.rimuru.shootingstardemo.client.render.d.b(this.aa, this.ab);
        this.ac = false;
        this.N = false;
        cyou.rimuru.shootingstardemo.client.render.d.b(this.A, this.E, this.F);
        n3 = cyou.rimuru.shootingstardemo.client.render.d.d(this.K) ? 1 : 0;
        switch (this.K) {
            case 33189: 
            case 33190: 
            case 33191: 
            case 35056: 
            case 36012: 
            case 36013: {
                int n5 = this.K;
                break;
            }
            default: {
                int n5 = n2 = 36012;
            }
        }
        if (Boolean.getBoolean("shooting_star_demo.mismatchdepth") && n3 == 0) {
            n2 = n2 == 33190 ? 36012 : 33190;
        }
        GL11.glBindTexture((int)3553, (int)this.B);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
        GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
        GL11.glTexParameteri((int)3553, (int)34892, (int)0);
        if (n3 != 0) {
            GL11.glTexImage2D((int)3553, (int)0, (int)n2, (int)this.E, (int)this.F, (int)0, (int)34041, (int)(n2 == 36013 ? 36269 : 34042), (long)0L);
        } else {
            GL11.glTexImage2D((int)3553, (int)0, (int)n2, (int)this.E, (int)this.F, (int)0, (int)6402, (int)5126, (long)0L);
        }
        GL30.glBindFramebuffer((int)36160, (int)this.z);
        GL30.glFramebufferTexture2D((int)36160, (int)36064, (int)3553, (int)this.A, (int)0);
        cyou.rimuru.shootingstardemo.client.render.d.a(this.B, n3 != 0);
        GL11.glDrawBuffer((int)36064);
        cyou.rimuru.shootingstardemo.client.render.d.c("snapshot");
    }

    private static void a(int n2, int n3, int n4) {
        GL11.glBindTexture((int)3553, (int)n2);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
        GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
        GL11.glTexImage2D((int)3553, (int)0, (int)34842, (int)n3, (int)n4, (int)0, (int)6408, (int)5126, (long)0L);
    }

    private static void b(int n2, int n3) {
        GL30.glBindFramebuffer((int)36160, (int)n2);
        GL30.glFramebufferTexture2D((int)36160, (int)36064, (int)3553, (int)n3, (int)0);
        GL11.glDrawBuffer((int)36064);
        cyou.rimuru.shootingstardemo.client.render.d.c("bloom");
    }

    private static void b(int n2, int n3, int n4) {
        GL11.glBindTexture((int)3553, (int)n2);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
        GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
        GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)n3, (int)n4, (int)0, (int)6408, (int)5121, (long)0L);
    }

    private void b(int n2) {
        GL30.glBindFramebuffer((int)36008, (int)this.y);
        GL30.glBindFramebuffer((int)36009, (int)this.z);
        GL30.glBlitFramebuffer((int)0, (int)0, (int)this.E, (int)this.F, (int)0, (int)0, (int)this.E, (int)this.F, (int)16384, (int)9728);
        this.c(n2);
    }

    private void c(int n2) {
        g g2 = this.b("depth_copy");
        if (g2 == null) {
            GL30.glBlitFramebuffer((int)0, (int)0, (int)this.E, (int)this.F, (int)0, (int)0, (int)this.E, (int)this.F, (int)256, (int)9728);
            return;
        }
        int n3 = GL11.glGetInteger((int)2932);
        GL11.glViewport((int)0, (int)0, (int)this.E, (int)this.F);
        GL11.glColorMask((boolean)false, (boolean)false, (boolean)false, (boolean)false);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)3089);
        GL11.glEnable((int)2929);
        GL11.glDepthFunc((int)519);
        GL11.glDepthMask((boolean)true);
        GL20.glUseProgram((int)g2.b);
        GL13.glActiveTexture((int)33985);
        GL11.glBindTexture((int)3553, (int)n2);
        GL33.glBindSampler((int)1, (int)this.C);
        GL13.glActiveTexture((int)33984);
        cyou.rimuru.shootingstardemo.client.render.d.c(g2.a("DepthSampler"), 1);
        GL30.glBindVertexArray((int)this.D);
        GL11.glDrawArrays((int)4, (int)0, (int)3);
        GL33.glBindSampler((int)1, (int)0);
        GL11.glDepthFunc((int)n3);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
    }

    private static boolean d(int n2) {
        return n2 == 35056 || n2 == 36013;
    }

    private static void a(int n2, boolean bl) {
        if (bl) {
            GL30.glFramebufferTexture2D((int)36160, (int)36096, (int)3553, (int)0, (int)0);
            GL30.glFramebufferTexture2D((int)36160, (int)33306, (int)3553, (int)n2, (int)0);
        } else {
            GL30.glFramebufferTexture2D((int)36160, (int)33306, (int)3553, (int)0, (int)0);
            GL30.glFramebufferTexture2D((int)36160, (int)36096, (int)3553, (int)n2, (int)0);
        }
    }

    private static void c(String string) {
        int n2 = GL30.glCheckFramebufferStatus((int)36160);
        if (n2 != 36053) {
            throw new IllegalStateException("Incomplete " + string + " framebuffer: " + n2);
        }
    }

    private static void c(int n2, int n3) {
        if (n2 >= 0) {
            GL20.glUniform1i((int)n2, (int)n3);
        }
    }

    private void a(int n2, Matrix4f matrix4f) {
        if (n2 >= 0) {
            this.l.clear();
            matrix4f.get(this.l);
            GL20.glUniformMatrix4fv((int)n2, (boolean)false, (FloatBuffer)this.l);
        }
    }

    private final class a
    implements j {
        static final int a = 6;
        g b;
        int c;
        final /* synthetic */ d d;

        private a(d d2) {
            d d3 = d2;
            Objects.requireNonNull(d3);
            this.d = d3;
        }

        @Override
        public void a(String string, String string2) {
            int n2 = this.b.a(string);
            if (n2 < 0 || this.c >= 16) {
                return;
            }
            int n3 = this.c++;
            GL13.glActiveTexture((int)(33984 + n3));
            GL11.glBindTexture((int)3553, (int)cyou.rimuru.shootingstardemo.client.render.a.b(string2));
            GL33.glBindSampler((int)n3, (int)0);
            GL13.glActiveTexture((int)33984);
            GL20.glUniform1i((int)n2, (int)n3);
        }

        @Override
        public void a(String string, int n2) {
            int n3 = this.b.a(string);
            if (n3 < 0 || this.c >= 16 || n2 == 0) {
                return;
            }
            int n4 = this.c++;
            GL13.glActiveTexture((int)(33984 + n4));
            GL11.glBindTexture((int)3553, (int)n2);
            GL33.glBindSampler((int)n4, (int)0);
            GL13.glActiveTexture((int)33984);
            GL20.glUniform1i((int)n3, (int)n4);
        }

        @Override
        public void a(String string, float f2) {
            this.a(string, this.d.r != 0 && this.d.v > 0 ? this.d.p[this.d.a(f2)] : this.d.A);
        }

        @Override
        public void b(String string, float f2) {
            int n2 = this.b.a(string);
            if (n2 >= 0) {
                GL20.glUniform1f((int)n2, (float)f2);
            }
        }

        @Override
        public void a(String string, float f2, float f3) {
            int n2 = this.b.a(string);
            if (n2 >= 0) {
                GL20.glUniform2f((int)n2, (float)f2, (float)f3);
            }
        }

        @Override
        public void a(String string, float f2, float f3, float f4) {
            int n2 = this.b.a(string);
            if (n2 >= 0) {
                GL20.glUniform3f((int)n2, (float)f2, (float)f3, (float)f4);
            }
        }

        @Override
        public void a(String string, float f2, float f3, float f4, float f5) {
            int n2 = this.b.a(string);
            if (n2 >= 0) {
                GL20.glUniform4f((int)n2, (float)f2, (float)f3, (float)f4, (float)f5);
            }
        }

        @Override
        public void a(String string, float[] fArray) {
            int n2 = this.b.a(string + "[0]");
            if (n2 < 0) {
                n2 = this.b.a(string);
            }
            if (n2 >= 0) {
                GL20.glUniform4fv((int)n2, (float[])fArray);
            }
        }
    }

    static final class b
    extends Record {
        private final int b;
        private final int c;
        private final int d;
        private final int e;
        private final int f;
        private final int[] g;
        private final int[] h;
        private final int[] i;
        private final boolean j;
        private final boolean k;
        private final boolean l;
        private final boolean m;
        private final boolean n;
        private final boolean[] o;
        static final int a = 16;

        b(int n2, int n3, int n4, int n5, int n6, int[] nArray, int[] nArray2, int[] nArray3, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5, boolean[] blArray) {
            this.b = n2;
            this.c = n3;
            this.d = n4;
            this.e = n5;
            this.f = n6;
            this.g = nArray;
            this.h = nArray2;
            this.i = nArray3;
            this.j = bl;
            this.k = bl2;
            this.l = bl3;
            this.m = bl4;
            this.n = bl5;
            this.o = blArray;
        }

        static b a() {
            IntBuffer intBuffer = BufferUtils.createIntBuffer((int)4);
            GL11.glGetIntegerv((int)2978, (IntBuffer)intBuffer);
            int n2 = GL11.glGetInteger((int)34016);
            int[] nArray = new int[16];
            int[] nArray2 = new int[16];
            for (int i2 = 0; i2 < 16; ++i2) {
                GL13.glActiveTexture((int)(33984 + i2));
                nArray[i2] = GL11.glGetInteger((int)32873);
                nArray2[i2] = GL11.glGetInteger((int)35097);
            }
            GL13.glActiveTexture((int)n2);
            ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)16);
            GL11.glGetBooleanv((int)3107, (ByteBuffer)byteBuffer);
            return new b(GL11.glGetInteger((int)36006), GL11.glGetInteger((int)36010), GL11.glGetInteger((int)35725), GL11.glGetInteger((int)34229), n2, nArray, nArray2, new int[]{intBuffer.get(0), intBuffer.get(1), intBuffer.get(2), intBuffer.get(3)}, GL11.glIsEnabled((int)2929), GL11.glIsEnabled((int)3042), GL11.glIsEnabled((int)2884), GL11.glIsEnabled((int)3089), GL11.glGetBoolean((int)2930), new boolean[]{byteBuffer.get(0) != 0, byteBuffer.get(1) != 0, byteBuffer.get(2) != 0, byteBuffer.get(3) != 0});
        }

        void b() {
            cyou.rimuru.shootingstardemo.client.render.d$b.a(2929, this.j);
            cyou.rimuru.shootingstardemo.client.render.d$b.a(3042, this.k);
            cyou.rimuru.shootingstardemo.client.render.d$b.a(2884, this.l);
            cyou.rimuru.shootingstardemo.client.render.d$b.a(3089, this.m);
            GL11.glDepthMask((boolean)this.n);
            GL11.glColorMask((boolean)this.o[0], (boolean)this.o[1], (boolean)this.o[2], (boolean)this.o[3]);
            GL20.glUseProgram((int)this.d);
            GL30.glBindVertexArray((int)this.e);
            for (int i2 = 0; i2 < 16; ++i2) {
                GL13.glActiveTexture((int)(33984 + i2));
                GL11.glBindTexture((int)3553, (int)this.g[i2]);
                GL33.glBindSampler((int)i2, (int)this.h[i2]);
            }
            GL13.glActiveTexture((int)this.f);
            GL30.glBindFramebuffer((int)36009, (int)this.b);
            GL30.glBindFramebuffer((int)36008, (int)this.c);
            GL11.glViewport((int)this.i[0], (int)this.i[1], (int)this.i[2], (int)this.i[3]);
        }

        private static void a(int n2, boolean bl) {
            if (bl) {
                GL11.glEnable((int)n2);
            } else {
                GL11.glDisable((int)n2);
            }
        }

        @Override
        public final String toString() {
            return ObjectMethods.bootstrap("toString", new MethodHandle[]{b.class, "drawFbo;readFbo;program;vao;activeTexture;textures;samplers;viewport;depthTest;blend;cull;scissor;depthMask;colorMask", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o"}, this);
        }

        @Override
        public final int hashCode() {
            return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{b.class, "drawFbo;readFbo;program;vao;activeTexture;textures;samplers;viewport;depthTest;blend;cull;scissor;depthMask;colorMask", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o"}, this);
        }

        @Override
        public final boolean equals(Object object) {
            return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{b.class, "drawFbo;readFbo;program;vao;activeTexture;textures;samplers;viewport;depthTest;blend;cull;scissor;depthMask;colorMask", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o"}, this, object);
        }

        public int c() {
            return this.b;
        }

        public int d() {
            return this.c;
        }

        public int e() {
            return this.d;
        }

        public int f() {
            return this.e;
        }

        public int g() {
            return this.f;
        }

        public int[] h() {
            return this.g;
        }

        public int[] i() {
            return this.h;
        }

        public int[] j() {
            return this.i;
        }

        public boolean k() {
            return this.j;
        }

        public boolean l() {
            return this.k;
        }

        public boolean m() {
            return this.l;
        }

        public boolean n() {
            return this.m;
        }

        public boolean o() {
            return this.n;
        }

        public boolean[] p() {
            return this.o;
        }
    }
}

