/*
 * Decompiled with CFR 0.152.
 */
package cyou.rimuru.shootingstardemo.client.cinematic;

import cyou.rimuru.shootingstardemo.client.cinematic.a;
import cyou.rimuru.shootingstardemo.client.cinematic.c;

public interface b {
    public a a(c var1, a var2, float var3, float var4);
}

