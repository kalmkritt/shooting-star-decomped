/*
 * Decompiled with CFR 0.152.
 */
package cyou.rimuru.shootingstardemo.client.cinematic;

import cyou.rimuru.shootingstardemo.client.cinematic.i;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;

public record g(int a, int b, int c, a d) {
    public static g a(int n2, int n3, a a2) {
        return new g(n2, n3, 0, a2);
    }

    public static g a(int n2, int n3, int n4, a a2) {
        return new g(n2, n3, n4, a2);
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{g.class, "start;end;blendIn;path", "a", "b", "c", "d"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{g.class, "start;end;blendIn;path", "a", "b", "c", "d"}, this);
    }

    @Override
    public final boolean equals(Object object) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{g.class, "start;end;blendIn;path", "a", "b", "c", "d"}, this, object);
    }

    @FunctionalInterface
    public static interface a {
        public cyou.rimuru.shootingstardemo.client.cinematic.a pose(i var1, float var2, float var3);
    }
}

