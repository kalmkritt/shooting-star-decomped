/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.phys.Vec3
 */
package cyou.rimuru.shootingstardemo.spell;

import cyou.rimuru.shootingstardemo.magic.e;
import cyou.rimuru.shootingstardemo.magic.f;
import cyou.rimuru.shootingstardemo.spell.d;
import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

public abstract class a {
    public final cyou.rimuru.shootingstardemo.magic.d a;
    public final ServerLevel b;
    public final UUID c;
    public final Vec3 d;
    public final Vec3 e;
    public final long f;
    public final boolean g;
    public final boolean h;
    public final f i;
    protected ServerPlayer j;
    protected int k;
    private double l;

    protected a(cyou.rimuru.shootingstardemo.magic.d d2, ServerPlayer serverPlayer, Vec3 vec3, Vec3 vec32, long l2, boolean bl) {
        this(d2, serverPlayer, vec3, vec32, l2, bl, cyou.rimuru.shootingstardemo.magic.f.a(d2));
    }

    protected a(cyou.rimuru.shootingstardemo.magic.d d2, ServerPlayer serverPlayer, Vec3 vec3, Vec3 vec32, long l2, boolean bl, f f2) {
        this.a = d2;
        this.i = f2;
        this.b = serverPlayer.level();
        this.c = serverPlayer.getUUID();
        this.j = serverPlayer;
        this.d = vec3;
        this.e = vec32;
        this.f = l2;
        this.g = bl;
        this.h = cyou.rimuru.shootingstardemo.magic.a.a(this.c);
    }

    final boolean a() {
        this.j = this.b.getServer().getPlayerList().getPlayer(this.c);
        if (this.j != null && this.j.level() != this.b) {
            this.j = null;
        }
        int n2 = (int)Math.floor(this.l + 1.0E-6);
        while (this.k <= n2 && !this.c()) {
            this.a(this.k);
            ++this.k;
        }
        this.b();
        this.l += (double)this.i.d();
        return this.c();
    }

    protected void b() {
    }

    protected boolean c() {
        return this.k > this.a.f();
    }

    protected abstract void a(int var1);

    protected int[] d() {
        return new int[0];
    }

    public cyou.rimuru.shootingstardemo.net.d e() {
        return new cyou.rimuru.shootingstardemo.net.d(cyou.rimuru.shootingstardemo.magic.e.a(this.a), this.j == null ? -1 : this.j.getId(), this.d.x, this.d.y, this.d.z, this.e.x, this.e.y, this.e.z, this.j == null ? 0.0f : this.j.getYRot(), this.f, this.d(), (this.g ? 1 : 0) | (this.g && cyou.rimuru.shootingstardemo.spell.d.a(this.b) ? 4 : 0) | (this.h ? 8 : 0), this.i.b(), this.i.d());
    }

    public double f() {
        return 512.0;
    }

    protected void g() {
    }

    public int h() {
        return this.k;
    }

    protected int b(int n2) {
        return Math.max(1, Math.round((float)n2 / this.i.d()));
    }

    protected Vec3 i() {
        return this.j != null && this.j.isAlive() ? this.j.position() : this.d;
    }

    protected static double a(double d2) {
        d2 = Math.max(0.0, Math.min(1.0, d2));
        return 1.0 - Math.pow(1.0 - d2, 3.0);
    }
}

