/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents
 *  net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.Identifier
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.CreativeModeTabs
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Rarity
 *  net.minecraft.world.level.ItemLike
 */
package cyou.rimuru.shootingstardemo.registry;

import cyou.rimuru.shootingstardemo.registry.b;
import cyou.rimuru.shootingstardemo.registry.f;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.ItemLike;

public final class e {
    public static final ResourceKey<Item> a = ResourceKey.create((ResourceKey)Registries.ITEM, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"stellar_remote"));
    public static final Item b = (Item)Registry.register((Registry)BuiltInRegistries.ITEM, a, (Object)((Object)new cyou.rimuru.shootingstardemo.magic.b(cyou.rimuru.shootingstardemo.registry.f.a, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant().setId(a))));
    public static final ResourceKey<Item> c = ResourceKey.create((ResourceKey)Registries.ITEM, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"star_core"));
    public static final Item d = (Item)Registry.register((Registry)BuiltInRegistries.ITEM, c, (Object)new BlockItem(cyou.rimuru.shootingstardemo.registry.b.c, new Item.Properties().useBlockDescriptionPrefix().setId(c)));
    public static final ResourceKey<Item> e = ResourceKey.create((ResourceKey)Registries.ITEM, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"gungnir_hull"));
    public static final Item f = (Item)Registry.register((Registry)BuiltInRegistries.ITEM, e, (Object)new BlockItem(cyou.rimuru.shootingstardemo.registry.b.a, new Item.Properties().useBlockDescriptionPrefix().setId(e)));
    public static final ResourceKey<Item> g = ResourceKey.create((ResourceKey)Registries.ITEM, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"gungnir_seam"));
    public static final Item h = (Item)Registry.register((Registry)BuiltInRegistries.ITEM, g, (Object)new BlockItem(cyou.rimuru.shootingstardemo.registry.b.b, new Item.Properties().useBlockDescriptionPrefix().setId(g)));
    public static final ResourceKey<Item> i = ResourceKey.create((ResourceKey)Registries.ITEM, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"star_trace"));
    public static final Item j = (Item)Registry.register((Registry)BuiltInRegistries.ITEM, i, (Object)new BlockItem(cyou.rimuru.shootingstardemo.registry.b.d, new Item.Properties().useBlockDescriptionPrefix().setId(i)));
    public static final ResourceKey<Item> k = ResourceKey.create((ResourceKey)Registries.ITEM, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"lattice_edge"));
    public static final Item l = (Item)Registry.register((Registry)BuiltInRegistries.ITEM, k, (Object)new BlockItem(cyou.rimuru.shootingstardemo.registry.b.e, new Item.Properties().useBlockDescriptionPrefix().setId(k)));

    private e() {
    }

    public static void a() {
        Registry.register((Registry)BuiltInRegistries.CREATIVE_MODE_TAB, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"shooting_star_demo"), (Object)FabricCreativeModeTab.builder().title((Component)Component.translatable((String)"itemGroup.shooting_star_demo")).icon(() -> new ItemStack((ItemLike)b)).displayItems((itemDisplayParameters, output) -> {
            output.accept((ItemLike)b);
            output.accept((ItemLike)d);
            output.accept((ItemLike)f);
            output.accept((ItemLike)h);
            output.accept((ItemLike)j);
            output.accept((ItemLike)l);
        }).build());
        CreativeModeTabEvents.modifyOutputEvent((ResourceKey)CreativeModeTabs.COMBAT).register(fabricCreativeModeTabOutput -> fabricCreativeModeTabOutput.accept((ItemLike)b));
    }
}

