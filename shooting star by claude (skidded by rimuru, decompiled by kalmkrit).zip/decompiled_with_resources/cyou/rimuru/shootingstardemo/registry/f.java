/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.Identifier
 */
package cyou.rimuru.shootingstardemo.registry;

import cyou.rimuru.shootingstardemo.magic.d;
import cyou.rimuru.shootingstardemo.magic.e;
import cyou.rimuru.shootingstardemo.star.j;
import cyou.rimuru.shootingstardemo.star.k;
import net.minecraft.resources.Identifier;

public final class f {
    public static final e a = e.a((Identifier)f.a("stellar_remote"), (int)16724808, (d[])k.values(), j::a);

    private f() {
    }

    public static void a() {
    }

    private static Identifier a(String string) {
        return Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)string);
    }
}

