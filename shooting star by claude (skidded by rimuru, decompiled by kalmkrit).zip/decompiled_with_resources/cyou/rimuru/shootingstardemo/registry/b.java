/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.Identifier
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.StateDefinition$Builder
 *  net.minecraft.world.level.block.state.properties.IntegerProperty
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraft.world.level.material.PushReaction
 */
package cyou.rimuru.shootingstardemo.registry;

import cyou.rimuru.shootingstardemo.registry.h;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;

public final class b {
    public static final Block a = Blocks.register((ResourceKey)ResourceKey.create((ResourceKey)Registries.BLOCK, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"gungnir_hull")), h::new, (BlockBehaviour.Properties)BlockBehaviour.Properties.of().strength(150.0f, 3600.0f).mapColor(MapColor.COLOR_BLACK).sound(SoundType.NETHERITE_BLOCK).requiresCorrectToolForDrops().isValidSpawn(Blocks::never).pushReaction(PushReaction.IMMOVEABLE));
    public static final Block b = Blocks.register((ResourceKey)ResourceKey.create((ResourceKey)Registries.BLOCK, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"gungnir_seam")), cyou.rimuru.shootingstardemo.registry.a::new, (BlockBehaviour.Properties)BlockBehaviour.Properties.of().strength(50.0f, 1200.0f).mapColor(MapColor.COLOR_ORANGE).sound(SoundType.NETHERITE_BLOCK).lightLevel(blockState -> 12).emissiveRendering(blockState -> true).requiresCorrectToolForDrops().isValidSpawn(Blocks::never).pushReaction(PushReaction.IMMOVEABLE));
    public static final Block c = Blocks.register((ResourceKey)ResourceKey.create((ResourceKey)Registries.BLOCK, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"star_core")), cyou.rimuru.shootingstardemo.registry.a::new, (BlockBehaviour.Properties)BlockBehaviour.Properties.of().strength(50.0f, 1200.0f).mapColor(MapColor.COLOR_PURPLE).sound(SoundType.AMETHYST).lightLevel(blockState -> 15).emissiveRendering(blockState -> true).requiresCorrectToolForDrops().isValidSpawn(Blocks::never).pushReaction(PushReaction.IMMOVEABLE));
    public static final Block d = Blocks.register((ResourceKey)ResourceKey.create((ResourceKey)Registries.BLOCK, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"star_trace")), Block::new, (BlockBehaviour.Properties)BlockBehaviour.Properties.of().strength(50.0f, 1200.0f).mapColor(MapColor.COLOR_PURPLE).sound(SoundType.AMETHYST).lightLevel(blockState -> 10).emissiveRendering(blockState -> true).requiresCorrectToolForDrops().isValidSpawn(Blocks::never).pushReaction(PushReaction.IMMOVEABLE));
    public static final Block e = Blocks.register((ResourceKey)ResourceKey.create((ResourceKey)Registries.BLOCK, (Identifier)Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)"lattice_edge")), a::new, (BlockBehaviour.Properties)BlockBehaviour.Properties.of().strength(50.0f, 1200.0f).mapColor(blockState -> cyou.rimuru.shootingstardemo.registry.b$a.b[(Integer)blockState.getValue((Property)cyou.rimuru.shootingstardemo.registry.b$a.a)]).sound(SoundType.AMETHYST).lightLevel(blockState -> 12).emissiveRendering(blockState -> true).requiresCorrectToolForDrops().isValidSpawn(Blocks::never).pushReaction(PushReaction.IMMOVEABLE));

    private b() {
    }

    public static void a() {
    }

    public static final class a
    extends Block {
        public static final IntegerProperty a = IntegerProperty.create((String)"hue", (int)0, (int)6);
        static final MapColor[] b = new MapColor[]{MapColor.COLOR_RED, MapColor.COLOR_ORANGE, MapColor.COLOR_YELLOW, MapColor.COLOR_LIGHT_GREEN, MapColor.COLOR_LIGHT_BLUE, MapColor.COLOR_BLUE, MapColor.COLOR_PURPLE};

        public a(BlockBehaviour.Properties properties) {
            super(properties);
            this.registerDefaultState((BlockState)((BlockState)this.stateDefinition.any()).setValue((Property)a, (Comparable)Integer.valueOf(0)));
        }

        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
            builder.add(new Property[]{a});
        }

        public static BlockState a(int n2) {
            return (BlockState)e.defaultBlockState().setValue((Property)a, (Comparable)Integer.valueOf(Math.floorMod(n2, 7)));
        }
    }
}

