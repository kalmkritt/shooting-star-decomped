/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.resources.Identifier
 *  net.minecraft.sounds.SoundEvent
 */
package cyou.rimuru.shootingstardemo.registry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class g {
    public static final SoundEvent a = cyou.rimuru.shootingstardemo.registry.g.a("staff_select");
    public static final SoundEvent b = cyou.rimuru.shootingstardemo.registry.g.a("star_arm");
    public static final SoundEvent c = cyou.rimuru.shootingstardemo.registry.g.a("star_press");
    public static final SoundEvent d = cyou.rimuru.shootingstardemo.registry.g.a("star_lock");
    public static final SoundEvent e = cyou.rimuru.shootingstardemo.registry.g.a("star_countdown");
    public static final SoundEvent f = cyou.rimuru.shootingstardemo.registry.g.a("star_ascent");
    public static final SoundEvent g = cyou.rimuru.shootingstardemo.registry.g.a("star_gun");
    public static final SoundEvent h = cyou.rimuru.shootingstardemo.registry.g.a("star_fire");
    public static final SoundEvent i = cyou.rimuru.shootingstardemo.registry.g.a("star_impact");
    public static final SoundEvent j = cyou.rimuru.shootingstardemo.registry.g.a("star_beam");
    public static final SoundEvent k = cyou.rimuru.shootingstardemo.registry.g.a("star_collapse");
    public static final SoundEvent l = cyou.rimuru.shootingstardemo.registry.g.a("star_after");
    public static final SoundEvent m = cyou.rimuru.shootingstardemo.registry.g.a("star_evac");
    public static final SoundEvent n = cyou.rimuru.shootingstardemo.registry.g.a("star_rg_arm");
    public static final SoundEvent o = cyou.rimuru.shootingstardemo.registry.g.a("star_rg_press");
    public static final SoundEvent p = cyou.rimuru.shootingstardemo.registry.g.a("star_rg_collapse");
    public static final SoundEvent q = cyou.rimuru.shootingstardemo.registry.g.a("star_rg_after");
    public static final SoundEvent r = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_mark");
    public static final SoundEvent s = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_countdown");
    public static final SoundEvent t = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_ascent");
    public static final SoundEvent u = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_ring");
    public static final SoundEvent v = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_load");
    public static final SoundEvent w = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_spin");
    public static final SoundEvent x = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_release");
    public static final SoundEvent y = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_flight");
    public static final SoundEvent z = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_hush");
    public static final SoundEvent A = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_crack");
    public static final SoundEvent B = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_boom");
    public static final SoundEvent C = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_wind");
    public static final SoundEvent D = cyou.rimuru.shootingstardemo.registry.g.a("gungnir_hum");
    public static final SoundEvent E = cyou.rimuru.shootingstardemo.registry.g.a("stars_mark");
    public static final SoundEvent F = cyou.rimuru.shootingstardemo.registry.g.a("stars_countdown");
    public static final SoundEvent G = cyou.rimuru.shootingstardemo.registry.g.a("stars_lock");
    public static final SoundEvent H = cyou.rimuru.shootingstardemo.registry.g.a("stars_ascent");
    public static final SoundEvent I = cyou.rimuru.shootingstardemo.registry.g.a("stars_array");
    public static final SoundEvent J = cyou.rimuru.shootingstardemo.registry.g.a("stars_fire");
    public static final SoundEvent K = cyou.rimuru.shootingstardemo.registry.g.a("stars_return");
    public static final SoundEvent L = cyou.rimuru.shootingstardemo.registry.g.a("stars_fall");
    public static final SoundEvent M = cyou.rimuru.shootingstardemo.registry.g.a("stars_land");
    public static final SoundEvent N = cyou.rimuru.shootingstardemo.registry.g.a("stars_link");
    public static final SoundEvent O = cyou.rimuru.shootingstardemo.registry.g.a("stars_finale");
    public static final SoundEvent P = cyou.rimuru.shootingstardemo.registry.g.a("stars_hum");
    public static final SoundEvent Q = cyou.rimuru.shootingstardemo.registry.g.a("ws_warp_in");
    public static final SoundEvent R = cyou.rimuru.shootingstardemo.registry.g.a("ws_warp_out");
    public static final SoundEvent S = cyou.rimuru.shootingstardemo.registry.g.a("ws_hover");
    public static final SoundEvent T = cyou.rimuru.shootingstardemo.registry.g.a("ws_open");
    public static final SoundEvent U = cyou.rimuru.shootingstardemo.registry.g.a("ws_info_open");
    public static final SoundEvent V = cyou.rimuru.shootingstardemo.registry.g.a("ws_info_close");
    public static final SoundEvent W = cyou.rimuru.shootingstardemo.registry.g.a("ws_bind");
    public static final SoundEvent X = cyou.rimuru.shootingstardemo.registry.g.a("ws_bound");
    public static final SoundEvent Y = cyou.rimuru.shootingstardemo.registry.g.a("ws_deny");
    public static final SoundEvent Z = cyou.rimuru.shootingstardemo.registry.g.a("ws_shatter");
    public static final SoundEvent[] aa = new SoundEvent[16];

    private g() {
    }

    private static SoundEvent a(String string) {
        Identifier identifier = Identifier.fromNamespaceAndPath((String)"shooting_star_demo", (String)string);
        return (SoundEvent)Registry.register((Registry)BuiltInRegistries.SOUND_EVENT, (Identifier)identifier, (Object)SoundEvent.createVariableRangeEvent((Identifier)identifier));
    }

    public static void a() {
    }

    static {
        for (int i2 = 0; i2 < aa.length; ++i2) {
            cyou.rimuru.shootingstardemo.registry.g.aa[i2] = cyou.rimuru.shootingstardemo.registry.g.a("tess_rw_" + (i2 < 9 ? "0" : "") + (i2 + 1));
        }
    }
}

