/*
 * Decompiled with CFR 0.152.
 */
package cyou.rimuru.shootingstardemo;

public final class a {
    public static final boolean a = true;
    public static final boolean b = true;

    private a() {
    }
}

